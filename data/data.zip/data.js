window.corona = window.corona || {};
window.corona.data = window.corona.data || {};

window.corona.data.virusInfo = [
    {
      "idx": 0,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.511165,
        "lng": 126.490914
      },
      "address": "제주국제공항 도착<br>제주시호텔 이용",
      "address2": "제주국제공항 도착<br>제주시호텔 이용",
      "visitDate": "1/21",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "1/21",
      "contact": ""
    },
    {
      "idx": 0,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.447314,
        "lng": 126.667472
      },
      "address": "에코랜드 이동",
      "address2": "에코랜드 이동",
      "visitDate": "1/21",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "1/21",
      "contact": ""
    },
    {
      "idx": 0,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.447314,
        "lng": 126.667472
      },
      "address": "에코랜드 이동",
      "address2": "에코랜드 이동",
      "visitDate": "1/21",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "1/21",
      "contact": ""
    },
    {
      "idx": 0,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.431925,
        "lng": 126.690027
      },
      "address": "산굼부리 이동",
      "address2": "산굼부리 이동",
      "visitDate": "1/21",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "1/21",
      "contact": ""
    },
    {
      "idx": 0,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.505442,
        "lng": 126.95379
      },
      "address": "우도 이동",
      "address2": "우도 이동",
      "visitDate": "1/21",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "1/21",
      "contact": ""
    },
    {
      "idx": 0,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.458735,
        "lng": 126.942586
      },
      "address": "성산일출봉 이동",
      "address2": "성산일출봉 이동",
      "visitDate": "1/21",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "1/21",
      "contact": ""
    },
    {
      "idx": 0,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.486097,
        "lng": 126.48806
      },
      "address": "신라면세점 인근에서 식사",
      "address2": "신라면세점 인근에서 식사",
      "visitDate": "1/21",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "1/21",
      "contact": ""
    },
    {
      "idx": 0,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.486097,
        "lng": 126.48806
      },
      "address": "신라면세점 인근에서 식사<br>1/23일 롯데,신라면세점 쇼핑",
      "address2": "신라면세점 인근에서 식사<br>1/23일 롯데,신라면세점 쇼핑",
      "visitDate": "1/21",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "1/21",
      "contact": ""
    },
    {
      "idx": 0,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.514097,
        "lng": 126.525514
      },
      "address": "칠성통 이동",
      "address2": "칠성통 이동",
      "visitDate": "1/21",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "1/21",
      "contact": ""
    },
    {
      "idx": 0,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.359775,
        "lng": 126.462876
      },
      "address": "1100고지 이동",
      "address2": "1100고지 이동",
      "visitDate": "1/21",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "1/21",
      "contact": ""
    },
    {
      "idx": 0,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.509313,
        "lng": 126.47243
      },
      "address": "도두해안도로 인근 식사",
      "address2": "도두해안도로 인근 식사",
      "visitDate": "1/21",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "1/21",
      "contact": ""
    },
    {
      "idx": 0,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.486251,
        "lng": 126.490708
      },
      "address": "느웨마루거리 산책",
      "address2": "느웨마루거리 산책",
      "visitDate": "1/21",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "1/21",
      "contact": ""
    },
    {
      "idx": 0,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.50727,
        "lng": 126.493282
      },
      "address": "공항 도착후 중국행",
      "address2": "공항 도착후 중국행",
      "visitDate": "1/21",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "1/21",
      "contact": ""
    },
    {
      "idx": 1,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.460459,
        "lng": 126.44068
      },
      "address": "인천공항 도착",
      "address2": "인천공항 도착",
      "visitDate": "1/19",
      "age": "35",
      "nation": "CN",
      "gender": "F",
      "date": "1/19",
      "contact": "45"
    },
    {
      "idx": 1,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.478832,
        "lng": 126.668558
      },
      "address": "인천의료원 <span style='color:red;'>격리</span>",
      "address2": "인천의료원 <span style='color:red;'>격리</span>",
      "visitDate": "1/19",
      "age": "35",
      "nation": "CN",
      "gender": "F",
      "date": "1/19",
      "contact": "45"
    },
    {
      "idx": 2,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.562143,
        "lng": 126.801884
      },
      "address": "김포공항 도착",
      "address2": "김포공항 도착",
      "visitDate": "1/22",
      "age": "55",
      "nation": "KR",
      "gender": "M",
      "date": "1/22",
      "contact": "16"
    },
    {
      "idx": 2,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.567454,
        "lng": 127.005627
      },
      "address": "보건소 선별진료<br>24일 국립중앙의료원 <span style='color:red;'>격리</span>",
      "address2": "보건소 선별진료<br>24일 국립중앙의료원 <span style='color:red;'>격리</span>",
      "visitDate": "1/22",
      "age": "55",
      "nation": "KR",
      "gender": "M",
      "date": "1/22",
      "contact": "16"
    },
    {
      "idx": 3,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.460459,
        "lng": 126.44068
      },
      "address": "인천공항 도착",
      "address2": "인천공항 도착",
      "visitDate": "1/20",
      "age": "54",
      "nation": "KR",
      "gender": "M",
      "date": "1/20",
      "contact": "98"
    },
    {
      "idx": 3,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.524978,
        "lng": 127.027718
      },
      "address": "강남구 성형외과 지인동행",
      "address2": "강남구 성형외과 지인동행",
      "visitDate": "1/20",
      "age": "54",
      "nation": "KR",
      "gender": "M",
      "date": "1/20",
      "contact": "98"
    },
    {
      "idx": 3,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.503359,
        "lng": 127.049177
      },
      "address": "강남구 호텔 투숙",
      "address2": "강남구 호텔 투숙",
      "visitDate": "1/20",
      "age": "54",
      "nation": "KR",
      "gender": "M",
      "date": "1/20",
      "contact": "98"
    },
    {
      "idx": 3,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.524669,
        "lng": 127.015911
      },
      "address": "한강변 편의점 이용",
      "address2": "한강변 편의점 이용",
      "visitDate": "1/20",
      "age": "54",
      "nation": "KR",
      "gender": "M",
      "date": "1/20",
      "contact": "98"
    },
    {
      "idx": 3,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.5292,
        "lng": 127.032597
      },
      "address": "강남구 일대 음식점 이용",
      "address2": "강남구 일대 음식점 이용",
      "visitDate": "1/20",
      "age": "54",
      "nation": "KR",
      "gender": "M",
      "date": "1/20",
      "contact": "98"
    },
    {
      "idx": 3,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.674192,
        "lng": 126.776955
      },
      "address": "일산 음식점 이용",
      "address2": "일산 음식점 이용",
      "visitDate": "1/20",
      "age": "54",
      "nation": "KR",
      "gender": "M",
      "date": "1/20",
      "contact": "98"
    },
    {
      "idx": 3,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.678158,
        "lng": 126.812165
      },
      "address": "일산 카페 이용",
      "address2": "일산 카페 이용",
      "visitDate": "1/20",
      "age": "54",
      "nation": "KR",
      "gender": "M",
      "date": "1/20",
      "contact": "98"
    },
    {
      "idx": 3,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.682229,
        "lng": 126.770046
      },
      "address": "일산 모친 자택 체류",
      "address2": "일산 모친 자택 체류",
      "visitDate": "1/20",
      "age": "54",
      "nation": "KR",
      "gender": "M",
      "date": "1/20",
      "contact": "98"
    },
    {
      "idx": 3,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.642457,
        "lng": 126.831318
      },
      "address": "일산 명지병원에 <span style='color:red;'>격리</span>",
      "address2": "일산 명지병원에 <span style='color:red;'>격리</span>",
      "visitDate": "1/20",
      "age": "54",
      "nation": "KR",
      "gender": "M",
      "date": "1/20",
      "contact": "98"
    },
    {
      "idx": 4,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.460459,
        "lng": 126.44068
      },
      "address": "인천 공항 도착",
      "address2": "인천 공항 도착",
      "visitDate": "1/20",
      "age": "55",
      "nation": "KR",
      "gender": "M",
      "date": "1/20",
      "contact": "95"
    },
    {
      "idx": 4,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.07994,
        "lng": 127.058282
      },
      "address": "평택 송탄터미널",
      "address2": "평택 송탄터미널",
      "visitDate": "1/20",
      "age": "55",
      "nation": "KR",
      "gender": "M",
      "date": "1/20",
      "contact": "95"
    },
    {
      "idx": 4,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.052277,
        "lng": 127.057309
      },
      "address": "평택 365연합의원 진료<br>21~25일 자택",
      "address2": "평택 365연합의원 진료<br>21~25일 자택",
      "visitDate": "1/20",
      "age": "55",
      "nation": "KR",
      "gender": "M",
      "date": "1/20",
      "contact": "95"
    },
    {
      "idx": 4,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.350625,
        "lng": 127.124515
      },
      "address": "분당서울대병원 <span style='color:red;'>격리</span>",
      "address2": "분당서울대병원 <span style='color:red;'>격리</span>",
      "visitDate": "1/20",
      "age": "55",
      "nation": "KR",
      "gender": "M",
      "date": "1/20",
      "contact": "95"
    },
    {
      "idx": 5,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.460459,
        "lng": 126.44068
      },
      "address": "인천 공항 도착",
      "address2": "인천 공항 도착",
      "visitDate": "1/24",
      "age": "33",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "31"
    },
    {
      "idx": 5,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.564119,
        "lng": 127.029694
      },
      "address": "성동구 소재 역술인 방문",
      "address2": "성동구 소재 역술인 방문",
      "visitDate": "1/24",
      "age": "33",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "31"
    },
    {
      "idx": 5,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.592858,
        "lng": 127.017016
      },
      "address": "성신여대입구 CGV 방문",
      "address2": "성신여대입구 CGV 방문",
      "visitDate": "1/24",
      "age": "33",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "31"
    },
    {
      "idx": 5,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.591819,
        "lng": 127.018314
      },
      "address": "성북구 소재 미용실 이용",
      "address2": "성북구 소재 미용실 이용",
      "visitDate": "1/24",
      "age": "33",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "31"
    },
    {
      "idx": 5,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.588913,
        "lng": 127.091112
      },
      "address": "중랑구 음식점 방문",
      "address2": "중랑구 음식점 방문",
      "visitDate": "1/24",
      "age": "33",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "31"
    },
    {
      "idx": 5,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.585379,
        "lng": 127.088581
      },
      "address": "중랑구 마트 방문",
      "address2": "중랑구 마트 방문",
      "visitDate": "1/24",
      "age": "33",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "31"
    },
    {
      "idx": 5,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.523938,
        "lng": 127.046554
      },
      "address": "강남구소재 웨딩숍 방문후 자택 이동",
      "address2": "강남구소재 웨딩숍 방문후 자택 이동",
      "visitDate": "1/24",
      "age": "33",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "31"
    },
    {
      "idx": 5,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.60677,
        "lng": 127.092697
      },
      "address": "중랑구 보건소 검진",
      "address2": "중랑구 보건소 검진",
      "visitDate": "1/24",
      "age": "33",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "31"
    },
    {
      "idx": 5,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.613102,
        "lng": 127.098658
      },
      "address": "서울의료원 <span style='color:red;'>격리</span>",
      "address2": "서울의료원 <span style='color:red;'>격리</span>",
      "visitDate": "1/24",
      "age": "33",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "31"
    },
    {
      "idx": 6,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.527728,
        "lng": 127.03236
      },
      "address": "강남구 일대 음식점 이용",
      "address2": "강남구 일대 음식점 이용",
      "visitDate": "1/22",
      "age": "55",
      "nation": "KR",
      "gender": "M",
      "date": "1/22",
      "contact": "17"
    },
    {
      "idx": 6,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.58754,
        "lng": 127.000047
      },
      "address": "자택 근처 교회에서 예배",
      "address2": "자택 근처 교회에서 예배",
      "visitDate": "1/22",
      "age": "55",
      "nation": "KR",
      "gender": "M",
      "date": "1/22",
      "contact": "17"
    },
    {
      "idx": 6,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.579678,
        "lng": 126.998945
      },
      "address": "서울대병원 <span style='color:red;'>격리</span>",
      "address2": "서울대병원 <span style='color:red;'>격리</span>",
      "visitDate": "1/22",
      "age": "55",
      "nation": "KR",
      "gender": "M",
      "date": "1/22",
      "contact": "17"
    },
    {
      "idx": 7,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.460459,
        "lng": 126.44068
      },
      "address": "인천 공항 도착",
      "address2": "인천 공항 도착",
      "visitDate": "1/23",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "1/23",
      "contact": "9"
    },
    {
      "idx": 7,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.613102,
        "lng": 127.098658
      },
      "address": "서울의료원 <span style='color:red;'>격리</span>",
      "address2": "서울의료원 <span style='color:red;'>격리</span>",
      "visitDate": "1/23",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "1/23",
      "contact": "9"
    },
    {
      "idx": 8,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.460459,
        "lng": 126.44068
      },
      "address": "인천 공항 도착",
      "address2": "인천 공항 도착",
      "visitDate": "1/23",
      "age": "62",
      "nation": "KR",
      "gender": "F",
      "date": "1/23",
      "contact": "113"
    },
    {
      "idx": 8,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.491149,
        "lng": 127.011767
      },
      "address": "서울 자택 기거<br>1/25 서초 소재 음식점 이용",
      "address2": "서울 자택 기거<br>1/25 서초 소재 음식점 이용",
      "visitDate": "1/23",
      "age": "62",
      "nation": "KR",
      "gender": "F",
      "date": "1/23",
      "contact": "113"
    },
    {
      "idx": 8,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.986967,
        "lng": 126.708147
      },
      "address": "대중목욕탕 방문<br>군산 소재 음식점 방문",
      "address2": "대중목욕탕 방문<br>군산 소재 음식점 방문",
      "visitDate": "1/23",
      "age": "62",
      "nation": "KR",
      "gender": "F",
      "date": "1/23",
      "contact": "113"
    },
    {
      "idx": 8,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.968603,
        "lng": 126.716109
      },
      "address": "군산 소재 의료기관 내원",
      "address2": "군산 소재 의료기관 내원",
      "visitDate": "1/23",
      "age": "62",
      "nation": "KR",
      "gender": "F",
      "date": "1/23",
      "contact": "113"
    },
    {
      "idx": 8,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.955681,
        "lng": 126.711961
      },
      "address": "군산 의료원 진료<br>1/29 문화동 근방 식사",
      "address2": "군산 의료원 진료<br>1/29 문화동 근방 식사",
      "visitDate": "1/23",
      "age": "62",
      "nation": "KR",
      "gender": "F",
      "date": "1/23",
      "contact": "113"
    },
    {
      "idx": 8,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.982998,
        "lng": 126.734919
      },
      "address": "대형마트 방문",
      "address2": "대형마트 방문",
      "visitDate": "1/23",
      "age": "62",
      "nation": "KR",
      "gender": "F",
      "date": "1/23",
      "contact": "113"
    },
    {
      "idx": 8,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.965199,
        "lng": 126.958853
      },
      "address": "원광대병원 <span style='color:red;'>격리</span>",
      "address2": "원광대병원 <span style='color:red;'>격리</span>",
      "visitDate": "1/23",
      "age": "62",
      "nation": "KR",
      "gender": "F",
      "date": "1/23",
      "contact": "113"
    },
    {
      "idx": 9,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.613102,
        "lng": 127.098658
      },
      "address": "서울의료원 <span style='color:red;'>격리</span>",
      "address2": "서울의료원 <span style='color:red;'>격리</span>",
      "visitDate": "1/31",
      "age": "28",
      "nation": "KR",
      "gender": "F",
      "date": "1/31",
      "contact": "2"
    },
    {
      "idx": 10,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.641481,
        "lng": 126.792022
      },
      "address": "고양시 소재 미용실 방문",
      "address2": "고양시 소재 미용실 방문",
      "visitDate": "1/30",
      "age": "54",
      "nation": "KR",
      "gender": "F",
      "date": "1/30",
      "contact": "43"
    },
    {
      "idx": 10,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.579918,
        "lng": 126.998362
      },
      "address": "서울대 병원 <span style='color:red;'>격리</span>",
      "address2": "서울대 병원 <span style='color:red;'>격리</span>",
      "visitDate": "1/30",
      "age": "54",
      "nation": "KR",
      "gender": "F",
      "date": "1/30",
      "contact": "43"
    },
    {
      "idx": 11,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.641736,
        "lng": 126.791217
      },
      "address": "고양시 소재 미용실 방문",
      "address2": "고양시 소재 미용실 방문",
      "visitDate": "1/30",
      "age": "25",
      "nation": "KR",
      "gender": "M",
      "date": "1/30",
      "contact": ""
    },
    {
      "idx": 11,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.580486,
        "lng": 127.000701
      },
      "address": "서울대 병원 <span style='color:red;'>격리</span>",
      "address2": "서울대 병원 <span style='color:red;'>격리</span>",
      "visitDate": "1/30",
      "age": "25",
      "nation": "KR",
      "gender": "M",
      "date": "1/30",
      "contact": ""
    },
    {
      "idx": 12,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.563581,
        "lng": 126.802056
      },
      "address": "김포 공항 도착",
      "address2": "김포 공항 도착",
      "visitDate": "1/19",
      "age": "48",
      "nation": "CN",
      "gender": "M",
      "date": "1/19",
      "contact": "420"
    },
    {
      "idx": 12,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.486112,
        "lng": 126.781023
      },
      "address": "부천역 CGV 방문",
      "address2": "부천역 CGV 방문",
      "visitDate": "1/19",
      "age": "48",
      "nation": "CN",
      "gender": "M",
      "date": "1/19",
      "contact": "420"
    },
    {
      "idx": 12,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.4631,
        "lng": 126.631371
      },
      "address": "인천 출입국관리사무소 방문",
      "address2": "인천 출입국관리사무소 방문",
      "visitDate": "1/19",
      "age": "48",
      "nation": "CN",
      "gender": "M",
      "date": "1/19",
      "contact": "420"
    },
    {
      "idx": 12,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.555062,
        "lng": 126.970618
      },
      "address": "부천시 약국 방문후 서울역 이동",
      "address2": "부천시 약국 방문후 서울역 이동",
      "visitDate": "1/19",
      "age": "48",
      "nation": "CN",
      "gender": "M",
      "date": "1/19",
      "contact": "420"
    },
    {
      "idx": 12,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.764239,
        "lng": 128.899265
      },
      "address": "강릉 도착",
      "address2": "강릉 도착",
      "visitDate": "1/19",
      "age": "48",
      "nation": "CN",
      "gender": "M",
      "date": "1/19",
      "contact": "420"
    },
    {
      "idx": 12,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.755252,
        "lng": 128.899762
      },
      "address": "강릉소재 음식점 이용",
      "address2": "강릉소재 음식점 이용",
      "visitDate": "1/19",
      "age": "48",
      "nation": "CN",
      "gender": "M",
      "date": "1/19",
      "contact": "420"
    },
    {
      "idx": 12,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.68365,
        "lng": 129.043829
      },
      "address": "강릉소재 숙소 이용",
      "address2": "강릉소재 숙소 이용",
      "visitDate": "1/19",
      "age": "48",
      "nation": "CN",
      "gender": "M",
      "date": "1/19",
      "contact": "420"
    },
    {
      "idx": 12,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.690782,
        "lng": 129.032031
      },
      "address": "강릉소재 음식점 이용",
      "address2": "강릉소재 음식점 이용",
      "visitDate": "1/19",
      "age": "48",
      "nation": "CN",
      "gender": "M",
      "date": "1/19",
      "contact": "420"
    },
    {
      "idx": 12,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.763697,
        "lng": 128.897881
      },
      "address": "강릉역 도착",
      "address2": "강릉역 도착",
      "visitDate": "1/19",
      "age": "48",
      "nation": "CN",
      "gender": "M",
      "date": "1/19",
      "contact": "420"
    },
    {
      "idx": 12,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.483885,
        "lng": 126.77806
      },
      "address": "부천시 소재 의료기관 방문",
      "address2": "부천시 소재 의료기관 방문",
      "visitDate": "1/19",
      "age": "48",
      "nation": "CN",
      "gender": "M",
      "date": "1/19",
      "contact": "420"
    },
    {
      "idx": 12,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.266602,
        "lng": 126.999805
      },
      "address": "수원역 이동",
      "address2": "수원역 이동",
      "visitDate": "1/19",
      "age": "48",
      "nation": "CN",
      "gender": "M",
      "date": "1/19",
      "contact": "420"
    },
    {
      "idx": 12,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.283066,
        "lng": 127.019904
      },
      "address": "친척집 방문",
      "address2": "친척집 방문",
      "visitDate": "1/19",
      "age": "48",
      "nation": "CN",
      "gender": "M",
      "date": "1/19",
      "contact": "420"
    },
    {
      "idx": 12,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.359357,
        "lng": 126.930992
      },
      "address": "군포소재 의료기관 방문",
      "address2": "군포소재 의료기관 방문",
      "visitDate": "1/19",
      "age": "48",
      "nation": "CN",
      "gender": "M",
      "date": "1/19",
      "contact": "420"
    },
    {
      "idx": 12,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.48587,
        "lng": 126.780125
      },
      "address": "부천역 CGV 재방문",
      "address2": "부천역 CGV 재방문",
      "visitDate": "1/19",
      "age": "48",
      "nation": "CN",
      "gender": "M",
      "date": "1/19",
      "contact": "420"
    },
    {
      "idx": 12,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.557078,
        "lng": 127.007666
      },
      "address": "서울 중구 소재 면세점 방문",
      "address2": "서울 중구 소재 면세점 방문",
      "visitDate": "1/19",
      "age": "48",
      "nation": "CN",
      "gender": "M",
      "date": "1/19",
      "contact": "420"
    },
    {
      "idx": 12,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.561192,
        "lng": 126.994074
      },
      "address": "서울 중구 활동",
      "address2": "서울 중구 활동",
      "visitDate": "1/19",
      "age": "48",
      "nation": "CN",
      "gender": "M",
      "date": "1/19",
      "contact": "420"
    },
    {
      "idx": 12,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.483614,
        "lng": 126.781754
      },
      "address": "부천 소재 약국 방문 후 자택 귀가",
      "address2": "부천 소재 약국 방문 후 자택 귀가",
      "visitDate": "1/19",
      "age": "48",
      "nation": "CN",
      "gender": "M",
      "date": "1/19",
      "contact": "420"
    },
    {
      "idx": 12,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.483893,
        "lng": 126.778092
      },
      "address": "부천시 소재 의료기관 재방문",
      "address2": "부천시 소재 의료기관 재방문",
      "visitDate": "1/19",
      "age": "48",
      "nation": "CN",
      "gender": "M",
      "date": "1/19",
      "contact": "420"
    },
    {
      "idx": 12,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.498619,
        "lng": 126.762854
      },
      "address": "부천보건소 선별진료소 방문<br>순천향대학교 부속 부천병원 방문",
      "address2": "부천보건소 선별진료소 방문<br>순천향대학교 부속 부천병원 방문",
      "visitDate": "1/19",
      "age": "48",
      "nation": "CN",
      "gender": "M",
      "date": "1/19",
      "contact": "420"
    },
    {
      "idx": 12,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.348152,
        "lng": 127.124784
      },
      "address": "분당 서울대병원 <span style='color:red;'>격리</span>",
      "address2": "분당 서울대병원 <span style='color:red;'>격리</span>",
      "visitDate": "1/19",
      "age": "48",
      "nation": "CN",
      "gender": "M",
      "date": "1/19",
      "contact": "420"
    },
    {
      "idx": 13,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.553381,
        "lng": 126.806361
      },
      "address": "우한교민 1차귀국 후 격리조치",
      "address2": "우한교민 1차귀국 후 격리조치",
      "visitDate": "1/31",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "1/31",
      "contact": ""
    },
    {
      "idx": 13,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.566876,
        "lng": 127.004962
      },
      "address": "국립중앙의료원 <span style='color:red;'>격리</span>",
      "address2": "국립중앙의료원 <span style='color:red;'>격리</span>",
      "visitDate": "1/31",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "1/31",
      "contact": ""
    },
    {
      "idx": 14,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.563581,
        "lng": 126.802056
      },
      "address": "김포 공항 도착",
      "address2": "김포 공항 도착",
      "visitDate": "1/19",
      "age": "40",
      "nation": "CN",
      "gender": "F",
      "date": "1/19",
      "contact": "3"
    },
    {
      "idx": 14,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.498304,
        "lng": 126.762864
      },
      "address": "순천향대학교부속 부천병원 방문",
      "address2": "순천향대학교부속 부천병원 방문",
      "visitDate": "1/19",
      "age": "40",
      "nation": "CN",
      "gender": "F",
      "date": "1/19",
      "contact": "3"
    },
    {
      "idx": 14,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.484044,
        "lng": 126.782436
      },
      "address": "부천시소재 대형마트 이용",
      "address2": "부천시소재 대형마트 이용",
      "visitDate": "1/19",
      "age": "40",
      "nation": "CN",
      "gender": "F",
      "date": "1/19",
      "contact": "3"
    },
    {
      "idx": 14,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.347722,
        "lng": 127.124322
      },
      "address": "분당서울대병원 <span style='color:red;'>격리</span>",
      "address2": "분당서울대병원 <span style='color:red;'>격리</span>",
      "visitDate": "1/19",
      "age": "40",
      "nation": "CN",
      "gender": "F",
      "date": "1/19",
      "contact": "3"
    },
    {
      "idx": 15,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.460459,
        "lng": 126.44068
      },
      "address": "인천 공항 도착",
      "address2": "인천 공항 도착",
      "visitDate": "1/20",
      "age": "43",
      "nation": "KR",
      "gender": "M",
      "date": "1/20",
      "contact": "15"
    },
    {
      "idx": 15,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.297586,
        "lng": 126.978377
      },
      "address": "자택 자가격리",
      "address2": "자택 자가격리",
      "visitDate": "1/20",
      "age": "43",
      "nation": "KR",
      "gender": "M",
      "date": "1/20",
      "contact": "15"
    },
    {
      "idx": 15,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.304558,
        "lng": 127.010198
      },
      "address": "장안구보건소 방문",
      "address2": "장안구보건소 방문",
      "visitDate": "1/20",
      "age": "43",
      "nation": "KR",
      "gender": "M",
      "date": "1/20",
      "contact": "15"
    },
    {
      "idx": 15,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.390524,
        "lng": 127.149769
      },
      "address": "국군수도병원 <span style='color:red;'>격리</span>",
      "address2": "국군수도병원 <span style='color:red;'>격리</span>",
      "visitDate": "1/20",
      "age": "43",
      "nation": "KR",
      "gender": "M",
      "date": "1/20",
      "contact": "15"
    },
    {
      "idx": 16,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 34.996485,
        "lng": 126.387447
      },
      "address": "무안공항 입국",
      "address2": "무안공항 입국",
      "visitDate": "1/19",
      "age": "42",
      "nation": "KR",
      "gender": "F",
      "date": "1/19",
      "contact": "430"
    },
    {
      "idx": 16,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.175836,
        "lng": 126.818103
      },
      "address": "21세기병원 치료<br>21세기병원 내 체류",
      "address2": "21세기병원 치료<br>21세기병원 내 체류",
      "visitDate": "1/19",
      "age": "42",
      "nation": "KR",
      "gender": "F",
      "date": "1/19",
      "contact": "430"
    },
    {
      "idx": 16,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.142094,
        "lng": 126.921635
      },
      "address": "전남대학교병원 <span style='color:red;'>격리</span>",
      "address2": "전남대학교병원 <span style='color:red;'>격리</span>",
      "visitDate": "1/19",
      "age": "42",
      "nation": "KR",
      "gender": "F",
      "date": "1/19",
      "contact": "430"
    },
    {
      "idx": 17,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.460459,
        "lng": 126.44068
      },
      "address": "인천공항 도착",
      "address2": "인천공항 도착",
      "visitDate": "1/24",
      "age": "37",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "290"
    },
    {
      "idx": 17,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.555877,
        "lng": 126.969728
      },
      "address": "서울역 음식점에서 식사",
      "address2": "서울역 음식점에서 식사",
      "visitDate": "1/24",
      "age": "37",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "290"
    },
    {
      "idx": 17,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.879893,
        "lng": 128.628476
      },
      "address": "동대구역 도착",
      "address2": "동대구역 도착",
      "visitDate": "1/24",
      "age": "37",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "290"
    },
    {
      "idx": 17,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.85816,
        "lng": 128.63054
      },
      "address": "수성구 본가 이동",
      "address2": "수성구 본가 이동",
      "visitDate": "1/24",
      "age": "37",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "290"
    },
    {
      "idx": 17,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.885552,
        "lng": 128.582882
      },
      "address": "북구 방문",
      "address2": "북구 방문",
      "visitDate": "1/24",
      "age": "37",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "290"
    },
    {
      "idx": 17,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.878754,
        "lng": 128.6254936
      },
      "address": "동대구역 출발",
      "address2": "동대구역 출발",
      "visitDate": "1/24",
      "age": "37",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "290"
    },
    {
      "idx": 17,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.487409,
        "lng": 127.10155
      },
      "address": "수서역 도착",
      "address2": "수서역 도착",
      "visitDate": "1/24",
      "age": "37",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "290"
    },
    {
      "idx": 17,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.601196,
        "lng": 127.132803
      },
      "address": "한양대 응급실 방문,진료",
      "address2": "한양대 응급실 방문,진료",
      "visitDate": "1/24",
      "age": "37",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "290"
    },
    {
      "idx": 17,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.606423,
        "lng": 127.138958
      },
      "address": "삼성서울가정의원 진료<br>구리시 약국 약처방",
      "address2": "삼성서울가정의원 진료<br>구리시 약국 약처방",
      "visitDate": "1/24",
      "age": "37",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "290"
    },
    {
      "idx": 17,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.587193,
        "lng": 127.138966
      },
      "address": "구리시 음식점 식사",
      "address2": "구리시 음식점 식사",
      "visitDate": "1/24",
      "age": "37",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "290"
    },
    {
      "idx": 17,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.586809,
        "lng": 127.138323
      },
      "address": "구리시 마트 방문",
      "address2": "구리시 마트 방문",
      "visitDate": "1/24",
      "age": "37",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "290"
    },
    {
      "idx": 17,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.587102,
        "lng": 127.138193
      },
      "address": "서울아산내과 진료 및 근처 약국 이용",
      "address2": "서울아산내과 진료 및 근처 약국 이용",
      "visitDate": "1/24",
      "age": "37",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "290"
    },
    {
      "idx": 17,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.545354,
        "lng": 127.10319
      },
      "address": "광나루역 도착 후 인근 편의점 이용",
      "address2": "광나루역 도착 후 인근 편의점 이용",
      "visitDate": "1/24",
      "age": "37",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "290"
    },
    {
      "idx": 17,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.601095,
        "lng": 127.132179
      },
      "address": "한양대 구리병원 선별진료소 방문",
      "address2": "한양대 구리병원 선별진료소 방문",
      "visitDate": "1/24",
      "age": "37",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "290"
    },
    {
      "idx": 17,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.645413,
        "lng": 126.831101
      },
      "address": "명지병원 <span style='color:red;'>격리</span>",
      "address2": "명지병원 <span style='color:red;'>격리</span>",
      "visitDate": "1/24",
      "age": "37",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "290"
    },
    {
      "idx": 18,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.175661,
        "lng": 126.818743
      },
      "address": "광주 21세기병원 입원",
      "address2": "광주 21세기병원 입원",
      "visitDate": "1/27",
      "age": "20",
      "nation": "KR",
      "gender": "F",
      "date": "1/27",
      "contact": "8"
    },
    {
      "idx": 18,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.140927,
        "lng": 126.922322
      },
      "address": "전남대학교병원 <span style='color:red;'>격리</span>",
      "address2": "전남대학교병원 <span style='color:red;'>격리</span>",
      "visitDate": "1/27",
      "age": "20",
      "nation": "KR",
      "gender": "F",
      "date": "1/27",
      "contact": "8"
    },
    {
      "idx": 19,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.460459,
        "lng": 126.44068
      },
      "address": "인천공항 도착",
      "address2": "인천공항 도착",
      "visitDate": "1/24",
      "age": "36",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "67"
    },
    {
      "idx": 19,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.378511,
        "lng": 127.114316
      },
      "address": "분당 수내동 직장 출근",
      "address2": "분당 수내동 직장 출근",
      "visitDate": "1/24",
      "age": "36",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "67"
    },
    {
      "idx": 19,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.499514,
        "lng": 127.11202
      },
      "address": "송파구소재 빵집 방문",
      "address2": "송파구소재 빵집 방문",
      "visitDate": "1/24",
      "age": "36",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "67"
    },
    {
      "idx": 19,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.497001,
        "lng": 127.119984
      },
      "address": "송파구 소재 소재 음식점 방문",
      "address2": "송파구 소재 소재 음식점 방문",
      "visitDate": "1/24",
      "age": "36",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "67"
    },
    {
      "idx": 19,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.499514,
        "lng": 127.11202
      },
      "address": "송파구소재 빵집 방문",
      "address2": "송파구소재 빵집 방문",
      "visitDate": "1/24",
      "age": "36",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "67"
    },
    {
      "idx": 19,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.504752,
        "lng": 127.027474
      },
      "address": "서울시 강남구 소재 호텔 방문",
      "address2": "서울시 강남구 소재 호텔 방문",
      "visitDate": "1/24",
      "age": "36",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "67"
    },
    {
      "idx": 19,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.381624,
        "lng": 126.657218
      },
      "address": "송도 대형쇼핑몰 방문",
      "address2": "송도 대형쇼핑몰 방문",
      "visitDate": "1/24",
      "age": "36",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "67"
    },
    {
      "idx": 19,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.495414,
        "lng": 127.117521
      },
      "address": "서울시 송파구 소재 음식점 방문",
      "address2": "서울시 송파구 소재 음식점 방문",
      "visitDate": "1/24",
      "age": "36",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "67"
    },
    {
      "idx": 19,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.377241,
        "lng": 127.112749
      },
      "address": "분당구 소재 음식점 방문",
      "address2": "분당구 소재 음식점 방문",
      "visitDate": "1/24",
      "age": "36",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "67"
    },
    {
      "idx": 19,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.613102,
        "lng": 127.098658
      },
      "address": "서울의료원 <span style='color:red;'>격리</span>",
      "address2": "서울의료원 <span style='color:red;'>격리</span>",
      "visitDate": "1/24",
      "age": "36",
      "nation": "KR",
      "gender": "M",
      "date": "1/24",
      "contact": "67"
    },
    {
      "idx": 20,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.521024,
        "lng": 126.889323
      },
      "address": "영등포구 회사 근무",
      "address2": "영등포구 회사 근무",
      "visitDate": "",
      "age": "41",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": "2"
    },
    {
      "idx": 20,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.296669,
        "lng": 126.97957
      },
      "address": "수원 천천동 자택 기거",
      "address2": "수원 천천동 자택 기거",
      "visitDate": "",
      "age": "41",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": "2"
    },
    {
      "idx": 20,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.304439,
        "lng": 127.010123
      },
      "address": "수원 장안구 보건소 이동 후 검사",
      "address2": "수원 장안구 보건소 이동 후 검사",
      "visitDate": "",
      "age": "41",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": "2"
    },
    {
      "idx": 20,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.391762,
        "lng": 127.148825
      },
      "address": "국군수도병원 <span style='color:red;'>격리</span>",
      "address2": "국군수도병원 <span style='color:red;'>격리</span>",
      "visitDate": "",
      "age": "41",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": "2"
    },
    {
      "idx": 21,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.586425,
        "lng": 126.9998
      },
      "address": "명륜교회 예배당(본당)",
      "address2": "명륜교회 예배당(본당)",
      "visitDate": "1/29",
      "age": "59",
      "nation": "KR",
      "gender": "F",
      "date": "1/29",
      "contact": "6"
    },
    {
      "idx": 21,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.602813,
        "lng": 127.039582
      },
      "address": "성북구 보건소 방문",
      "address2": "성북구 보건소 방문",
      "visitDate": "1/29",
      "age": "59",
      "nation": "KR",
      "gender": "F",
      "date": "1/29",
      "contact": "6"
    },
    {
      "idx": 21,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.579747,
        "lng": 126.998395
      },
      "address": "서울대병원 <span style='color:red;'>격리</span>",
      "address2": "서울대병원 <span style='color:red;'>격리</span>",
      "visitDate": "1/29",
      "age": "59",
      "nation": "KR",
      "gender": "F",
      "date": "1/29",
      "contact": "6"
    },
    {
      "idx": 22,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.015831,
        "lng": 126.710771
      },
      "address": "나주 자택에서 자가격리 중 확진판정",
      "address2": "나주 자택에서 자가격리 중 확진판정",
      "visitDate": "2/6",
      "age": "46",
      "nation": "KR",
      "gender": "M",
      "date": "2/6",
      "contact": "1"
    },
    {
      "idx": 22,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.138602,
        "lng": 126.92612
      },
      "address": "조선대병원 <span style='color:red;'>격리</span>",
      "address2": "조선대병원 <span style='color:red;'>격리</span>",
      "visitDate": "2/6",
      "age": "46",
      "nation": "KR",
      "gender": "M",
      "date": "2/6",
      "contact": "1"
    },
    {
      "idx": 23,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.460459,
        "lng": 126.44068
      },
      "address": "인천공항 도착",
      "address2": "인천공항 도착",
      "visitDate": "1/23",
      "age": "57",
      "nation": "CN",
      "gender": "F",
      "date": "1/23",
      "contact": "23"
    },
    {
      "idx": 23,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.565707,
        "lng": 126.979336
      },
      "address": "서울시 중구 소재 호텔 퇴실",
      "address2": "서울시 중구 소재 호텔 퇴실",
      "visitDate": "1/23",
      "age": "57",
      "nation": "CN",
      "gender": "F",
      "date": "1/23",
      "contact": "23"
    },
    {
      "idx": 23,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.565152,
        "lng": 126.981348
      },
      "address": "서울시 중구 소재 백화점 방문",
      "address2": "서울시 중구 소재 백화점 방문",
      "visitDate": "1/23",
      "age": "57",
      "nation": "CN",
      "gender": "F",
      "date": "1/23",
      "contact": "23"
    },
    {
      "idx": 23,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.542533,
        "lng": 126.95331
      },
      "address": "마포구 소재 대형마트 방문(이마트 마포공덕점)",
      "address2": "마포구 소재 대형마트 방문(이마트 마포공덕점)",
      "visitDate": "1/23",
      "age": "57",
      "nation": "CN",
      "gender": "F",
      "date": "1/23",
      "contact": "23"
    },
    {
      "idx": 23,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.567122,
        "lng": 127.005777
      },
      "address": "국립중앙의료원 <span style='color:red;'>격리</span>",
      "address2": "국립중앙의료원 <span style='color:red;'>격리</span>",
      "visitDate": "1/23",
      "age": "57",
      "nation": "CN",
      "gender": "F",
      "date": "1/23",
      "contact": "23"
    },
    {
      "idx": 24,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.460459,
        "lng": 126.44068
      },
      "address": "인천공항 도착",
      "address2": "인천공항 도착",
      "visitDate": "1/23",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "1/23",
      "contact": ""
    },
    {
      "idx": 24,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.567152,
        "lng": 127.00567
      },
      "address": "국립중앙의료원 <span style='color:red;'>격리</span>",
      "address2": "국립중앙의료원 <span style='color:red;'>격리</span>",
      "visitDate": "1/23",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "1/23",
      "contact": ""
    },
    {
      "idx": 25,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.41733,
        "lng": 126.811396
      },
      "address": "경기도 시흥시 소재 슈퍼마켓 방문",
      "address2": "경기도 시흥시 소재 슈퍼마켓 방문",
      "visitDate": "2/5",
      "age": "73",
      "nation": "KR",
      "gender": "F",
      "date": "2/5",
      "contact": "11"
    },
    {
      "idx": 25,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.444478,
        "lng": 126.789562
      },
      "address": "시흥시 소재 의료기관(신천연합병원)방문",
      "address2": "시흥시 소재 의료기관(신천연합병원)방문",
      "visitDate": "2/5",
      "age": "73",
      "nation": "KR",
      "gender": "F",
      "date": "2/5",
      "contact": "11"
    },
    {
      "idx": 25,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.438205,
        "lng": 126.796363
      },
      "address": "경기도 시흥시 소재 슈퍼마켓 방문",
      "address2": "경기도 시흥시 소재 슈퍼마켓 방문",
      "visitDate": "2/5",
      "age": "73",
      "nation": "KR",
      "gender": "F",
      "date": "2/5",
      "contact": "11"
    },
    {
      "idx": 25,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.444478,
        "lng": 126.789562
      },
      "address": "시흥시 소재 의료기관(신천연합병원)방문",
      "address2": "시흥시 소재 의료기관(신천연합병원)방문",
      "visitDate": "2/5",
      "age": "73",
      "nation": "KR",
      "gender": "F",
      "date": "2/5",
      "contact": "11"
    },
    {
      "idx": 25,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.350625,
        "lng": 127.124515
      },
      "address": "분당서울대병원 <span style='color:red;'>격리</span>",
      "address2": "분당서울대병원 <span style='color:red;'>격리</span>",
      "visitDate": "2/5",
      "age": "73",
      "nation": "KR",
      "gender": "F",
      "date": "2/5",
      "contact": "11"
    },
    {
      "idx": 26,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.444478,
        "lng": 126.789562
      },
      "address": "시흥시 소재 의료기관(신천연합병원)방문",
      "address2": "시흥시 소재 의료기관(신천연합병원)방문",
      "visitDate": "2/7",
      "age": "51",
      "nation": "KR",
      "gender": "M",
      "date": "2/7",
      "contact": ""
    },
    {
      "idx": 26,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.438205,
        "lng": 126.796363
      },
      "address": "경기도 시흥시 소재 슈퍼마켓 방문",
      "address2": "경기도 시흥시 소재 슈퍼마켓 방문",
      "visitDate": "2/7",
      "age": "51",
      "nation": "KR",
      "gender": "M",
      "date": "2/7",
      "contact": ""
    },
    {
      "idx": 26,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.017297,
        "lng": 127.260422
      },
      "address": "경기도의료원 안성병원 <span style='color:red;'>격리</span>",
      "address2": "경기도의료원 안성병원 <span style='color:red;'>격리</span>",
      "visitDate": "2/7",
      "age": "51",
      "nation": "KR",
      "gender": "M",
      "date": "2/7",
      "contact": ""
    },
    {
      "idx": 27,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.460459,
        "lng": 126.44068
      },
      "address": "인천공항 도착",
      "address2": "인천공항 도착",
      "visitDate": "1/31",
      "age": "37",
      "nation": "CN",
      "gender": "F",
      "date": "1/31",
      "contact": "37"
    },
    {
      "idx": 27,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.432458,
        "lng": 126.80988
      },
      "address": "시흥시 소재 음식점 방문",
      "address2": "시흥시 소재 음식점 방문",
      "visitDate": "1/31",
      "age": "37",
      "nation": "CN",
      "gender": "F",
      "date": "1/31",
      "contact": "37"
    },
    {
      "idx": 27,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.444478,
        "lng": 126.789562
      },
      "address": "시흥시 소재 의료기관(신천연합병원)방문",
      "address2": "시흥시 소재 의료기관(신천연합병원)방문",
      "visitDate": "1/31",
      "age": "37",
      "nation": "CN",
      "gender": "F",
      "date": "1/31",
      "contact": "37"
    },
    {
      "idx": 27,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.017297,
        "lng": 127.260422
      },
      "address": "경기도의료원 안성병원 <span style='color:red;'>격리</span>",
      "address2": "경기도의료원 안성병원 <span style='color:red;'>격리</span>",
      "visitDate": "1/31",
      "age": "37",
      "nation": "CN",
      "gender": "F",
      "date": "1/31",
      "contact": "37"
    },
    {
      "idx": 28,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.642092,
        "lng": 126.831264
      },
      "address": " 1월 26일부터 자가격리<br>명지병원 <span style='color:red;'>격리</span>",
      "address2": " 1월 26일부터 자가격리<br>명지병원 <span style='color:red;'>격리</span>",
      "visitDate": "2/11",
      "age": "30",
      "nation": "CN",
      "gender": "F",
      "date": "2/11",
      "contact": "1"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.573067,
        "lng": 127.015951
      },
      "address": "동묘앞역 출발",
      "address2": "동묘앞역 출발",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.575981,
        "lng": 127.024678
      },
      "address": "신설동역 도착(15:53~15:57)",
      "address2": "신설동역 도착(15:53~15:57)",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.575981,
        "lng": 127.024678
      },
      "address": "신설동역 출발",
      "address2": "신설동역 출발",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.573067,
        "lng": 127.015951
      },
      "address": "동묘앞역 도착(21:36~21:46)",
      "address2": "동묘앞역 도착(21:36~21:46)",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.571721,
        "lng": 127.010896
      },
      "address": "동대문역 출발",
      "address2": "동대문역 출발",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.759448,
        "lng": 127.042167
      },
      "address": "녹양역 도착(11:41~12:41)",
      "address2": "녹양역 도착(11:41~12:41)",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.759448,
        "lng": 127.042167
      },
      "address": "녹양역 출발(11:41~12:41)",
      "address2": "녹양역 출발(11:41~12:41)",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.571721,
        "lng": 127.010896
      },
      "address": "동대문역 도착(12:43~13:38)",
      "address2": "동대문역 도착(12:43~13:38)",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.575739,
        "lng": 127.015399
      },
      "address": "서울시 종로구 소재 의료기관(신중호내과의원) 방문",
      "address2": "서울시 종로구 소재 의료기관(신중호내과의원) 방문",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.57239,
        "lng": 127.013899
      },
      "address": "서울시 종로구 소재 약국(보람약국) 방문",
      "address2": "서울시 종로구 소재 약국(보람약국) 방문",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.572596,
        "lng": 127.01527
      },
      "address": "종로구 소재 의료기관(강북서울외과의원) 방문",
      "address2": "종로구 소재 의료기관(강북서울외과의원) 방문",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.575739,
        "lng": 127.015399
      },
      "address": "서울시 종로구 소재 의료기관(신중호내과의원) 방문",
      "address2": "서울시 종로구 소재 의료기관(신중호내과의원) 방문",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.948023,
        "lng": 127.061052
      },
      "address": "소요산역 이동",
      "address2": "소요산역 이동",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.572596,
        "lng": 127.01527
      },
      "address": "종로구 소재 의료기관(강북서울외과의원) 방문",
      "address2": "종로구 소재 의료기관(강북서울외과의원) 방문",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.573326,
        "lng": 127.015311
      },
      "address": "종로구 소재 약국(봄약국) 방문",
      "address2": "종로구 소재 약국(봄약국) 방문",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.572596,
        "lng": 127.01527
      },
      "address": "종로구 소재 의료기관(강북서울외과의원) 방문",
      "address2": "종로구 소재 의료기관(강북서울외과의원) 방문",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.57239,
        "lng": 127.013899
      },
      "address": "서울시 종로구 소재 약국(보람약국) 방문",
      "address2": "서울시 종로구 소재 약국(보람약국) 방문",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.575879,
        "lng": 127.024495
      },
      "address": "신설동역 출발",
      "address2": "신설동역 출발",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.843309,
        "lng": 127.061543
      },
      "address": "덕정역 도착(14:04~14:53)",
      "address2": "덕정역 도착(14:04~14:53)",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.843309,
        "lng": 127.061543
      },
      "address": "덕정역 출발",
      "address2": "덕정역 출발",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.572925,
        "lng": 127.015772
      },
      "address": "동묘앞역 도착(14:58~16:14)",
      "address2": "동묘앞역 도착(14:58~16:14)",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.572596,
        "lng": 127.01527
      },
      "address": "종로구 소재 의료기관(강북서울외과의원) 방문",
      "address2": "종로구 소재 의료기관(강북서울외과의원) 방문",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.572596,
        "lng": 127.01527
      },
      "address": "종로구 소재 의료기관(강북서울외과의원) 방문",
      "address2": "종로구 소재 의료기관(강북서울외과의원) 방문",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.573326,
        "lng": 127.015311
      },
      "address": "종로구 소재 약국(봄약국) 방문",
      "address2": "종로구 소재 약국(봄약국) 방문",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.579471,
        "lng": 127.015224
      },
      "address": "창신역 - 봉화산역 왕복이동",
      "address2": "창신역 - 봉화산역 왕복이동",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.617076,
        "lng": 127.091603
      },
      "address": "창신역 - 봉화산역 왕복이동",
      "address2": "창신역 - 봉화산역 왕복이동",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.572596,
        "lng": 127.01527
      },
      "address": "종로구 소재 의료기관(강북서울외과의원) 방문",
      "address2": "종로구 소재 의료기관(강북서울외과의원) 방문",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.587055,
        "lng": 127.02683
      },
      "address": "고려대안암 병원에서 검사 후 양성판정",
      "address2": "고려대안암 병원에서 검사 후 양성판정",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 29,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.579678,
        "lng": 126.998945
      },
      "address": "서울대 병원 <span style='color:red;'>격리</span>",
      "address2": "서울대 병원 <span style='color:red;'>격리</span>",
      "visitDate": "2/4",
      "age": "82",
      "nation": "KR",
      "gender": "M",
      "date": "2/4",
      "contact": "115"
    },
    {
      "idx": 30,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.579541,
        "lng": 126.999305
      },
      "address": "종로구 소재 의료기관(서울대학교병원 외래) 방문",
      "address2": "종로구 소재 의료기관(서울대학교병원 외래) 방문",
      "visitDate": "2/8",
      "age": "68",
      "nation": "KR",
      "gender": "F",
      "date": "2/8",
      "contact": "27"
    },
    {
      "idx": 30,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.572596,
        "lng": 127.01527
      },
      "address": "종로구 소재 의료기관(강북서울외과의원) 방문",
      "address2": "종로구 소재 의료기관(강북서울외과의원) 방문",
      "visitDate": "2/8",
      "age": "68",
      "nation": "KR",
      "gender": "F",
      "date": "2/8",
      "contact": "27"
    },
    {
      "idx": 30,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.423537,
        "lng": 126.421426
      },
      "address": "지인들과 함께 인천시 중구 용유도 방문",
      "address2": "지인들과 함께 인천시 중구 용유도 방문",
      "visitDate": "2/8",
      "age": "68",
      "nation": "KR",
      "gender": "F",
      "date": "2/8",
      "contact": "27"
    },
    {
      "idx": 30,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.570719,
        "lng": 126.675649
      },
      "address": "경인아라뱃길 방문",
      "address2": "경인아라뱃길 방문",
      "visitDate": "2/8",
      "age": "68",
      "nation": "KR",
      "gender": "F",
      "date": "2/8",
      "contact": "27"
    },
    {
      "idx": 30,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.574541,
        "lng": 127.015927
      },
      "address": "종로구 소재 약국(단골온누리약국) 방문",
      "address2": "종로구 소재 약국(단골온누리약국) 방문",
      "visitDate": "2/8",
      "age": "68",
      "nation": "KR",
      "gender": "F",
      "date": "2/8",
      "contact": "27"
    },
    {
      "idx": 30,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.572499,
        "lng": 127.013268
      },
      "address": "종로구 소재 식당(명륜진사갈비 서울동묘점) 방문",
      "address2": "종로구 소재 식당(명륜진사갈비 서울동묘점) 방문",
      "visitDate": "2/8",
      "age": "68",
      "nation": "KR",
      "gender": "F",
      "date": "2/8",
      "contact": "27"
    },
    {
      "idx": 30,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.572793,
        "lng": 127.015975
      },
      "address": "종로구 소재 카페(스타벅스 동묘앞역점) 방문",
      "address2": "종로구 소재 카페(스타벅스 동묘앞역점) 방문",
      "visitDate": "2/8",
      "age": "68",
      "nation": "KR",
      "gender": "F",
      "date": "2/8",
      "contact": "27"
    },
    {
      "idx": 30,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.572596,
        "lng": 127.01527
      },
      "address": "종로구 소재 의료기관(강북서울외과의원) 방문",
      "address2": "종로구 소재 의료기관(강북서울외과의원) 방문",
      "visitDate": "2/8",
      "age": "68",
      "nation": "KR",
      "gender": "F",
      "date": "2/8",
      "contact": "27"
    },
    {
      "idx": 30,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.574541,
        "lng": 127.015927
      },
      "address": "종로구 소재 약국(단골온누리약국) 방문",
      "address2": "종로구 소재 약국(단골온누리약국) 방문",
      "visitDate": "2/8",
      "age": "68",
      "nation": "KR",
      "gender": "F",
      "date": "2/8",
      "contact": "27"
    },
    {
      "idx": 30,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.587055,
        "lng": 127.02683
      },
      "address": "29번째 확진자 간호를 위해 고려대 안암병원 방문",
      "address2": "29번째 확진자 간호를 위해 고려대 안암병원 방문",
      "visitDate": "2/8",
      "age": "68",
      "nation": "KR",
      "gender": "F",
      "date": "2/8",
      "contact": "27"
    },
    {
      "idx": 30,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.579678,
        "lng": 126.998945
      },
      "address": "서울대 병원 <span style='color:red;'>격리</span>",
      "address2": "서울대 병원 <span style='color:red;'>격리</span>",
      "visitDate": "2/8",
      "age": "68",
      "nation": "KR",
      "gender": "F",
      "date": "2/8",
      "contact": "27"
    },
    {
      "idx": 31,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.505066,
        "lng": 127.047281
      },
      "address": "서울 대치동 C클럽 본사에서 열린 행사에 참석",
      "address2": "서울 대치동 C클럽 본사에서 열린 행사에 참석",
      "visitDate": "",
      "age": "61",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": "166"
    },
    {
      "idx": 31,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.875115,
        "lng": 128.627581
      },
      "address": "동구소재 C클럽 직장 출근",
      "address2": "동구소재 C클럽 직장 출근",
      "visitDate": "",
      "age": "61",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": "166"
    },
    {
      "idx": 31,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.858512,
        "lng": 128.635278
      },
      "address": "대구 의료기관에서(새로난한방병원) 외래진료",
      "address2": "대구 의료기관에서(새로난한방병원) 외래진료",
      "visitDate": "",
      "age": "61",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": "166"
    },
    {
      "idx": 31,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.839821,
        "lng": 128.566553
      },
      "address": "신천지예수교회다대오지성전에서 예배",
      "address2": "신천지예수교회다대오지성전에서 예배",
      "visitDate": "",
      "age": "61",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": "166"
    },
    {
      "idx": 31,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.882409,
        "lng": 128.662136
      },
      "address": "동구 소재 호텔(퀸벨호텔) 뷔페에서 점심 식사",
      "address2": "동구 소재 호텔(퀸벨호텔) 뷔페에서 점심 식사",
      "visitDate": "",
      "age": "61",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": "166"
    },
    {
      "idx": 31,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.839821,
        "lng": 128.566553
      },
      "address": "신천지예수교회다대오지성전에서 예배",
      "address2": "신천지예수교회다대오지성전에서 예배",
      "visitDate": "",
      "age": "61",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": "166"
    },
    {
      "idx": 31,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.844728,
        "lng": 128.612261
      },
      "address": "대구 수성구 보건소에서 검사 실시 후 양성",
      "address2": "대구 수성구 보건소에서 검사 실시 후 양성",
      "visitDate": "",
      "age": "61",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": "166"
    },
    {
      "idx": 31,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.859594,
        "lng": 128.540617
      },
      "address": "대구 의료원 <span style='color:red;'>격리</span>",
      "address2": "대구 의료원 <span style='color:red;'>격리</span>",
      "visitDate": "",
      "age": "61",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": "166"
    },
    {
      "idx": 32,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.351384,
        "lng": 127.123507
      },
      "address": "분당서울대병원 <span style='color:red;'>격리</span>",
      "address2": "분당서울대병원 <span style='color:red;'>격리</span>",
      "visitDate": "2/19",
      "age": "11",
      "nation": "KR",
      "gender": "F",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 33,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.866696,
        "lng": 128.590597
      },
      "address": "현대백화점 대구점 방문(오후 1시경)",
      "address2": "현대백화점 대구점 방문(오후 1시경)",
      "visitDate": "2/19",
      "age": "40",
      "nation": "KR",
      "gender": "F",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 33,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.859629,
        "lng": 128.540596
      },
      "address": "대구의료원 <span style='color:red;'>격리</span>",
      "address2": "대구의료원 <span style='color:red;'>격리</span>",
      "visitDate": "2/19",
      "age": "40",
      "nation": "KR",
      "gender": "F",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 34,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.859629,
        "lng": 128.540596
      },
      "address": "대구의료원 <span style='color:red;'>격리</span>",
      "address2": "대구의료원 <span style='color:red;'>격리</span>",
      "visitDate": "2/19",
      "age": "24",
      "nation": "KR",
      "gender": "M",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 35,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.859629,
        "lng": 128.540596
      },
      "address": "대구의료원 <span style='color:red;'>격리</span>",
      "address2": "대구의료원 <span style='color:red;'>격리</span>",
      "visitDate": "2/19",
      "age": "26",
      "nation": "KR",
      "gender": "F",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 36,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.859629,
        "lng": 128.540596
      },
      "address": "대구의료원 <span style='color:red;'>격리</span>",
      "address2": "대구의료원 <span style='color:red;'>격리</span>",
      "visitDate": "2/19",
      "age": "48",
      "nation": "KR",
      "gender": "F",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 37,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.932453,
        "lng": 128.872049
      },
      "address": "영천 금호의원 진료",
      "address2": "영천 금호의원 진료",
      "visitDate": "2/16",
      "age": "47",
      "nation": "KR",
      "gender": "M",
      "date": "2/16",
      "contact": ""
    },
    {
      "idx": 37,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.965198,
        "lng": 128.938671
      },
      "address": "김인환내과의원 진료",
      "address2": "김인환내과의원 진료",
      "visitDate": "2/16",
      "age": "47",
      "nation": "KR",
      "gender": "M",
      "date": "2/16",
      "contact": ""
    },
    {
      "idx": 37,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.965198,
        "lng": 128.938671
      },
      "address": "김인환내과의원 재진료",
      "address2": "김인환내과의원 재진료",
      "visitDate": "2/16",
      "age": "47",
      "nation": "KR",
      "gender": "M",
      "date": "2/16",
      "contact": ""
    },
    {
      "idx": 37,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.961186,
        "lng": 128.927832
      },
      "address": "영제한의원 진료",
      "address2": "영제한의원 진료",
      "visitDate": "2/16",
      "age": "47",
      "nation": "KR",
      "gender": "M",
      "date": "2/16",
      "contact": ""
    },
    {
      "idx": 37,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.866029,
        "lng": 128.60506
      },
      "address": "경북대병원 <span style='color:red;'>격리</span>",
      "address2": "경북대병원 <span style='color:red;'>격리</span>",
      "visitDate": "2/16",
      "age": "47",
      "nation": "KR",
      "gender": "M",
      "date": "2/16",
      "contact": ""
    },
    {
      "idx": 38,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.866029,
        "lng": 128.60506
      },
      "address": "경북대병원 <span style='color:red;'>격리</span>",
      "address2": "경북대병원 <span style='color:red;'>격리</span>",
      "visitDate": "2/19",
      "age": "56",
      "nation": "KR",
      "gender": "F",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 39,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.858249,
        "lng": 129.196778
      },
      "address": "동국대경주병원 <span style='color:red;'>격리</span>",
      "address2": "동국대경주병원 <span style='color:red;'>격리</span>",
      "visitDate": "",
      "age": "61",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 40,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.539848,
        "lng": 127.053015
      },
      "address": "이마트 성수점 방문",
      "address2": "이마트 성수점 방문",
      "visitDate": "2/10",
      "age": "77",
      "nation": "KR",
      "gender": "M",
      "date": "2/10",
      "contact": "8"
    },
    {
      "idx": 40,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.557378,
        "lng": 127.040081
      },
      "address": "포보스 엔터식스 한양대점 방문",
      "address2": "포보스 엔터식스 한양대점 방문",
      "visitDate": "2/10",
      "age": "77",
      "nation": "KR",
      "gender": "M",
      "date": "2/10",
      "contact": "8"
    },
    {
      "idx": 40,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.588233,
        "lng": 127.063556
      },
      "address": "삼육서울병원 장례식장 방문",
      "address2": "삼육서울병원 장례식장 방문",
      "visitDate": "2/10",
      "age": "77",
      "nation": "KR",
      "gender": "M",
      "date": "2/10",
      "contact": "8"
    },
    {
      "idx": 40,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.559702,
        "lng": 127.04396
      },
      "address": "한양대병원 외래방문",
      "address2": "한양대병원 외래방문",
      "visitDate": "2/10",
      "age": "77",
      "nation": "KR",
      "gender": "M",
      "date": "2/10",
      "contact": "8"
    },
    {
      "idx": 40,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.559702,
        "lng": 127.04396
      },
      "address": "한양대병원 선별진료소에서 최종 양성<br>국가지정병원이송",
      "address2": "한양대병원 선별진료소에서 최종 양성<br>국가지정병원이송",
      "visitDate": "2/10",
      "age": "77",
      "nation": "KR",
      "gender": "M",
      "date": "2/10",
      "contact": "8"
    },
    {
      "idx": 40,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.567241,
        "lng": 127.005702
      },
      "address": "국립중앙의료원 <span style='color:red;'>격리</span>",
      "address2": "국립중앙의료원 <span style='color:red;'>격리</span>",
      "visitDate": "2/10",
      "age": "77",
      "nation": "KR",
      "gender": "M",
      "date": "2/10",
      "contact": "8"
    },
    {
      "idx": 41,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.858249,
        "lng": 129.196778
      },
      "address": "동국대경주병원 <span style='color:red;'>격리</span>",
      "address2": "동국대경주병원 <span style='color:red;'>격리</span>",
      "visitDate": "2/19",
      "age": "70",
      "nation": "KR",
      "gender": "F",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 42,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.859629,
        "lng": 128.540596
      },
      "address": "대구의료원 <span style='color:red;'>격리</span>",
      "address2": "대구의료원 <span style='color:red;'>격리</span>",
      "visitDate": "2/19",
      "age": "28",
      "nation": "KR",
      "gender": "F",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 43,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.854171,
        "lng": 128.480071
      },
      "address": "계명대동산병원 <span style='color:red;'>격리</span>",
      "address2": "계명대동산병원 <span style='color:red;'>격리</span>",
      "visitDate": "2/19",
      "age": "58",
      "nation": "KR",
      "gender": "F",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 44,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.866029,
        "lng": 128.60506
      },
      "address": "경북대병원 <span style='color:red;'>격리</span>",
      "address2": "경북대병원 <span style='color:red;'>격리</span>",
      "visitDate": "2/19",
      "age": "46",
      "nation": "KR",
      "gender": "F",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 45,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.859629,
        "lng": 128.540596
      },
      "address": "대구의료원 <span style='color:red;'>격리</span>",
      "address2": "대구의료원 <span style='color:red;'>격리</span>",
      "visitDate": "2/19",
      "age": "53",
      "nation": "KR",
      "gender": "F",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 46,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.859629,
        "lng": 128.540596
      },
      "address": "대구의료원 <span style='color:red;'>격리</span>",
      "address2": "대구의료원 <span style='color:red;'>격리</span>",
      "visitDate": "2/19",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 47,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.859629,
        "lng": 128.540596
      },
      "address": "대구의료원 <span style='color:red;'>격리</span>",
      "address2": "대구의료원 <span style='color:red;'>격리</span>",
      "visitDate": "2/19",
      "age": "63",
      "nation": "KR",
      "gender": "F",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 48,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.956615,
        "lng": 128.564272
      },
      "address": "칠곡경북대병원 <span style='color:red;'>격리</span>",
      "address2": "칠곡경북대병원 <span style='color:red;'>격리</span>",
      "visitDate": "2/19",
      "age": "72",
      "nation": "KR",
      "gender": "F",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 49,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.86622,
        "lng": 128.60446
      },
      "address": "경북대병원 <span style='color:red;'>격리</span>",
      "address2": "경북대병원 <span style='color:red;'>격리</span>",
      "visitDate": "2/19",
      "age": "58",
      "nation": "KR",
      "gender": "F",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 50,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.84736,
        "lng": 128.584848
      },
      "address": "영남대병원 <span style='color:red;'>격리</span>",
      "address2": "영남대병원 <span style='color:red;'>격리</span>",
      "visitDate": "2/19",
      "age": "76",
      "nation": "KR",
      "gender": "M",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 51,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.854171,
        "lng": 128.480071
      },
      "address": "계명대동산병원 <span style='color:red;'>격리</span>",
      "address2": "계명대동산병원 <span style='color:red;'>격리</span>",
      "visitDate": "",
      "age": "61",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 52,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "2/19",
      "age": "24",
      "nation": "KR",
      "gender": "M",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 53,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.859629,
        "lng": 128.540596
      },
      "address": "대구의료원 <span style='color:red;'>격리</span>",
      "address2": "대구의료원 <span style='color:red;'>격리</span>",
      "visitDate": "2/19",
      "age": "38",
      "nation": "KR",
      "gender": "F",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 54,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.034762,
        "lng": 129.355059
      },
      "address": "포항의료원 <span style='color:red;'>격리</span>",
      "address2": "포항의료원 <span style='color:red;'>격리</span>",
      "visitDate": "",
      "age": "57",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 55,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.034762,
        "lng": 129.355059
      },
      "address": "포항의료원 <span style='color:red;'>격리</span>",
      "address2": "포항의료원 <span style='color:red;'>격리</span>",
      "visitDate": "",
      "age": "59",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 56,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.57642,
        "lng": 126.972759
      },
      "address": "하니이비인후과 방문(2/6-2/17)",
      "address2": "하니이비인후과 방문(2/6-2/17)",
      "visitDate": "2/17",
      "age": "75",
      "nation": "KR",
      "gender": "F",
      "date": "2/17",
      "contact": ""
    },
    {
      "idx": 56,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.593919,
        "lng": 127.051291
      },
      "address": "경희대병원에 진료를 받기 위해 내원",
      "address2": "경희대병원에 진료를 받기 위해 내원",
      "visitDate": "2/17",
      "age": "75",
      "nation": "KR",
      "gender": "F",
      "date": "2/17",
      "contact": ""
    },
    {
      "idx": 56,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.581837,
        "lng": 126.969186
      },
      "address": "종로구 보건소에서 진료",
      "address2": "종로구 보건소에서 진료",
      "visitDate": "2/17",
      "age": "75",
      "nation": "KR",
      "gender": "F",
      "date": "2/17",
      "contact": ""
    },
    {
      "idx": 56,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.612806,
        "lng": 127.098134
      },
      "address": "서울의료원 <span style='color:red;'>격리</span>",
      "address2": "서울의료원 <span style='color:red;'>격리</span>",
      "visitDate": "2/17",
      "age": "75",
      "nation": "KR",
      "gender": "F",
      "date": "2/17",
      "contact": ""
    },
    {
      "idx": 57,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "2/19",
      "age": "30",
      "nation": "KR",
      "gender": "M",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 58,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "2/19",
      "age": "26",
      "nation": "KR",
      "gender": "F",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 59,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "2/19",
      "age": "34",
      "nation": "KR",
      "gender": "F",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 60,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "2/19",
      "age": "59",
      "nation": "KR",
      "gender": "F",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 61,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "2/19",
      "age": "58",
      "nation": "KR",
      "gender": "F",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 62,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "2/19",
      "age": "60",
      "nation": "KR",
      "gender": "M",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 63,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.841673,
        "lng": 128.704953
      },
      "address": "시지 닥터필의원 방문",
      "address2": "시지 닥터필의원 방문",
      "visitDate": "",
      "age": "29",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 63,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "대구메트로병원 방문(주소확인중)",
      "address2": "대구메트로병원 방문(주소확인중)",
      "visitDate": "",
      "age": "29",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 63,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.860062,
        "lng": 128.613893
      },
      "address": "대구 예일연합이비인후과 방문",
      "address2": "대구 예일연합이비인후과 방문",
      "visitDate": "",
      "age": "29",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 63,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "미래연합의원 방문 (주소확인중)",
      "address2": "미래연합의원 방문 (주소확인중)",
      "visitDate": "",
      "age": "29",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 63,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.824947,
        "lng": 128.743321
      },
      "address": "경산시 보건소 선별진료소 방문",
      "address2": "경산시 보건소 선별진료소 방문",
      "visitDate": "",
      "age": "29",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 63,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.034762,
        "lng": 129.355059
      },
      "address": "포항의료원 격리",
      "address2": "포항의료원 격리",
      "visitDate": "",
      "age": "29",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 64,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "2/19",
      "age": "59",
      "nation": "KR",
      "gender": "F",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 65,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.866029,
        "lng": 128.60506
      },
      "address": "경북대병원 <span style='color:red;'>격리</span>",
      "address2": "경북대병원 <span style='color:red;'>격리</span>",
      "visitDate": "2/19",
      "age": "50",
      "nation": "KR",
      "gender": "F",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 66,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "2/19",
      "age": "22",
      "nation": "KR",
      "gender": "M",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 67,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "2/19",
      "age": "30",
      "nation": "KR",
      "gender": "F",
      "date": "2/19",
      "contact": ""
    },
    {
      "idx": 68,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "2/20",
      "age": "56",
      "nation": "KR",
      "gender": "F",
      "date": "2/20",
      "contact": ""
    },
    {
      "idx": 69,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "",
      "age": "29",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 70,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.83678,
        "lng": 128.55786
      },
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "",
      "age": "48",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 71,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "",
      "age": "56",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 72,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "",
      "age": "39",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 73,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.813036,
        "lng": 128.732551
      },
      "address": "혜화연합의원(옥곡동) 내원 후 보건소 선별진료소 방문",
      "address2": "혜화연합의원(옥곡동) 내원 후 보건소 선별진료소 방문",
      "visitDate": "",
      "age": "19",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 73,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.034762,
        "lng": 129.355059
      },
      "address": "포항의료원 격리",
      "address2": "포항의료원 격리",
      "visitDate": "",
      "age": "19",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 74,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "",
      "age": "49",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 75,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "",
      "age": "23",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 76,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "",
      "age": "36",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 77,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "",
      "age": "57",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 78,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "",
      "age": "55",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 79,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "",
      "age": "22",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 80,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "",
      "age": "34",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 81,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "",
      "age": "65",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 82,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "",
      "age": "64",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 83,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "",
      "age": "76",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 84,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.83678,
        "lng": 128.55786
      },
      "address": "대구서부터미널에서 포항으로 이동(12:50)",
      "address2": "대구서부터미널에서 포항으로 이동(12:50)",
      "visitDate": "",
      "age": "48",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 84,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.017759,
        "lng": 129.345628
      },
      "address": "대잠아델리아 방문(13:40)",
      "address2": "대잠아델리아 방문(13:40)",
      "visitDate": "",
      "age": "48",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 84,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.06938,
        "lng": 129.380109
      },
      "address": "자택 도착(22:08)",
      "address2": "자택 도착(22:08)",
      "visitDate": "",
      "age": "48",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 84,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "장성동에서 버스로 대잠동으로 이동",
      "address2": "장성동에서 버스로 대잠동으로 이동",
      "visitDate": "",
      "age": "48",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 84,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "북부해수욕장에서 101번 버스 탑승",
      "address2": "북부해수욕장에서 101번 버스 탑승",
      "visitDate": "",
      "age": "48",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 84,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "죽도시장에서 108번 버스 환승",
      "address2": "죽도시장에서 108번 버스 환승",
      "visitDate": "",
      "age": "48",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 84,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.018148,
        "lng": 129.341997
      },
      "address": "코아이빈후과 방문(14:22)",
      "address2": "코아이빈후과 방문(14:22)",
      "visitDate": "",
      "age": "48",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 84,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.018148,
        "lng": 129.341997
      },
      "address": "미래건강약국 방문(14:44)",
      "address2": "미래건강약국 방문(14:44)",
      "visitDate": "",
      "age": "48",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 84,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.06938,
        "lng": 129.380109
      },
      "address": "자택 도착(15:30)",
      "address2": "자택 도착(15:30)",
      "visitDate": "",
      "age": "48",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 84,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "대잠동에서 장성동으로 오는 버스 이용(130번, 105번)",
      "address2": "대잠동에서 장성동으로 오는 버스 이용(130번, 105번)",
      "visitDate": "",
      "age": "48",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 84,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.017839,
        "lng": 129.362102
      },
      "address": "개인차량으로 세명기독병원 방문<br>개인차량으로 자택 귀가",
      "address2": "개인차량으로 세명기독병원 방문<br>개인차량으로 자택 귀가",
      "visitDate": "",
      "age": "48",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 84,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "자가격리 중 코로나19 확진 판정",
      "address2": "자가격리 중 코로나19 확진 판정",
      "visitDate": "",
      "age": "48",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 84,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.034762,
        "lng": 129.355059
      },
      "address": "포항의료원 <span style='color:red;'>격리</span>",
      "address2": "포항의료원 <span style='color:red;'>격리</span>",
      "visitDate": "",
      "age": "48",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 85,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.122683,
        "lng": 128.126468
      },
      "address": "김천의료원 격리",
      "address2": "김천의료원 격리",
      "visitDate": "",
      "age": "46",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 86,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.81444,
        "lng": 128.728348
      },
      "address": "아틀리에빈 옥곡점 방문",
      "address2": "아틀리에빈 옥곡점 방문",
      "visitDate": "",
      "age": "55",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 86,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.817049,
        "lng": 128.759688
      },
      "address": "경산 세무서 방문",
      "address2": "경산 세무서 방문",
      "visitDate": "",
      "age": "55",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 86,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.825057,
        "lng": 128.741543
      },
      "address": "경산 시청 방문",
      "address2": "경산 시청 방문",
      "visitDate": "",
      "age": "55",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 86,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.829161,
        "lng": 128.73628
      },
      "address": "롤링핀 경산점 방문",
      "address2": "롤링핀 경산점 방문",
      "visitDate": "",
      "age": "55",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 86,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.122659,
        "lng": 128.126482
      },
      "address": "김천의료원 격리",
      "address2": "김천의료원 격리",
      "visitDate": "",
      "age": "55",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 87,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.824255,
        "lng": 128.737729
      },
      "address": "김동희 속내과의원 방문",
      "address2": "김동희 속내과의원 방문",
      "visitDate": "",
      "age": "29",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 87,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.824229,
        "lng": 128.737793
      },
      "address": "새별약국 방문",
      "address2": "새별약국 방문",
      "visitDate": "",
      "age": "29",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 87,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.826328,
        "lng": 128.738082
      },
      "address": "촌순두부청국장전문 방문",
      "address2": "촌순두부청국장전문 방문",
      "visitDate": "",
      "age": "29",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 87,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.82726,
        "lng": 128.73673
      },
      "address": "스타벅스 경산중방DT점 방문",
      "address2": "스타벅스 경산중방DT점 방문",
      "visitDate": "",
      "age": "29",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 87,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "보건소 유선 통화 중 발열 및 인후통 호소, 자택방문검사",
      "address2": "보건소 유선 통화 중 발열 및 인후통 호소, 자택방문검사",
      "visitDate": "",
      "age": "29",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 87,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "보건소 유선 통화 중 발열 및 인후통 호소, 자택방문검사",
      "address2": "보건소 유선 통화 중 발열 및 인후통 호소, 자택방문검사",
      "visitDate": "",
      "age": "29",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 87,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "김천의료원 격리",
      "address2": "김천의료원 격리",
      "visitDate": "",
      "age": "29",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 88,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동선 확인중",
      "address2": "동선 확인중",
      "visitDate": "",
      "age": "79",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 89,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.878286,
        "lng": 128.630244
      },
      "address": "동대구 터미널 방문",
      "address2": "동대구 터미널 방문",
      "visitDate": "",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 89,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동성로 술집 -> 북성로 음식점 -> 인근 모텔",
      "address2": "동성로 술집 -> 북성로 음식점 -> 인근 모텔",
      "visitDate": "",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 89,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "수성구 음식점 -> PC방(14:00~16:00) -> 코인 노래방 -> 동성로 술집",
      "address2": "수성구 음식점 -> PC방(14:00~16:00) -> 코인 노래방 -> 동성로 술집",
      "visitDate": "",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 89,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.878286,
        "lng": 128.630244
      },
      "address": "동대구 터미널(7:30-10:30) 이용",
      "address2": "동대구 터미널(7:30-10:30) 이용",
      "visitDate": "",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 89,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.835771,
        "lng": 127.129118
      },
      "address": "전주고속터미널 (11:00) 도착<br>도보로 서신동 빽다방 이용",
      "address2": "전주고속터미널 (11:00) 도착<br>도보로 서신동 빽다방 이용",
      "visitDate": "",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 89,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.858123,
        "lng": 127.086091
      },
      "address": "팔복동 KS공업사 지하1층(14:00-15:00)",
      "address2": "팔복동 KS공업사 지하1층(14:00-15:00)",
      "visitDate": "",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 89,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.84395,
        "lng": 127.110583
      },
      "address": "하가지구 푸라닭 이용(20:00-21:00)",
      "address2": "하가지구 푸라닭 이용(20:00-21:00)",
      "visitDate": "",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 89,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.861459,
        "lng": 127.121145
      },
      "address": "송천동 원이비인후과 (16:00-17:00) 방문",
      "address2": "송천동 원이비인후과 (16:00-17:00) 방문",
      "visitDate": "",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 89,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.806854,
        "lng": 127.115566
      },
      "address": "효자동 CGV 이철헤어컷(20:00)",
      "address2": "효자동 CGV 이철헤어컷(20:00)",
      "visitDate": "",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 89,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.843795,
        "lng": 127.127505
      },
      "address": "전북대 쓰리팝PC방 이용",
      "address2": "전북대 쓰리팝PC방 이용",
      "visitDate": "",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 89,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.843795,
        "lng": 127.127505
      },
      "address": "전북대 쓰리팝PC방 이용(15:00-18:00)",
      "address2": "전북대 쓰리팝PC방 이용(15:00-18:00)",
      "visitDate": "",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 89,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "송천동 스타벅스 방문",
      "address2": "송천동 스타벅스 방문",
      "visitDate": "",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 89,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.826098,
        "lng": 127.176045
      },
      "address": "아중리 청혜참치(19:30) 이용",
      "address2": "아중리 청혜참치(19:30) 이용",
      "visitDate": "",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 89,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.854273,
        "lng": 127.120135
      },
      "address": "송천롯데마트(20:00-20:30)",
      "address2": "송천롯데마트(20:00-20:30)",
      "visitDate": "",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 89,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.950936,
        "lng": 126.715354
      },
      "address": "군산 대박주유소 방문",
      "address2": "군산 대박주유소 방문",
      "visitDate": "",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 89,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.962723,
        "lng": 126.697251
      },
      "address": "고래설렁탕 방문",
      "address2": "고래설렁탕 방문",
      "visitDate": "",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 89,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.847292,
        "lng": 127.140611
      },
      "address": "전북대병원 <span style='color:red;'>격리</span>",
      "address2": "전북대병원 <span style='color:red;'>격리</span>",
      "visitDate": "",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 90,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.613102,
        "lng": 127.098658
      },
      "address": "서울의료원 <span style='color:red;'>격리</span>",
      "address2": "서울의료원 <span style='color:red;'>격리</span>",
      "visitDate": "",
      "age": "79",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 91,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.821274,
        "lng": 128.824283
      },
      "address": "자인초등학교 방문",
      "address2": "자인초등학교 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 91,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.819082,
        "lng": 128.822929
      },
      "address": "자택 및 영미사진관 머뭄(2/18-2/20)",
      "address2": "자택 및 영미사진관 머뭄(2/18-2/20)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 91,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.820286,
        "lng": 128.82388
      },
      "address": "자인농협 방문",
      "address2": "자인농협 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 91,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "보건소 선별진료실 방문",
      "address2": "보건소 선별진료실 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 92,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.567343,
        "lng": 127.005648
      },
      "address": "국립중앙의료원 <span style='color:red;'>격리</span>",
      "address2": "국립중앙의료원 <span style='color:red;'>격리</span>",
      "visitDate": "",
      "age": "28",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 93,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.819459,
        "lng": 128.727495
      },
      "address": "경산역 출발(14:38)",
      "address2": "경산역 출발(14:38)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 93,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.123448,
        "lng": 128.114656
      },
      "address": "김천역 경유(15:49)",
      "address2": "김천역 경유(15:49)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 93,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.410458,
        "lng": 128.164155
      },
      "address": "상주역 도착(16:30)",
      "address2": "상주역 도착(16:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 93,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.420284,
        "lng": 128.159749
      },
      "address": "성모병원입구, 열체크(16:50)",
      "address2": "성모병원입구, 열체크(16:50)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 93,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.416707,
        "lng": 128.150557
      },
      "address": "상주보건소 선별진료소 도착(17:20)",
      "address2": "상주보건소 선별진료소 도착(17:20)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 93,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.417096,
        "lng": 128.150847
      },
      "address": "상주 행림약국 방문후 자택 귀가",
      "address2": "상주 행림약국 방문후 자택 귀가",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 93,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.568004,
        "lng": 128.731964
      },
      "address": "안동 의료원 이송 및 치료중",
      "address2": "안동 의료원 이송 및 치료중",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 94,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.460459,
        "lng": 126.44068
      },
      "address": "인천공항 도착",
      "address2": "인천공항 도착",
      "visitDate": "",
      "age": "59",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 94,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.657708,
        "lng": 128.452978
      },
      "address": "예천보건소 선별진료소 방문",
      "address2": "예천보건소 선별진료소 방문",
      "visitDate": "",
      "age": "59",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 94,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.567994,
        "lng": 128.731753
      },
      "address": "안동의료원 이송 및 치료",
      "address2": "안동의료원 이송 및 치료",
      "visitDate": "",
      "age": "59",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 95,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.127368,
        "lng": 126.896252
      },
      "address": "주월동카페 '소요' 방문",
      "address2": "주월동카페 '소요' 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 95,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.135462,
        "lng": 126.895629
      },
      "address": "백운동 음식점 '최가박당' 방문",
      "address2": "백운동 음식점 '최가박당' 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 95,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.133058,
        "lng": 126.902449
      },
      "address": "남구보건소 방문",
      "address2": "남구보건소 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 95,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.126229,
        "lng": 126.911115
      },
      "address": "봉선동 '사계진미숯불닭갈비' 방문",
      "address2": "봉선동 '사계진미숯불닭갈비' 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 95,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.152283,
        "lng": 126.889923
      },
      "address": "서구보건소 진료",
      "address2": "서구보건소 진료",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 96,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.145595,
        "lng": 126.923217
      },
      "address": "월산동 학습관 방문 후 동구보건소 방문",
      "address2": "월산동 학습관 방문 후 동구보건소 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 96,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.126229,
        "lng": 126.911115
      },
      "address": "봉선동 '사계진미숯불닭갈비' 방문",
      "address2": "봉선동 '사계진미숯불닭갈비' 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 96,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "20일 자택 기거",
      "address2": "20일 자택 기거",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 97,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.1492,
        "lng": 126.926489
      },
      "address": "동명동 소재 빵집 방문",
      "address2": "동명동 소재 빵집 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 97,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "중흥동 헬스장 '중흥헬스' 방문",
      "address2": "중흥동 헬스장 '중흥헬스' 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 97,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.154714,
        "lng": 126.854335
      },
      "address": "치평동 음식점 '텐토' 방문",
      "address2": "치평동 음식점 '텐토' 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 97,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.208994,
        "lng": 126.878977
      },
      "address": "양산동 음식점 '양떼목장' 방문",
      "address2": "양산동 음식점 '양떼목장' 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 97,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "중흥동 헬스장 '중흥헬스' 방문",
      "address2": "중흥동 헬스장 '중흥헬스' 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 97,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "사무실 출근",
      "address2": "사무실 출근",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 97,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "고흥읍에 있는 실버대학으로 출장",
      "address2": "고흥읍에 있는 실버대학으로 출장",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 97,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 34.525682,
        "lng": 127.135891
      },
      "address": "전남고흥 음식점 '뚝배기식당' 방문",
      "address2": "전남고흥 음식점 '뚝배기식당' 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 97,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.173329,
        "lng": 126.91219
      },
      "address": "북구보건소 방문",
      "address2": "북구보건소 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 97,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.142094,
        "lng": 126.921635
      },
      "address": "전남대학교병원 <span style='color:red;'>격리</span>",
      "address2": "전남대학교병원 <span style='color:red;'>격리</span>",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 98,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.175689,
        "lng": 126.913875
      },
      "address": "용봉동 소재 포켓볼하우스 방문",
      "address2": "용봉동 소재 포켓볼하우스 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 98,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.170034,
        "lng": 126.910806
      },
      "address": "중흥동 소재 음식점 방문",
      "address2": "중흥동 소재 음식점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 98,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.165176,
        "lng": 126.914238
      },
      "address": "중흥동 소재 편의점 방문 후 자택 기거",
      "address2": "중흥동 소재 편의점 방문 후 자택 기거",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 98,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "보성군 문덕면 소재 버섯농장 방문",
      "address2": "보성군 문덕면 소재 버섯농장 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 98,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "보성군 문덕면 소재 버섯농장 방문",
      "address2": "보성군 문덕면 소재 버섯농장 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 98,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "화순 사평면 사평리 소재 음식점 방문",
      "address2": "화순 사평면 사평리 소재 음식점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 98,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.16138,
        "lng": 126.91672
      },
      "address": "홈플러스 계림점 방문 후 자택 기거",
      "address2": "홈플러스 계림점 방문 후 자택 기거",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 98,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "서구보건소에서 확진자A 접촉자로 연락받고 자가 격리",
      "address2": "서구보건소에서 확진자A 접촉자로 연락받고 자가 격리",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 99,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.899478,
        "lng": 128.638419
      },
      "address": "대구 국제공항 출발",
      "address2": "대구 국제공항 출발",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 99,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.509302,
        "lng": 126.491663
      },
      "address": "티웨이 항공 TW809 탑승",
      "address2": "티웨이 항공 TW809 탑승",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 99,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "택시 이용(20:31)",
      "address2": "택시 이용(20:31)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 99,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.512939,
        "lng": 126.503016
      },
      "address": "CU 제주 용해로점 방문(20:40)",
      "address2": "CU 제주 용해로점 방문(20:40)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 99,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "부대 복귀(22:00)",
      "address2": "부대 복귀(22:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 99,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "부대 내 생활",
      "address2": "부대 내 생활",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 99,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.490004,
        "lng": 126.485135
      },
      "address": "한라병원 선별진료소 방문",
      "address2": "한라병원 선별진료소 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 99,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.467106,
        "lng": 126.545745
      },
      "address": "제주대병원 이송",
      "address2": "제주대병원 이송",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 100,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.899478,
        "lng": 128.638419
      },
      "address": "대구 국제공항 출발 제주 입도",
      "address2": "대구 국제공항 출발 제주 입도",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 100,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.285128,
        "lng": 126.454557
      },
      "address": "서귀포 위호텔 근무",
      "address2": "서귀포 위호텔 근무",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 100,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "직원 기숙사 복귀",
      "address2": "직원 기숙사 복귀",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 100,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.285128,
        "lng": 126.454557
      },
      "address": "셔틀버스로 위호텔 출근",
      "address2": "셔틀버스로 위호텔 출근",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 100,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.252098,
        "lng": 126.423172
      },
      "address": "중문신내과의원 방문",
      "address2": "중문신내과의원 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 100,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.252098,
        "lng": 126.423172
      },
      "address": "중문신내과의원 방문",
      "address2": "중문신내과의원 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 100,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.254479,
        "lng": 126.565456
      },
      "address": "서귀포 열린병원 방문",
      "address2": "서귀포 열린병원 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 100,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.255031,
        "lng": 126.428428
      },
      "address": "CU오네뜨점 방문",
      "address2": "CU오네뜨점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 100,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.254479,
        "lng": 126.565456
      },
      "address": "서귀포 열린병원 방문",
      "address2": "서귀포 열린병원 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 100,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.467106,
        "lng": 126.545745
      },
      "address": "제주대병원 격리",
      "address2": "제주대병원 격리",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 101,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.48746,
        "lng": 127.101314
      },
      "address": "수서역에서 출발(SRT)(14:00-17:00)",
      "address2": "수서역에서 출발(SRT)(14:00-17:00)",
      "visitDate": "",
      "age": "50대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 101,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.115164,
        "lng": 129.041825
      },
      "address": "부산역 도착",
      "address2": "부산역 도착",
      "visitDate": "",
      "age": "50대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 101,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "자택 기거",
      "address2": "자택 기거",
      "visitDate": "",
      "age": "50대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 101,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.205766,
        "lng": 129.125581
      },
      "address": "장산 성당 방문(10:00-11:00)",
      "address2": "장산 성당 방문(10:00-11:00)",
      "visitDate": "",
      "age": "50대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 101,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.199116,
        "lng": 129.11915
      },
      "address": "반여동 장산명가 방문(11:00-12:40)",
      "address2": "반여동 장산명가 방문(11:00-12:40)",
      "visitDate": "",
      "age": "50대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 101,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.199592,
        "lng": 129.116725
      },
      "address": "자연드림 반여점(12:53-13:30)",
      "address2": "자연드림 반여점(12:53-13:30)",
      "visitDate": "",
      "age": "50대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 101,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "자택 기거",
      "address2": "자택 기거",
      "visitDate": "",
      "age": "50대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 101,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.202708,
        "lng": 129.119949
      },
      "address": "센텀 내과의원(11:20-11:50)",
      "address2": "센텀 내과의원(11:20-11:50)",
      "visitDate": "",
      "age": "50대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 101,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "자택 기거",
      "address2": "자택 기거",
      "visitDate": "",
      "age": "50대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 101,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.173544,
        "lng": 129.18191
      },
      "address": "부산해운대백병원 방문 후 자택 기거",
      "address2": "부산해운대백병원 방문 후 자택 기거",
      "visitDate": "",
      "age": "50대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 101,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.187234,
        "lng": 129.059263
      },
      "address": "부산 의료원 격리",
      "address2": "부산 의료원 격리",
      "visitDate": "",
      "age": "50대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 102,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.215191,
        "lng": 129.073803
      },
      "address": "전자공고(운동장) 이용(11:50:-12:40)",
      "address2": "전자공고(운동장) 이용(11:50:-12:40)",
      "visitDate": "",
      "age": "19",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 102,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.219597,
        "lng": 129.081204
      },
      "address": "대성탕(목욕탕) 이용(13:00~14:40)",
      "address2": "대성탕(목욕탕) 이용(13:00~14:40)",
      "visitDate": "",
      "age": "19",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 102,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.198369,
        "lng": 129.084146
      },
      "address": "동래밀면 본점(15:10~16:40)",
      "address2": "동래밀면 본점(15:10~16:40)",
      "visitDate": "",
      "age": "19",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 102,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.206371,
        "lng": 129.085512
      },
      "address": "복산동 주민센터 방문(16:20~16:30)",
      "address2": "복산동 주민센터 방문(16:20~16:30)",
      "visitDate": "",
      "age": "19",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 102,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.196488,
        "lng": 129.093137
      },
      "address": "동래구청 복지정책과 방문(17:00~17:20)",
      "address2": "동래구청 복지정책과 방문(17:00~17:20)",
      "visitDate": "",
      "age": "19",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 102,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.196488,
        "lng": 129.093137
      },
      "address": "동래구청 복지정책과 방문(17:00~17:20)",
      "address2": "동래구청 복지정책과 방문(17:00~17:20)",
      "visitDate": "",
      "age": "19",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 102,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "명륜역 인근마트 방문 후 자택기거",
      "address2": "명륜역 인근마트 방문 후 자택기거",
      "visitDate": "",
      "age": "19",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 102,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.216039,
        "lng": 129.077183
      },
      "address": "온천교회 1층카페 방문(10:00-13:00) 후 자택 기거",
      "address2": "온천교회 1층카페 방문(10:00-13:00) 후 자택 기거",
      "visitDate": "",
      "age": "19",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 102,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.216039,
        "lng": 129.077183
      },
      "address": "온천교회 2층서 예배(18:30-21:00) 후 자택 기거",
      "address2": "온천교회 2층서 예배(18:30-21:00) 후 자택 기거",
      "visitDate": "",
      "age": "19",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 102,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.154464,
        "lng": 129.119086
      },
      "address": "광안리 피자몰 방문(13:40-15:00)",
      "address2": "광안리 피자몰 방문(13:40-15:00)",
      "visitDate": "",
      "age": "19",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 102,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.196415,
        "lng": 129.090618
      },
      "address": "GS25 동래꿈에그린점 방문",
      "address2": "GS25 동래꿈에그린점 방문",
      "visitDate": "",
      "age": "19",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 102,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.204439,
        "lng": 129.080164
      },
      "address": "대동병원 선별진료소 방문",
      "address2": "대동병원 선별진료소 방문",
      "visitDate": "",
      "age": "19",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 102,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.204553,
        "lng": 129.079749
      },
      "address": "가까운약국 방문",
      "address2": "가까운약국 방문",
      "visitDate": "",
      "age": "19",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 102,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.20462,
        "lng": 129.081162
      },
      "address": "동래메가마트 방문",
      "address2": "동래메가마트 방문",
      "visitDate": "",
      "age": "19",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 102,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.19947,
        "lng": 129.098606
      },
      "address": "얼쑤대박터지는집 동래점 방문",
      "address2": "얼쑤대박터지는집 동래점 방문",
      "visitDate": "",
      "age": "19",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 102,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.211384,
        "lng": 129.079862
      },
      "address": "동래구 보건소 방문",
      "address2": "동래구 보건소 방문",
      "visitDate": "",
      "age": "19",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 102,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.187243,
        "lng": 129.05922
      },
      "address": "부산의료원 격리",
      "address2": "부산의료원 격리",
      "visitDate": "",
      "age": "19",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 103,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.176226,
        "lng": 129.064766
      },
      "address": "부산시 교육청 방문",
      "address2": "부산시 교육청 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 103,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.160705,
        "lng": 129.115174
      },
      "address": "수영구 광안동 슈가스팟 건물 방문",
      "address2": "수영구 광안동 슈가스팟 건물 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 103,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "부산 한서병원 선별진료소 방문",
      "address2": "부산 한서병원 선별진료소 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 103,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.100739,
        "lng": 129.018796
      },
      "address": "부산대 병원으로 이송",
      "address2": "부산대 병원으로 이송",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 104,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.877488,
        "lng": 128.62906
      },
      "address": "동대구시외버스터미널 출발",
      "address2": "동대구시외버스터미널 출발",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 104,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.164788,
        "lng": 129.160508
      },
      "address": "해운대시외버스터미널 도착",
      "address2": "해운대시외버스터미널 도착",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 104,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.186459,
        "lng": 129.203454
      },
      "address": "해운대구 음식점 방문",
      "address2": "해운대구 음식점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 104,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.172759,
        "lng": 129.17636
      },
      "address": "해운대 좌동 아이스크림점 방문",
      "address2": "해운대 좌동 아이스크림점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 104,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "경남 CU편의점 방문(주소확인중)",
      "address2": "경남 CU편의점 방문(주소확인중)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 104,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "경남선경자이마트 방문",
      "address2": "경남선경자이마트 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 104,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.16407,
        "lng": 129.178703
      },
      "address": "해운대보건소 선별진료소 방문",
      "address2": "해운대보건소 선별진료소 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 104,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.100713,
        "lng": 129.01869
      },
      "address": "부산대병원 이송",
      "address2": "부산대병원 이송",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 105,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.201308,
        "lng": 129.1198
      },
      "address": "부산 해운대구 음식점 방문",
      "address2": "부산 해운대구 음식점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 105,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.203812,
        "lng": 129.119357
      },
      "address": "스타벅스 수영강변점 방문",
      "address2": "스타벅스 수영강변점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 105,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.202023,
        "lng": 129.121793
      },
      "address": "반여 선수촌세븐일레븐(직원 1명) 방문",
      "address2": "반여 선수촌세븐일레븐(직원 1명) 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 105,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.203454,
        "lng": 129.123612
      },
      "address": " CU반여선수촌점(직원 1명) 방문",
      "address2": " CU반여선수촌점(직원 1명) 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 105,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.164081,
        "lng": 129.17865
      },
      "address": "해운대보건소 선별진료소 방문",
      "address2": "해운대보건소 선별진료소 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 105,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.18719,
        "lng": 129.059316
      },
      "address": "부산의료원 격리",
      "address2": "부산의료원 격리",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 106,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.839821,
        "lng": 128.566553
      },
      "address": "신천지예수교회다대오지성전에서 예배",
      "address2": "신천지예수교회다대오지성전에서 예배",
      "visitDate": "",
      "age": "19",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 106,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.1988,
        "lng": 128.566457
      },
      "address": "마산의료원 <span style='color:red;'>격리</span>",
      "address2": "마산의료원 <span style='color:red;'>격리</span>",
      "visitDate": "",
      "age": "19",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 107,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.839821,
        "lng": 128.566553
      },
      "address": "신천지예수교회다대오지성전에서 예배",
      "address2": "신천지예수교회다대오지성전에서 예배",
      "visitDate": "",
      "age": "14",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 107,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.1988,
        "lng": 128.566457
      },
      "address": "마산의료원 <span style='color:red;'>격리</span>",
      "address2": "마산의료원 <span style='color:red;'>격리</span>",
      "visitDate": "",
      "age": "14",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 108,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.332343,
        "lng": 127.434243
      },
      "address": "대전역 도착",
      "address2": "대전역 도착",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 108,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.273005,
        "lng": 127.265272
      },
      "address": "계룡역 도착",
      "address2": "계룡역 도착",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 108,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.282554,
        "lng": 127.241553
      },
      "address": "늘푸른목장식당 방문",
      "address2": "늘푸른목장식당 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 108,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.288507,
        "lng": 127.235964
      },
      "address": "향한리 가는길에 방문",
      "address2": "향한리 가는길에 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 108,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.282695,
        "lng": 127.237831
      },
      "address": "김밥천국 방문",
      "address2": "김밥천국 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 108,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "대전병원 선별진료소 진료",
      "address2": "대전병원 선별진료소 진료",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 109,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.390689,
        "lng": 127.149482
      },
      "address": "국군수도병원 <span style='color:red;'>격리</span>",
      "address2": "국군수도병원 <span style='color:red;'>격리</span>",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 110,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.839821,
        "lng": 128.566553
      },
      "address": "신천지예수교회다대오지성전에서 예배",
      "address2": "신천지예수교회다대오지성전에서 예배",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 110,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "합천 자택 기거<br>악기연습실 방문",
      "address2": "합천 자택 기거<br>악기연습실 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 110,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.566544,
        "lng": 128.159809
      },
      "address": "왕비 세탁소 방문",
      "address2": "왕비 세탁소 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 110,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.568415,
        "lng": 128.15495
      },
      "address": "세운할인마트 방문",
      "address2": "세운할인마트 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 110,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.567196,
        "lng": 128.162809
      },
      "address": "합천 시외버스 터미널 방문",
      "address2": "합천 시외버스 터미널 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 110,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.567985,
        "lng": 128.156572
      },
      "address": "합천 보건소 방문",
      "address2": "합천 보건소 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 110,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.567501,
        "lng": 128.161306
      },
      "address": "소정약국 방문",
      "address2": "소정약국 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 110,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.176216,
        "lng": 128.093848
      },
      "address": "경상대병원 <span style='color:red;'>격리</span>",
      "address2": "경상대병원 <span style='color:red;'>격리</span>",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 111,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.839821,
        "lng": 128.566553
      },
      "address": "신천지예수교회다대오지성전에서 예배",
      "address2": "신천지예수교회다대오지성전에서 예배",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 111,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.567104,
        "lng": 128.162741
      },
      "address": "합천 시외버스 터미널 도착",
      "address2": "합천 시외버스 터미널 도착",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 111,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "자택 기거",
      "address2": "자택 기거",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 111,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "자택 기거",
      "address2": "자택 기거",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 111,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.762709,
        "lng": 128.139412
      },
      "address": "가야면사무소 20분 방문",
      "address2": "가야면사무소 20분 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 111,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.762719,
        "lng": 128.138622
      },
      "address": "야천1구 경로당 방문",
      "address2": "야천1구 경로당 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 111,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.176216,
        "lng": 128.093848
      },
      "address": "경상대병원 <span style='color:red;'>격리</span>",
      "address2": "경상대병원 <span style='color:red;'>격리</span>",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 112,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.567196,
        "lng": 128.162809
      },
      "address": "합천시외버스터미널-대구서부정류장 왕복 이동(2/14,2/17,2/18)",
      "address2": "합천시외버스터미널-대구서부정류장 왕복 이동(2/14,2/17,2/18)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 112,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.568004,
        "lng": 128.163674
      },
      "address": "합천참정형외과 방문(방역후 폐쇄)",
      "address2": "합천참정형외과 방문(방역후 폐쇄)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 112,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.568432,
        "lng": 128.162206
      },
      "address": "김경호내과 방문(방역후 폐쇄)",
      "address2": "김경호내과 방문(방역후 폐쇄)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 112,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.1988,
        "lng": 128.566475
      },
      "address": "마산 의료원 격리",
      "address2": "마산 의료원 격리",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 113,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.819429,
        "lng": 128.727654
      },
      "address": "경산역 출발",
      "address2": "경산역 출발",
      "visitDate": "",
      "age": "20대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 113,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.332274,
        "lng": 127.43419
      },
      "address": "대전역 도착",
      "address2": "대전역 도착",
      "visitDate": "",
      "age": "20대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 113,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.335688,
        "lng": 127.449375
      },
      "address": "불난뚱땡이(일반음식점) 방문",
      "address2": "불난뚱땡이(일반음식점) 방문",
      "visitDate": "",
      "age": "20대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 113,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.33774,
        "lng": 127.44783
      },
      "address": "코인노래방 방문",
      "address2": "코인노래방 방문",
      "visitDate": "",
      "age": "20대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 113,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.33774,
        "lng": 127.44783
      },
      "address": "GS25 우송대센터점 방문",
      "address2": "GS25 우송대센터점 방문",
      "visitDate": "",
      "age": "20대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 113,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.335659,
        "lng": 127.446351
      },
      "address": "손이가짜장 식사",
      "address2": "손이가짜장 식사",
      "visitDate": "",
      "age": "20대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 113,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "더그레이카페 방문",
      "address2": "더그레이카페 방문",
      "visitDate": "",
      "age": "20대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 113,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.328707,
        "lng": 127.425853
      },
      "address": "은행동 이동 후 상가 7곳 지하상가 방문",
      "address2": "은행동 이동 후 상가 7곳 지하상가 방문",
      "visitDate": "",
      "age": "20대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 113,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.332567,
        "lng": 127.436014
      },
      "address": "대전역 동광장 이동",
      "address2": "대전역 동광장 이동",
      "visitDate": "",
      "age": "20대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 113,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.33982,
        "lng": 127.448997
      },
      "address": "우송어학센터 이동",
      "address2": "우송어학센터 이동",
      "visitDate": "",
      "age": "20대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 113,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.33774,
        "lng": 127.44783
      },
      "address": "코인노래방 방문",
      "address2": "코인노래방 방문",
      "visitDate": "",
      "age": "20대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 113,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.333753,
        "lng": 127.445273
      },
      "address": "아지트PC방 방문",
      "address2": "아지트PC방 방문",
      "visitDate": "",
      "age": "20대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 113,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.337327,
        "lng": 127.448069
      },
      "address": "케이마트 방문",
      "address2": "케이마트 방문",
      "visitDate": "",
      "age": "20대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 113,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.31135,
        "lng": 127.45472
      },
      "address": "대전 동구보건소 방문",
      "address2": "대전 동구보건소 방문",
      "visitDate": "",
      "age": "20대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 113,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.317062,
        "lng": 127.415699
      },
      "address": "충남대학교 <span style='color:red;'>격리</span>",
      "address2": "충남대학교 <span style='color:red;'>격리</span>",
      "visitDate": "",
      "age": "20대",
      "nation": "KR",
      "gender": "F",
      "date": "",
      "contact": ""
    },
    {
      "idx": 114,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.839821,
        "lng": 128.566553
      },
      "address": "신천지예수교회다대오지성전에서 예배",
      "address2": "신천지예수교회다대오지성전에서 예배",
      "visitDate": "",
      "age": "32",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 114,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.463094,
        "lng": 127.280676
      },
      "address": "쑥티식당 방문",
      "address2": "쑥티식당 방문",
      "visitDate": "",
      "age": "32",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 114,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.778499,
        "lng": 127.018752
      },
      "address": "아산 항아리보쌈 방문",
      "address2": "아산 항아리보쌈 방문",
      "visitDate": "",
      "age": "32",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 114,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.841724,
        "lng": 127.172624
      },
      "address": "단국대천안병원 <span style='color:red;'>격리</span>",
      "address2": "단국대천안병원 <span style='color:red;'>격리</span>",
      "visitDate": "",
      "age": "32",
      "nation": "KR",
      "gender": "M",
      "date": "",
      "contact": ""
    },
    {
      "idx": 115,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.839821,
        "lng": 128.566553
      },
      "address": "신천지예수교회다대오지성전에서 예배",
      "address2": "신천지예수교회다대오지성전에서 예배",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 115,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "대구 시외버스터미널 -> 포항 도착",
      "address2": "대구 시외버스터미널 -> 포항 도착",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 115,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "신천지 포항교회 방문",
      "address2": "신천지 포항교회 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 115,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.036665,
        "lng": 129.362961
      },
      "address": "중앙상가 애슐리 이용",
      "address2": "중앙상가 애슐리 이용",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 115,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.036665,
        "lng": 129.362961
      },
      "address": "중앙상가 애슐리 이용",
      "address2": "중앙상가 애슐리 이용",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 115,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.035098,
        "lng": 129.365516
      },
      "address": "달콤커피(죽도시장) 방문",
      "address2": "달콤커피(죽도시장) 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 115,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.023124,
        "lng": 129.358718
      },
      "address": "동원성에서 식사",
      "address2": "동원성에서 식사",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 115,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "신천지 포항교회(장성동) 도착 후 예배",
      "address2": "신천지 포항교회(장성동) 도착 후 예배",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 115,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.031716,
        "lng": 129.364882
      },
      "address": "김밥나라(오거리) 이용",
      "address2": "김밥나라(오거리) 이용",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 115,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "맥도날드(중앙상가) 이용(주소 확인중)",
      "address2": "맥도날드(중앙상가) 이용(주소 확인중)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 115,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.992375,
        "lng": 129.396217
      },
      "address": "남구보건소 방문",
      "address2": "남구보건소 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 115,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.034762,
        "lng": 129.355059
      },
      "address": "포항의료원 <span style='color:red;'>격리</span>",
      "address2": "포항의료원 <span style='color:red;'>격리</span>",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 116,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.060524,
        "lng": 129.378828
      },
      "address": "어림지 방문",
      "address2": "어림지 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 116,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.999765,
        "lng": 129.345021
      },
      "address": "매직 PC방 방문후 귀가",
      "address2": "매직 PC방 방문후 귀가",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 116,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "북구보건소 승차 (105번) -> 시외버스 환승 후 (107번) 경북자동차학원 하차",
      "address2": "북구보건소 승차 (105번) -> 시외버스 환승 후 (107번) 경북자동차학원 하차",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 116,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.996333,
        "lng": 129.345901
      },
      "address": "맘스터치 연일점 방문",
      "address2": "맘스터치 연일점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 116,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "지인 집 방문 후 도보로 자택 귀가",
      "address2": "지인 집 방문 후 도보로 자택 귀가",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 116,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.99244,
        "lng": 129.396289
      },
      "address": "동해주유소 승차(107번) -> 한전사거리 환승 후 남구보건소 방문",
      "address2": "동해주유소 승차(107번) -> 한전사거리 환승 후 남구보건소 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 116,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "GS 슈퍼마켓 방문",
      "address2": "GS 슈퍼마켓 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 116,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.99244,
        "lng": 129.396289
      },
      "address": "남구보건소 검사 후 귀가",
      "address2": "남구보건소 검사 후 귀가",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 116,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "자택서 격리",
      "address2": "자택서 격리",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 117,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.059444,
        "lng": 129.374354
      },
      "address": "바디라인 피트니스 방문",
      "address2": "바디라인 피트니스 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 117,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "사택 도착",
      "address2": "사택 도착",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 117,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.011127,
        "lng": 129.349145
      },
      "address": "포항 우체국 출근",
      "address2": "포항 우체국 출근",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 117,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.059444,
        "lng": 129.374354
      },
      "address": "바디라인 피트니스 방문",
      "address2": "바디라인 피트니스 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 117,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.011127,
        "lng": 129.349145
      },
      "address": "포항 우체국 출근",
      "address2": "포항 우체국 출근",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 117,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.059444,
        "lng": 129.374354
      },
      "address": "바디라인피트니스 방문",
      "address2": "바디라인피트니스 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 117,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.011127,
        "lng": 129.349145
      },
      "address": "직장(포항우체국) 근무",
      "address2": "직장(포항우체국) 근무",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 117,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.059444,
        "lng": 129.374354
      },
      "address": "바디라인피트니스 운동후 사택 귀가",
      "address2": "바디라인피트니스 운동후 사택 귀가",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 117,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.011127,
        "lng": 129.349145
      },
      "address": "직장(포항우체국) 근무",
      "address2": "직장(포항우체국) 근무",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 117,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "자택 기거",
      "address2": "자택 기거",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 118,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.031672,
        "lng": 129.364906
      },
      "address": "김밥나라(오거리) 방문",
      "address2": "김밥나라(오거리) 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 118,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "도보로 자택 귀가",
      "address2": "도보로 자택 귀가",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 118,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "친구 집 방문",
      "address2": "친구 집 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 118,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.012772,
        "lng": 129.348954
      },
      "address": "밸류플러스 1층 라라코스트 방문",
      "address2": "밸류플러스 1층 라라코스트 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 118,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.0114,
        "lng": 129.347188
      },
      "address": "터미널 근처 호텔 팰리스 방문",
      "address2": "터미널 근처 호텔 팰리스 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 118,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "108번 버스타고 이동 BL헬스장(2층 이용) 도착",
      "address2": "108번 버스타고 이동 BL헬스장(2층 이용) 도착",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 118,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "108번 버스타고 자택 귀가",
      "address2": "108번 버스타고 자택 귀가",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 118,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "도보로 하나은행(오광장점)방문 후 자택 귀가",
      "address2": "도보로 하나은행(오광장점)방문 후 자택 귀가",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 118,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.033023,
        "lng": 129.366457
      },
      "address": "홍성철성형외과(오거리) 4층 방문",
      "address2": "홍성철성형외과(오거리) 4층 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 118,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.033032,
        "lng": 129.366868
      },
      "address": "독일 약국 방문",
      "address2": "독일 약국 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 118,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "세명고 뒤 맥도날드 드라이빙쓰루 이용(주소 확인중)",
      "address2": "세명고 뒤 맥도날드 드라이빙쓰루 이용(주소 확인중)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 118,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.0114,
        "lng": 129.347188
      },
      "address": "호텔팰리스 방문",
      "address2": "호텔팰리스 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 118,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "자택 귀가",
      "address2": "자택 귀가",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 119,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.070662,
        "lng": 129.380494
      },
      "address": "북구보건소 근무",
      "address2": "북구보건소 근무",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 119,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.080567,
        "lng": 129.392345
      },
      "address": "CU 편의점 포항인성점 방문",
      "address2": "CU 편의점 포항인성점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 119,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.070662,
        "lng": 129.380494
      },
      "address": "북구보건소 근무",
      "address2": "북구보건소 근무",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 119,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.079349,
        "lng": 129.39251
      },
      "address": "장성동 진할인마트 방문(생필품 구입)",
      "address2": "장성동 진할인마트 방문(생필품 구입)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 119,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "자택 귀가",
      "address2": "자택 귀가",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 120,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.868166,
        "lng": 128.594798
      },
      "address": "동성로 KB ATM 이용<br>대구 동성로 꽃집 방문",
      "address2": "동성로 KB ATM 이용<br>대구 동성로 꽃집 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 120,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.868512,
        "lng": 128.59823
      },
      "address": "대구 동성로 식당'스시라스또' 방문",
      "address2": "대구 동성로 식당'스시라스또' 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 120,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.879893,
        "lng": 128.628476
      },
      "address": "동대구역 출발",
      "address2": "동대구역 출발",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 120,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.869232,
        "lng": 129.200574
      },
      "address": "서경주역 도착",
      "address2": "서경주역 도착",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 120,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.866663,
        "lng": 129.202241
      },
      "address": "현곡 준PC방 방문 ",
      "address2": "현곡 준PC방 방문 ",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 120,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.858188,
        "lng": 129.196671
      },
      "address": "동국대경주병원 선별진료소 방문 후 양성판정",
      "address2": "동국대경주병원 선별진료소 방문 후 양성판정",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 121,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.833409,
        "lng": 127.121673
      },
      "address": "직장 근무",
      "address2": "직장 근무",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 121,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "전주출발 -> 청주 처가 도착",
      "address2": "전주출발 -> 청주 처가 도착",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 121,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "태안일대 여행 -> 전주 도착",
      "address2": "태안일대 여행 -> 전주 도착",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 121,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.817194,
        "lng": 127.102292
      },
      "address": "다솔아동병원&다솜약국 방문",
      "address2": "다솔아동병원&다솜약국 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 121,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.80654,
        "lng": 127.114314
      },
      "address": "전주효자동 홈플러스 방문",
      "address2": "전주효자동 홈플러스 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 121,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.830807,
        "lng": 127.116256
      },
      "address": "지리산 한방병원 방문",
      "address2": "지리산 한방병원 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 121,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.9643,
        "lng": 126.959546
      },
      "address": "원광대병원 격리",
      "address2": "원광대병원 격리",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 122,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.6421,
        "lng": 126.831178
      },
      "address": "명지병원으로 이송",
      "address2": "명지병원으로 이송",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 123,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.6421,
        "lng": 126.831178
      },
      "address": "명지병원으로 이송",
      "address2": "명지병원으로 이송",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 124,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.866256,
        "lng": 128.597597
      },
      "address": "대구동성로 음식점(끌리다) 방문",
      "address2": "대구동성로 음식점(끌리다) 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 124,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "외출없이 자가격리",
      "address2": "외출없이 자가격리",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 124,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.102915,
        "lng": 128.382719
      },
      "address": "순천향구미병원에서 검체를 채취, 검사를 의뢰",
      "address2": "순천향구미병원에서 검체를 채취, 검사를 의뢰",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 124,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.102915,
        "lng": 128.382719
      },
      "address": "순천향구미병원으로부터 양성 판정",
      "address2": "순천향구미병원으로부터 양성 판정",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 124,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "현재 자가 격리중",
      "address2": "현재 자가 격리중",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 125,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.520046,
        "lng": 129.428956
      },
      "address": "울산대병원 국가지정음압격리치료실로 이송",
      "address2": "울산대병원 국가지정음압격리치료실로 이송",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 126,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.863408,
        "lng": 127.718369
      },
      "address": "춘천 버스터미널에서 고속버스를 이용해 대구로 이동",
      "address2": "춘천 버스터미널에서 고속버스를 이용해 대구로 이동",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 126,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.839821,
        "lng": 128.566553
      },
      "address": "신천지예수교회다대오지성전에서 예배",
      "address2": "신천지예수교회다대오지성전에서 예배",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 126,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": " 대구 트레이더스 방문",
      "address2": " 대구 트레이더스 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 126,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.863408,
        "lng": 127.718369
      },
      "address": "춘천 버스터미널 도착",
      "address2": "춘천 버스터미널 도착",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 126,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "새명동에 있는 신천지 센터 방문",
      "address2": "새명동에 있는 신천지 센터 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 126,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "자택 기거",
      "address2": "자택 기거",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 127,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.62902,
        "lng": 127.488395
      },
      "address": "청주시 상당구 석교동 육거리 시장 주차장~떡집골목",
      "address2": "청주시 상당구 석교동 육거리 시장 주차장~떡집골목",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 127,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.628274,
        "lng": 127.507736
      },
      "address": "청주시 상당구 금천동 문구점 방문",
      "address2": "청주시 상당구 금천동 문구점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 127,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.620401,
        "lng": 127.516061
      },
      "address": "용암동 롯데마트 방문",
      "address2": "용암동 롯데마트 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 127,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.778018,
        "lng": 127.568671
      },
      "address": "증평군 증평읍 송원칼국수",
      "address2": "증평군 증평읍 송원칼국수",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 127,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "증평군 충북 식자재마트",
      "address2": "증평군 충북 식자재마트",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 127,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "금천동 델리퀸 방문 (주소확인중)",
      "address2": "금천동 델리퀸 방문 (주소확인중)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 127,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "자가격리 실시",
      "address2": "자가격리 실시",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 128,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.900718,
        "lng": 127.201162
      },
      "address": "포천 보건소 방문",
      "address2": "포천 보건소 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 129,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.443068,
        "lng": 129.164281
      },
      "address": "삼척시 PC방 방문",
      "address2": "삼척시 PC방 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 129,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.443602,
        "lng": 129.163701
      },
      "address": "만치만치 방문",
      "address2": "만치만치 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 129,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.522873,
        "lng": 129.116069
      },
      "address": "맥도날드 동해점 방문",
      "address2": "맥도날드 동해점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 129,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "데일리커피숍 방문",
      "address2": "데일리커피숍 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 129,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.443068,
        "lng": 129.164281
      },
      "address": "삼척시 PC방 방문",
      "address2": "삼척시 PC방 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 129,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.443602,
        "lng": 129.163701
      },
      "address": "만치만치 방문",
      "address2": "만치만치 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 129,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.442638,
        "lng": 129.164561
      },
      "address": "모닝캄 방문",
      "address2": "모닝캄 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 129,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.44415,
        "lng": 129.163383
      },
      "address": "양분식 방문",
      "address2": "양분식 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 129,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.442978,
        "lng": 129.163504
      },
      "address": "삼척시 PC방 방문",
      "address2": "삼척시 PC방 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 129,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {},
      "address": "동해역전할머니 방문",
      "address2": "동해역전할머니 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 129,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.443068,
        "lng": 129.164281
      },
      "address": "삼척시 PC방 방문",
      "address2": "삼척시 PC방 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 129,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.444197,
        "lng": 129.16345
      },
      "address": "놀부부대찌개 방문",
      "address2": "놀부부대찌개 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 129,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.443102,
        "lng": 129.164206
      },
      "address": "그랑프리당구장 방문",
      "address2": "그랑프리당구장 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 129,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.749212,
        "lng": 128.888693
      },
      "address": "강릉의료원 이송",
      "address2": "강릉의료원 이송",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 130,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.110259,
        "lng": 128.419082
      },
      "address": "호텔 아메리카 방문",
      "address2": "호텔 아메리카 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 131,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.107918,
        "lng": 128.424005
      },
      "address": "GS편의점(인의센타점) 방문",
      "address2": "GS편의점(인의센타점) 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 132,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.107993,
        "lng": 128.418469
      },
      "address": "에이플러스노래방(황상동) 방문",
      "address2": "에이플러스노래방(황상동) 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 133,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.107883,
        "lng": 128.423984
      },
      "address": "GS편의점(인의센타점) 방문",
      "address2": "GS편의점(인의센타점) 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 134,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.557032,
        "lng": 127.07944
      },
      "address": "군자역 방문",
      "address2": "군자역 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 135,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.555958,
        "lng": 127.079286
      },
      "address": "군자 탐앤탐스 방문",
      "address2": "군자 탐앤탐스 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 136,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.558112,
        "lng": 127.079373
      },
      "address": "영 모네중식 방문",
      "address2": "영 모네중식 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 137,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.550983,
        "lng": 129.137993
      },
      "address": "울산역 방문",
      "address2": "울산역 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 138,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.557535,
        "lng": 129.308828
      },
      "address": "울산 닥터리연합내과 방문",
      "address2": "울산 닥터리연합내과 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 139,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.869179,
        "lng": 128.594829
      },
      "address": " 동성로 장도뚝배기 방문",
      "address2": " 동성로 장도뚝배기 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 140,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.838913,
        "lng": 128.571015
      },
      "address": "대명클락해치워트니센터 방문",
      "address2": "대명클락해치워트니센터 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 141,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.841091,
        "lng": 128.57184
      },
      "address": "다원 카페 헤어 방문",
      "address2": "다원 카페 헤어 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 142,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.550769,
        "lng": 129.263124
      },
      "address": "신복 로타리 방문",
      "address2": "신복 로타리 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 143,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.645513,
        "lng": 129.441712
      },
      "address": "신명횟집 방문",
      "address2": "신명횟집 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 144,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.557617,
        "lng": 129.308594
      },
      "address": "그린약국 방문",
      "address2": "그린약국 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 145,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.173062,
        "lng": 128.946523
      },
      "address": "김해공항 입국",
      "address2": "김해공항 입국",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 146,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 34.871984,
        "lng": 128.722161
      },
      "address": "대우병원 방문",
      "address2": "대우병원 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 147,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.198835,
        "lng": 128.566518
      },
      "address": "마산의료원 격리",
      "address2": "마산의료원 격리",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 148,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.567971,
        "lng": 128.732347
      },
      "address": "안동 의료원 격리",
      "address2": "안동 의료원 격리",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 149,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.220285,
        "lng": 129.086445
      },
      "address": "온천장지하철역 방문",
      "address2": "온천장지하철역 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 150,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.21632,
        "lng": 129.079251
      },
      "address": "목화식당 방문",
      "address2": "목화식당 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 151,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.179495,
        "lng": 128.104776
      },
      "address": "진주기계공고 정류장 방문",
      "address2": "진주기계공고 정류장 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 152,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.193187,
        "lng": 128.116517
      },
      "address": "선학사거리 정류장 방문",
      "address2": "선학사거리 정류장 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 153,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.107201,
        "lng": 129.032514
      },
      "address": "메리놀병원 방문",
      "address2": "메리놀병원 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 154,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.648645,
        "lng": 128.737074
      },
      "address": "청도 대남병원",
      "address2": "청도 대남병원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 155,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.012037,
        "lng": 128.430844
      },
      "address": "칠곡휴계소 방문",
      "address2": "칠곡휴계소 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 156,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.397808,
        "lng": 127.355314
      },
      "address": "대전 음식점 방문",
      "address2": "대전 음식점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 157,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.384265,
        "lng": 127.321621
      },
      "address": "롯데마트 노은점 방문",
      "address2": "롯데마트 노은점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 158,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.128765,
        "lng": 127.612211
      },
      "address": "왕할머니 순두부 방문",
      "address2": "왕할머니 순두부 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 159,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.121864,
        "lng": 127.628632
      },
      "address": "이천 중식당 방문",
      "address2": "이천 중식당 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 160,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.124234,
        "lng": 127.615585
      },
      "address": "샘재로밥상 방문",
      "address2": "샘재로밥상 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 161,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.864705,
        "lng": 127.717515
      },
      "address": "춘천 고속버스 터미널 방문(14:00)",
      "address2": "춘천 고속버스 터미널 방문(14:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 162,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.889885,
        "lng": 128.555973
      },
      "address": "대구 트레이더스 방문(15:00~15:30)",
      "address2": "대구 트레이더스 방문(15:00~15:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 163,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.386813,
        "lng": 128.438429
      },
      "address": "안계성당 방문",
      "address2": "안계성당 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 164,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.388919,
        "lng": 128.43542
      },
      "address": "안계홈마트 방문",
      "address2": "안계홈마트 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 165,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.452938,
        "lng": 128.355027
      },
      "address": "다인중학교 방문",
      "address2": "다인중학교 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 166,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.38303,
        "lng": 128.439086
      },
      "address": "안계하나로마트 방문",
      "address2": "안계하나로마트 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 167,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.827495,
        "lng": 127.764597
      },
      "address": "새명동 신천지 센터 방문",
      "address2": "새명동 신천지 센터 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 168,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.862064,
        "lng": 127.731061
      },
      "address": "59쌀피자(남춘천점)에서 아르바이트(17:00~23:00)",
      "address2": "59쌀피자(남춘천점)에서 아르바이트(17:00~23:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 169,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 34.45386,
        "lng": 127.518144
      },
      "address": "나로우주센터 우주과학관 매점(13:00)",
      "address2": "나로우주센터 우주과학관 매점(13:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 170,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.837139,
        "lng": 128.754148
      },
      "address": "대학사진관 방문",
      "address2": "대학사진관 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 171,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.874798,
        "lng": 128.813918
      },
      "address": "초원애 한식뷔페 방문",
      "address2": "초원애 한식뷔페 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 172,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.91395,
        "lng": 128.819653
      },
      "address": "파티마연합속내과의원 방문",
      "address2": "파티마연합속내과의원 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 173,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.91395,
        "lng": 128.819653
      },
      "address": "바른약국 방문",
      "address2": "바른약국 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 174,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.826304,
        "lng": 128.737349
      },
      "address": "세명병원 선별진료소 방문",
      "address2": "세명병원 선별진료소 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 175,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.838615,
        "lng": 128.759718
      },
      "address": "세븐일레븐영대제일원룸점 방문",
      "address2": "세븐일레븐영대제일원룸점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 176,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.840582,
        "lng": 128.755491
      },
      "address": "포스마트 영남대학점 방문",
      "address2": "포스마트 영남대학점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 177,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.354974,
        "lng": 128.704869
      },
      "address": "의성군청 청소년센터-우쿠렐레 수강(10:00~12:00)",
      "address2": "의성군청 청소년센터-우쿠렐레 수강(10:00~12:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 178,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.266633,
        "lng": 126.999397
      },
      "address": "동대구역 -> 수원역 KTX 이동",
      "address2": "동대구역 -> 수원역 KTX 이동",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 179,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.346136,
        "lng": 128.697437
      },
      "address": "의성군보건소 방문/검진(14:30)",
      "address2": "의성군보건소 방문/검진(14:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 180,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.271733,
        "lng": 127.012442
      },
      "address": "팔달구 보건소 방문(11:45)",
      "address2": "팔달구 보건소 방문(11:45)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 181,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.508501,
        "lng": 128.421585
      },
      "address": "안사면 쌍호1리 경로당 저녁식사(17:00~19:00)",
      "address2": "안사면 쌍호1리 경로당 저녁식사(17:00~19:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 182,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.826819,
        "lng": 128.737377
      },
      "address": "경산세명장례식장(13:00)",
      "address2": "경산세명장례식장(13:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 183,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.274512,
        "lng": 127.062579
      },
      "address": "도쿄등심에서 저녁식사(18:00경)",
      "address2": "도쿄등심에서 저녁식사(18:00경)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 184,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.290972,
        "lng": 127.072968
      },
      "address": "광교 참누리 레이크 아파트 귀가",
      "address2": "광교 참누리 레이크 아파트 귀가",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 185,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.286904,
        "lng": 127.05571
      },
      "address": "롯데아울렛 광교점 방문(17:30)",
      "address2": "롯데아울렛 광교점 방문(17:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 186,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.5778,
        "lng": 128.573876
      },
      "address": "풍산 설화맥적 식당-산악회 점심식사(13:00~14:00)",
      "address2": "풍산 설화맥적 식당-산악회 점심식사(13:00~14:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 187,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.300929,
        "lng": 128.583041
      },
      "address": "김동준 한우-저녁식사(18:00~19:40)",
      "address2": "김동준 한우-저녁식사(18:00~19:40)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 188,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.836626,
        "lng": 128.753069
      },
      "address": "매스커피 영남대점 방문",
      "address2": "매스커피 영남대점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 189,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.300929,
        "lng": 128.583041
      },
      "address": "김동준 한우-저녁식사(18:00~19:40)",
      "address2": "김동준 한우-저녁식사(18:00~19:40)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 190,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.35133,
        "lng": 128.696059
      },
      "address": "경북의원 방문(10:00)",
      "address2": "경북의원 방문(10:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 191,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.355736,
        "lng": 128.694551
      },
      "address": "김일환 내과 방문(12:00)",
      "address2": "김일환 내과 방문(12:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 192,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.349524,
        "lng": 128.697745
      },
      "address": "대영목욕탕 방문(17:00)",
      "address2": "대영목욕탕 방문(17:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 193,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.350037,
        "lng": 128.697397
      },
      "address": "주광식당 식사 포장(18:30)",
      "address2": "주광식당 식사 포장(18:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 194,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.8504863,
        "lng": 128.5436292
      },
      "address": "달서시장 안 보리밥집에서 식사 (11:40)",
      "address2": "달서시장 안 보리밥집에서 식사 (11:40)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 195,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.827824,
        "lng": 128.725854
      },
      "address": "청해수산 방문",
      "address2": "청해수산 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 196,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.830094111715496,
        "lng": 128.7198879498054
      },
      "address": "펜타힐즈연합내과의원 방문",
      "address2": "펜타힐즈연합내과의원 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 197,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.0159043,
        "lng": 128.4296851
      },
      "address": "칠곡휴게소 (남편만 화장실 방문) (13:00)",
      "address2": "칠곡휴게소 (남편만 화장실 방문) (13:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 198,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.6017471,
        "lng": 128.2049427
      },
      "address": "점촌하나로마트(화장실만 이용) (14:00)",
      "address2": "점촌하나로마트(화장실만 이용) (14:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 199,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.567518,
        "lng": 128.162469
      },
      "address": "합천시외버스터미널 (2/14, 2/17일, 2/18 방문)",
      "address2": "합천시외버스터미널 (2/14, 2/17일, 2/18 방문)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 200,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.488448,
        "lng": 127.028689
      },
      "address": "삼성 디지털프라자 서초점 2층(방역조치 완료)",
      "address2": "삼성 디지털프라자 서초점 2층(방역조치 완료)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 201,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.477868,
        "lng": 126.987334
      },
      "address": "복돼지네 옛날 생돼지김치찌개 방문",
      "address2": "복돼지네 옛날 생돼지김치찌개 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 202,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.6277913,
        "lng": 128.2314212
      },
      "address": "산북하나로마트(남편만 내려 생수 구입) (14:27)",
      "address2": "산북하나로마트(남편만 내려 생수 구입) (14:27)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 203,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.019014,
        "lng": 127.070253
      },
      "address": "지제역 방문",
      "address2": "지제역 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 204,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.009115,
        "lng": 127.076112
      },
      "address": "노걸대 감자탕에서 점심(11:30)",
      "address2": "노걸대 감자탕에서 점심(11:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 205,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.963249,
        "lng": 127.063888
      },
      "address": "힐앤토 클라이밍 방문(17:00~22:00)",
      "address2": "힐앤토 클라이밍 방문(17:00~22:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 206,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.079693,
        "lng": 128.702434
      },
      "address": "백학 1리 마을회관 방문(17:00)",
      "address2": "백학 1리 마을회관 방문(17:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 207,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.229856,
        "lng": 128.569574
      },
      "address": "부계보건지소 방문(17:00, 자가용)",
      "address2": "부계보건지소 방문(17:00, 자가용)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 208,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.5962304,
        "lng": 128.1975181
      },
      "address": "점촌터미널도착 (쏘카 대여) (15:40)",
      "address2": "점촌터미널도착 (쏘카 대여) (15:40)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 209,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.123518,
        "lng": 128.694888
      },
      "address": "산성면사무소 방문(9:00)",
      "address2": "산성면사무소 방문(9:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 210,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 38.209944,
        "lng": 128.586603
      },
      "address": "가덕국수(동명동)",
      "address2": "가덕국수(동명동)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 211,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.008554,
        "lng": 127.074076
      },
      "address": "평택 성모병원 진료소 방문(증상 미미로 검사 미실시)",
      "address2": "평택 성모병원 진료소 방문(증상 미미로 검사 미실시)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 212,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.639014,
        "lng": 128.2560374
      },
      "address": "산양면 화수헌 카페 방문 (16:45 경)",
      "address2": "산양면 화수헌 카페 방문 (16:45 경)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 213,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.005685,
        "lng": 127.084431
      },
      "address": "맥도날드 평택 SK점 방문(13:15)",
      "address2": "맥도날드 평택 SK점 방문(13:15)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 214,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.001396,
        "lng": 127.07967
      },
      "address": "한라약국 방문(18:40)",
      "address2": "한라약국 방문(18:40)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 215,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 38.222805,
        "lng": 128.583287
      },
      "address": "파스쿠찌 영량호점 방문(14:00)",
      "address2": "파스쿠찌 영량호점 방문(14:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 216,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.001363,
        "lng": 127.079635
      },
      "address": "현대향촌마트 방문(18:40)",
      "address2": "현대향촌마트 방문(18:40)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 217,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.305648,
        "lng": 129.025007
      },
      "address": "삼산이용원 방문",
      "address2": "삼산이용원 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 218,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 38.210327,
        "lng": 128.586505
      },
      "address": "매자식당 방문(18:00)",
      "address2": "매자식당 방문(18:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 219,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 38.150126,
        "lng": 128.607381
      },
      "address": "양양 강현면사무소옆 GS편의점 밖 테라스 방문(5:50)",
      "address2": "양양 강현면사무소옆 GS편의점 밖 테라스 방문(5:50)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 220,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 38.238861,
        "lng": 128.511654
      },
      "address": "102 기갑여단 소형버스로 이동(16:30)",
      "address2": "102 기갑여단 소형버스로 이동(16:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 221,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.817607,
        "lng": 128.605227
      },
      "address": "영주온천 방문(17:30~18:30)",
      "address2": "영주온천 방문(17:30~18:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 222,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 38.186499,
        "lng": 128.60344
      },
      "address": "우동당 방문(12:03)",
      "address2": "우동당 방문(12:03)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 223,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.57973,
        "lng": 128.724522
      },
      "address": "안동교구청에서 교육(9:00~18:30), 영주 거주자 1명 동승",
      "address2": "안동교구청에서 교육(9:00~18:30), 영주 거주자 1명 동승",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 224,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 38.272725,
        "lng": 128.556271
      },
      "address": "고성 아야진항 낚시 위해 방문(14:00)",
      "address2": "고성 아야진항 낚시 위해 방문(14:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 225,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.567958,
        "lng": 128.163654
      },
      "address": "합천큰약국 방문",
      "address2": "합천큰약국 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 226,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 38.265251,
        "lng": 128.358809
      },
      "address": "고성 진부령 미술관 방문(13:30)",
      "address2": "고성 진부령 미술관 방문(13:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 227,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.553093,
        "lng": 126.972635
      },
      "address": "동대구역->서울역 KTX로 도착",
      "address2": "동대구역->서울역 KTX로 도착",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 228,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.56439,
        "lng": 128.162934
      },
      "address": "세운건축인테리어 방문",
      "address2": "세운건축인테리어 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 229,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.490585,
        "lng": 126.723634
      },
      "address": "서울역->부평역 지하철로 이동",
      "address2": "서울역->부평역 지하철로 이동",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 230,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.568437,
        "lng": 128.16249
      },
      "address": "황강약국 방문",
      "address2": "황강약국 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 231,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.495991,
        "lng": 126.72623
      },
      "address": "부평시장 내 상점 옥설선식 방문(2/18,19,20,21)",
      "address2": "부평시장 내 상점 옥설선식 방문(2/18,19,20,21)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 232,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.568028,
        "lng": 128.156549
      },
      "address": "합천군 보건소 선별진료소 방문",
      "address2": "합천군 보건소 선별진료소 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 233,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.494571,
        "lng": 126.725305
      },
      "address": "부평시장 내 상점 그린조이 방문(2/20,21)",
      "address2": "부평시장 내 상점 그린조이 방문(2/20,21)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 234,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.498984,
        "lng": 126.724246
      },
      "address": "부평구 보건소 선별진료소 방문",
      "address2": "부평구 보건소 선별진료소 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 235,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.198809,
        "lng": 128.566491
      },
      "address": "마산의료원 격리치료중",
      "address2": "마산의료원 격리치료중",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 236,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.552563,
        "lng": 129.138604
      },
      "address": "KTX 5호차 8B석으로 울산역 도착",
      "address2": "KTX 5호차 8B석으로 울산역 도착",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 237,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.336177,
        "lng": 129.025089
      },
      "address": "양산시보건소 선별진료소 방문(10:40)>자택격리 조치",
      "address2": "양산시보건소 선별진료소 방문(10:40)>자택격리 조치",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 238,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.558345,
        "lng": 129.308678
      },
      "address": "울산 닥터리 연합내과",
      "address2": "울산 닥터리 연합내과",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 239,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.868216,
        "lng": 128.594148
      },
      "address": "고수의 운전 면허 (09:00~11:00)",
      "address2": "고수의 운전 면허 (09:00~11:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 240,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.870104,
        "lng": 128.594665
      },
      "address": "동성로 장도 뚝배기",
      "address2": "동성로 장도 뚝배기",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 241,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.22072,
        "lng": 129.086595
      },
      "address": "온천장역 출발(7:45)>부산역 도착(7:50)",
      "address2": "온천장역 출발(7:45)>부산역 도착(7:50)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 242,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.924896,
        "lng": 128.55203
      },
      "address": "칠곡면허시험장(15:00~) - 지하철 1,3호선 이용",
      "address2": "칠곡면허시험장(15:00~) - 지하철 1,3호선 이용",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 243,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.7593291,
        "lng": 128.0776001
      },
      "address": "새재 스타벅스 (13시 경)",
      "address2": "새재 스타벅스 (13시 경)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 244,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.841453,
        "lng": 128.572402
      },
      "address": "다원 카페 헤어 (23:40~01:00))",
      "address2": "다원 카페 헤어 (23:40~01:00))",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 245,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.7314247,
        "lng": 128.1076078
      },
      "address": "사과꽃 필 무렵 방문 (14:30 경)",
      "address2": "사과꽃 필 무렵 방문 (14:30 경)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 246,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.867361,
        "lng": 128.594242
      },
      "address": "타이거 슈가 동성로점",
      "address2": "타이거 슈가 동성로점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 247,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.115286,
        "lng": 129.042264
      },
      "address": "부산역 (KTX  7호차), 20:40~21:02",
      "address2": "부산역 (KTX  7호차), 20:40~21:02",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 248,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.161656,
        "lng": 129.147337
      },
      "address": "동백역",
      "address2": "동백역",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 249,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.5875217,
        "lng": 128.1934636
      },
      "address": "M컨벤션 앞 (16:15 경)",
      "address2": "M컨벤션 앞 (16:15 경)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 250,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.6539688,
        "lng": 128.2574899
      },
      "address": "뉴욕제과 방문 (16:50 경)",
      "address2": "뉴욕제과 방문 (16:50 경)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 251,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.6541196,
        "lng": 128.2575626
      },
      "address": "산북손짜장 방문 (10:14 경)",
      "address2": "산북손짜장 방문 (10:14 경)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 252,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.569954,
        "lng": 129.243638
      },
      "address": "이가네 콩나물국밥(구영점)",
      "address2": "이가네 콩나물국밥(구영점)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 253,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.5915085,
        "lng": 128.1838529
      },
      "address": "모전 GS칼텍스 주유소 (12:20 경)",
      "address2": "모전 GS칼텍스 주유소 (12:20 경)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 254,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.152402,
        "lng": 126.889624
      },
      "address": "서구보건소 선별진료소 (11:30)",
      "address2": "서구보건소 선별진료소 (11:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 255,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.554963,
        "lng": 129.308599
      },
      "address": "GS25 리버스위트점(10:16~10:20)",
      "address2": "GS25 리버스위트점(10:16~10:20)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 256,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.554583,
        "lng": 129.308895
      },
      "address": "LG베스트샵(태화동, 10:20~10:25)",
      "address2": "LG베스트샵(태화동, 10:20~10:25)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 257,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.48146,
        "lng": 127.12293
      },
      "address": " 문정동 굿모닝이비인후과 방문",
      "address2": " 문정동 굿모닝이비인후과 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 258,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.481178,
        "lng": 127.123358
      },
      "address": "하나약국 방문",
      "address2": "하나약국 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 259,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.569455,
        "lng": 128.736081
      },
      "address": "가톨릭 상지대 구내서점 근무",
      "address2": "가톨릭 상지대 구내서점 근무",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 260,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.569455,
        "lng": 128.736081
      },
      "address": "가톨릭 상지대 구내서점 근무",
      "address2": "가톨릭 상지대 구내서점 근무",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 261,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.560988,
        "lng": 128.73722
      },
      "address": "안동소방서 방문",
      "address2": "안동소방서 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 262,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.079349,
        "lng": 129.392489
      },
      "address": "장성동 진할인마트 방문",
      "address2": "장성동 진할인마트 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 263,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.495317,
        "lng": 126.858458
      },
      "address": "본맛송탄부대찌개 방문후 포장",
      "address2": "본맛송탄부대찌개 방문후 포장",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 264,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.060533,
        "lng": 129.377153
      },
      "address": "설악산 막국수 방문",
      "address2": "설악산 막국수 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 265,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.06029,
        "lng": 129.373139
      },
      "address": "오피스디포(북포항점) 방문",
      "address2": "오피스디포(북포항점) 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 266,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.060299,
        "lng": 129.372949
      },
      "address": "오피스디포옆 파리바게뜨 방문",
      "address2": "오피스디포옆 파리바게뜨 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 267,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.238612,
        "lng": 128.915546
      },
      "address": "안동 박영진의원 방문",
      "address2": "안동 박영진의원 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 268,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.239137,
        "lng": 128.914969
      },
      "address": "더선경약국 방문",
      "address2": "더선경약국 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 269,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.176611,
        "lng": 128.806518
      },
      "address": "장유율하 돈토리식당 방문",
      "address2": "장유율하 돈토리식당 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 270,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.232267,
        "lng": 128.870919
      },
      "address": "김해시보건소 방문",
      "address2": "김해시보건소 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 271,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.224045,
        "lng": 126.891717
      },
      "address": "우치공원(15:30 ~ 17:30)",
      "address2": "우치공원(15:30 ~ 17:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 272,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.149437,
        "lng": 126.926382
      },
      "address": "동명동 동명식빵 (20:50)",
      "address2": "동명동 동명식빵 (20:50)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 273,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.132951,
        "lng": 126.91046
      },
      "address": "봉선점 파스타 르시엘블루(12:00)",
      "address2": "봉선점 파스타 르시엘블루(12:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 274,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.032644,
        "lng": 129.366662
      },
      "address": "BL헬스장 4층에서 운동(18:10~20:00)",
      "address2": "BL헬스장 4층에서 운동(18:10~20:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 275,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.482085,
        "lng": 127.123581
      },
      "address": "베스킨라빈스 송파하비오점",
      "address2": "베스킨라빈스 송파하비오점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 276,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.487737,
        "lng": 127.119209
      },
      "address": "문정 교동짬뽕 방문",
      "address2": "문정 교동짬뽕 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 277,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.222058,
        "lng": 128.676721
      },
      "address": "터치카페 창원중앙점(14:00)",
      "address2": "터치카페 창원중앙점(14:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 278,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.221407,
        "lng": 128.675717
      },
      "address": "중앙동 메가박스 건물 2층 이노스페이스 PC방(15:00)",
      "address2": "중앙동 메가박스 건물 2층 이노스페이스 PC방(15:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 279,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.216855,
        "lng": 128.685183
      },
      "address": "이디야커피 창원온천점(13:20)",
      "address2": "이디야커피 창원온천점(13:20)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 280,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.217606,
        "lng": 128.68463
      },
      "address": "k-1 1호점 PC방(15:00)",
      "address2": "k-1 1호점 PC방(15:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 281,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.217171,
        "lng": 128.670463
      },
      "address": "창원병원 앞 세계로약국 결제(14:55)",
      "address2": "창원병원 앞 세계로약국 결제(14:55)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 282,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.216518,
        "lng": 128.679405
      },
      "address": "텀브커피 상남꿈에그린점(15:00)",
      "address2": "텀브커피 상남꿈에그린점(15:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 283,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.107914,
        "lng": 129.032607
      },
      "address": "메리놀병원(08:15)",
      "address2": "메리놀병원(08:15)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 284,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.10414,
        "lng": 129.036415
      },
      "address": "중앙지하철역(17:45)",
      "address2": "중앙지하철역(17:45)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 285,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.002285,
        "lng": 129.344921
      },
      "address": "GS수퍼마켓 포항연일점 방문(16:00~17:00)",
      "address2": "GS수퍼마켓 포항연일점 방문(16:00~17:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 286,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.303328,
        "lng": 129.024979
      },
      "address": "삼산이용원(08:00)",
      "address2": "삼산이용원(08:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 287,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.882347,
        "lng": 128.662134
      },
      "address": "대구 퀸벨호텔 9층 결혼식 참석 및 8층 뷔페(11:00~12:30)",
      "address2": "대구 퀸벨호텔 9층 결혼식 참석 및 8층 뷔페(11:00~12:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 288,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.970879,
        "lng": 128.938576
      },
      "address": "영천 시청 오거리 버스정류장 555번 탑승 (13시~14시)",
      "address2": "영천 시청 오거리 버스정류장 555번 탑승 (13시~14시)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 289,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.232989,
        "lng": 129.086258
      },
      "address": "시골 통돼지볶음(부산대) 방문",
      "address2": "시골 통돼지볶음(부산대) 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 290,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.231155,
        "lng": 129.085656
      },
      "address": "롭스 부산대 2호점 방문",
      "address2": "롭스 부산대 2호점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 291,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.231002,
        "lng": 129.088153
      },
      "address": "트루바두르 부산대점 방문",
      "address2": "트루바두르 부산대점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 292,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.211595,
        "lng": 129.079938
      },
      "address": "동래구보건소(11:30~13:00)",
      "address2": "동래구보건소(11:30~13:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 293,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.24231,
        "lng": 129.092472
      },
      "address": "금정구 보건소",
      "address2": "금정구 보건소",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 294,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.187418,
        "lng": 129.059155
      },
      "address": "부산의료원(13:30)",
      "address2": "부산의료원(13:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 295,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.95736,
        "lng": 128.913157
      },
      "address": "영남대학교 영천병원 응급실 (19시 49분~19시 57분)",
      "address2": "영남대학교 영천병원 응급실 (19시 49분~19시 57분)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 296,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.963686,
        "lng": 128.936658
      },
      "address": "새영천경대연합정형외과의원 (10:40 ~ 14:00)",
      "address2": "새영천경대연합정형외과의원 (10:40 ~ 14:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 297,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.22959,
        "lng": 129.087132
      },
      "address": "이솝페이블 방문",
      "address2": "이솝페이블 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 298,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.212661,
        "lng": 129.078325
      },
      "address": "동래봄산부인과 방문",
      "address2": "동래봄산부인과 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 299,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.214593,
        "lng": 129.076954
      },
      "address": "명가김밥 방문",
      "address2": "명가김밥 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 300,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.957297,
        "lng": 128.913191
      },
      "address": "영남대학교영천병원 응급실(2/16 19:49~19:57)",
      "address2": "영남대학교영천병원 응급실(2/16 19:49~19:57)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 301,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.966525,
        "lng": 129.415593
      },
      "address": "CU포항오천점(23:10)",
      "address2": "CU포항오천점(23:10)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 302,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.963652,
        "lng": 128.936691
      },
      "address": "새영천경대연합정형외과 (2/17 10:40 ~ 14:00)",
      "address2": "새영천경대연합정형외과 (2/17 10:40 ~ 14:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 303,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 34.871866,
        "lng": 128.722149
      },
      "address": "대우병원 선별진료소 방문",
      "address2": "대우병원 선별진료소 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 304,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 34.891502,
        "lng": 128.63778
      },
      "address": "수양동 펫앤켓 방문",
      "address2": "수양동 펫앤켓 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 305,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.963639,
        "lng": 128.936715
      },
      "address": "새영천약국 (2/17 14:00)",
      "address2": "새영천약국 (2/17 14:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 306,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.871238,
        "lng": 128.733706
      },
      "address": "안심역-반월당역 (2/16 14:10~14:40)",
      "address2": "안심역-반월당역 (2/16 14:10~14:40)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 307,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.967593,
        "lng": 129.415787
      },
      "address": "오천 엄마김밥 방문(07:15)",
      "address2": "오천 엄마김밥 방문(07:15)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 308,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.840418,
        "lng": 128.622944
      },
      "address": "굿모닝 정형외과 치료 방문",
      "address2": "굿모닝 정형외과 치료 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 309,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.970637,
        "lng": 129.40414
      },
      "address": "키햐아 문덕점 방문(21:00)",
      "address2": "키햐아 문덕점 방문(21:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 310,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.030338,
        "lng": 129.338094
      },
      "address": "이동 동해해물찜 방문(18:15)",
      "address2": "이동 동해해물찜 방문(18:15)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 311,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.97619,
        "lng": 128.944844
      },
      "address": "안심의원 방문 (2/17)",
      "address2": "안심의원 방문 (2/17)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 312,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.0762169,
        "lng": 129.3849363
      },
      "address": "장성동 엄버지기 뒷고기 식사 (20:00 ~ 21:30)",
      "address2": "장성동 엄버지기 뒷고기 식사 (20:00 ~ 21:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 313,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.646792,
        "lng": 126.681622
      },
      "address": "신명태명가 식당(자차로 이동)",
      "address2": "신명태명가 식당(자차로 이동)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 314,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.976334,
        "lng": 128.944793
      },
      "address": "장수약국 방문 (2/17)",
      "address2": "장수약국 방문 (2/17)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 315,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.621468,
        "lng": 128.152418
      },
      "address": "문경 휴게소 군자 톨게이트 쉼터 이용",
      "address2": "문경 휴게소 군자 톨게이트 쉼터 이용",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 316,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.025724,
        "lng": 129.339361
      },
      "address": "다이소 대잠점(19:30)",
      "address2": "다이소 대잠점(19:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 317,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.013244,
        "lng": 129.349514
      },
      "address": "그랜드그랜드에비뉴 6층 왕돈까스/홈플러스 방문(12:30~/13:30~)",
      "address2": "그랜드그랜드에비뉴 6층 왕돈까스/홈플러스 방문(12:30~/13:30~)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 318,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.6412422,
        "lng": 126.657421
      },
      "address": "다솜약국",
      "address2": "다솜약국",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 319,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.034439,
        "lng": 129.364462
      },
      "address": "농협은행 포항시지부 방문(12:30)",
      "address2": "농협은행 포항시지부 방문(12:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 320,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.976073,
        "lng": 128.950078
      },
      "address": "큰사랑지역아동센터 출근 (2/18 10:00)",
      "address2": "큰사랑지역아동센터 출근 (2/18 10:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 321,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.035151,
        "lng": 129.366078
      },
      "address": "다이소 죽도시장점 방문(12:40~13:40)",
      "address2": "다이소 죽도시장점 방문(12:40~13:40)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 322,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.6324471,
        "lng": 126.7094558
      },
      "address": "김포우리병원(19:30)",
      "address2": "김포우리병원(19:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 323,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.975617,
        "lng": 128.950604
      },
      "address": "탑마트 영천점 방문 (2/18 19:15)",
      "address2": "탑마트 영천점 방문 (2/18 19:15)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 324,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.014493,
        "lng": 129.323298
      },
      "address": "포항공대 교직원 식당 방문(12:40~13:00)",
      "address2": "포항공대 교직원 식당 방문(12:40~13:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 325,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.019727,
        "lng": 129.32436
      },
      "address": "GS25편의점 지곡점(포스플렉스 상가) 방문(13:10~13:15)",
      "address2": "GS25편의점 지곡점(포스플렉스 상가) 방문(13:10~13:15)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 326,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.4725032,
        "lng": 126.440156
      },
      "address": "인천공항 -> 안계 이동 (전세버스)",
      "address2": "인천공항 -> 안계 이동 (전세버스)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 327,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.033235,
        "lng": 129.316941
      },
      "address": "지곡그린의원/그린약국 방문(9:20~9:40)",
      "address2": "지곡그린의원/그린약국 방문(9:20~9:40)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 328,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.942475,
        "lng": 128.89908
      },
      "address": "선헤어샵 영업 (2/17 15:00 ~ 16:00, 2/18 16:00~20:00)",
      "address2": "선헤어샵 영업 (2/17 15:00 ~ 16:00, 2/18 16:00~20:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 329,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.12555,
        "lng": 126.880243
      },
      "address": "메디팜큰사랑약국 방문",
      "address2": "메디팜큰사랑약국 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 330,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.125636,
        "lng": 126.880207
      },
      "address": "이삭토스트 풍암점 방문",
      "address2": "이삭토스트 풍암점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 331,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.00766020375492,
        "lng": 129.32988568343504
      },
      "address": "참뼈효자점(12:00~12:40)",
      "address2": "참뼈효자점(12:00~12:40)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 332,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.3868433,
        "lng": 128.4393344
      },
      "address": "안계성당 도착 (21:00)",
      "address2": "안계성당 도착 (21:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 333,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.040963,
        "lng": 128.788721
      },
      "address": "신녕버스정류장 (2/16 08:00 818번 탑승 안심역 방면)",
      "address2": "신녕버스정류장 (2/16 08:00 818번 탑승 안심역 방면)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 334,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.01412979681293,
        "lng": 129.32094682275698
      },
      "address": "포항공대 복지관 매점 방문(18:43)",
      "address2": "포항공대 복지관 매점 방문(18:43)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 335,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.2676335,
        "lng": 128.744376
      },
      "address": "21:00 경북보건환경연구원 양성자 확진",
      "address2": "21:00 경북보건환경연구원 양성자 확진",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 336,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.016858,
        "lng": 129.323511
      },
      "address": "포항공대 국제관 식당 점심식사(12:00~13:10)",
      "address2": "포항공대 국제관 식당 점심식사(12:00~13:10)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 337,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.871196,
        "lng": 128.733827
      },
      "address": "안심역 하차, 탑승 (2/16 09:00, 16:20 818번)",
      "address2": "안심역 하차, 탑승 (2/16 09:00, 16:20 818번)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 338,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.3888985,
        "lng": 128.4354007
      },
      "address": "안계홈마트 방문 (12:40)",
      "address2": "안계홈마트 방문 (12:40)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 339,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.481161,
        "lng": 127.01376
      },
      "address": "백년옥 본관 방문",
      "address2": "백년옥 본관 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 340,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.465851,
        "lng": 127.028293
      },
      "address": "한국교총 출근",
      "address2": "한국교총 출근",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 341,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.539403,
        "lng": 129.353792
      },
      "address": "울산 태화강역 하차, 승차(2/17 8:33, 14:04)",
      "address2": "울산 태화강역 하차, 승차(2/17 8:33, 14:04)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 342,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.519967,
        "lng": 129.428969
      },
      "address": "울산대학교병원 비뇨기과 진료 (2/17 10:00)",
      "address2": "울산대학교병원 비뇨기과 진료 (2/17 10:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 343,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.642134,
        "lng": 126.829043
      },
      "address": "명지병원(15:30)",
      "address2": "명지병원(15:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 344,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.3513241,
        "lng": 127.1212433
      },
      "address": "분당서울대병원(명지병원 -> 분당서울대병원 이송 후 격리)",
      "address2": "분당서울대병원(명지병원 -> 분당서울대병원 이송 후 격리)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 345,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.14006,
        "lng": 128.112829
      },
      "address": "김천시보건소 선별진료소 진료(11:00)>자택 귀가(대구 달서구) (김천시내 방문X)",
      "address2": "김천시보건소 선별진료소 진료(11:00)>자택 귀가(대구 달서구) (김천시내 방문X)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 346,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.3868433,
        "lng": 128.4393344
      },
      "address": "안계성당 도착 (21:00)",
      "address2": "안계성당 도착 (21:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 347,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.847313,
        "lng": 128.58481
      },
      "address": "안심의원 진료 (2/19 10:00 ~ 11:00)",
      "address2": "안심의원 진료 (2/19 10:00 ~ 11:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 348,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.6408747,
        "lng": 126.659757
      },
      "address": "뉴고려병원(17:39 - 선별진료소에서 검체채취 후 택시 귀가)",
      "address2": "뉴고려병원(17:39 - 선별진료소에서 검체채취 후 택시 귀가)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 349,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.883879,
        "lng": 128.624049
      },
      "address": "대구 파티마병원 검체체취 및 진료 (2/20 14:00 ~ 19:00)",
      "address2": "대구 파티마병원 검체체취 및 진료 (2/20 14:00 ~ 19:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 350,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.3548244,
        "lng": 128.7048378
      },
      "address": "17:00~19:00 : 안사면 쌍호1리 경로당 저녁식사",
      "address2": "17:00~19:00 : 안사면 쌍호1리 경로당 저녁식사",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 351,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.642134,
        "lng": 126.829043
      },
      "address": "명지병원(20:00 격리)",
      "address2": "명지병원(20:00 격리)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 352,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.642134,
        "lng": 126.829043
      },
      "address": "분당서울대병원(격리 - #140, #162 자녀)",
      "address2": "분당서울대병원(격리 - #140, #162 자녀)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 353,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.8261469,
        "lng": 128.7371953
      },
      "address": "13:00 : 경산세명장례식장 방문(형님 동행)",
      "address2": "13:00 : 경산세명장례식장 방문(형님 동행)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 354,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.1821593,
        "lng": 128.1031336
      },
      "address": "다다인 방문 후 자가용 귀가(2/17)",
      "address2": "다다인 방문 후 자가용 귀가(2/17)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 355,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.564992,
        "lng": 128.7318366
      },
      "address": "서울갈비 (2/17)",
      "address2": "서울갈비 (2/17)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 356,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.5675074,
        "lng": 128.7252097
      },
      "address": " 천주교 목성동 성당 (2/18)",
      "address2": " 천주교 목성동 성당 (2/18)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 357,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.5655359,
        "lng": 128.7372701
      },
      "address": "해동사 방문 (2/18)",
      "address2": "해동사 방문 (2/18)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 358,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.569938,
        "lng": 128.7293195
      },
      "address": "북문동 할매보리밥 (2/18)",
      "address2": "북문동 할매보리밥 (2/18)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 359,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.5474192,
        "lng": 128.7009159
      },
      "address": "교통안전공단 안동자동차검사소 (2/18)",
      "address2": "교통안전공단 안동자동차검사소 (2/18)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 360,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.109328,
        "lng": 128.415011
      },
      "address": "삼성전자 구미2사업장 (2/22)",
      "address2": "삼성전자 구미2사업장 (2/22)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 361,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 7.3224952,
        "lng": 127.0954908
      },
      "address": "수지구보건소(오전 검체 채취)",
      "address2": "수지구보건소(오전 검체 채취)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 362,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.867291,
        "lng": 128.591114
      },
      "address": "대구 스시준 방문 (2/13)",
      "address2": "대구 스시준 방문 (2/13)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 363,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.1539,
        "lng": 129.054335
      },
      "address": "부산진구 네오스파 찜질방 숙박 (2/18 ~ 2/21)",
      "address2": "부산진구 네오스파 찜질방 숙박 (2/18 ~ 2/21)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 364,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.109694,
        "lng": 128.364828
      },
      "address": "이마트 구미점 2층 전자기기 매장 방문(20:00~21:30)",
      "address2": "이마트 구미점 2층 전자기기 매장 방문(20:00~21:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 365,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.110723,
        "lng": 128.335488
      },
      "address": "황가정 의학과 방문(11:00~11:30)",
      "address2": "황가정 의학과 방문(11:00~11:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 366,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.114371,
        "lng": 128.340569
      },
      "address": "구미차병원 선별진료소 재방문(7:00~9:30)",
      "address2": "구미차병원 선별진료소 재방문(7:00~9:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 367,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.649848,
        "lng": 126.793746
      },
      "address": " 백석동 유니테크빌 벤쳐타운 출근 후, 동안 한의원 방문(~11:00)",
      "address2": " 백석동 유니테크빌 벤쳐타운 출근 후, 동안 한의원 방문(~11:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 368,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.291899,
        "lng": 127.067184
      },
      "address": "스타벅스 수원법조타운점 방문(13:00)",
      "address2": "스타벅스 수원법조타운점 방문(13:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 369,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.279206,
        "lng": 127.044022
      },
      "address": "투썸플레이스 아주대점(19:00경)",
      "address2": "투썸플레이스 아주대점(19:00경)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 370,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.3132824,
        "lng": 127.0876936
      },
      "address": "다경식당 식사(12:00 ~ 13:00, 방역 및 폐쇄)",
      "address2": "다경식당 식사(12:00 ~ 13:00, 방역 및 폐쇄)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 371,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.1594495,
        "lng": 129.1397183
      },
      "address": "해운대 수영만요트경기장 (2/15)",
      "address2": "해운대 수영만요트경기장 (2/15)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 372,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.8321078,
        "lng": 128.6045133
      },
      "address": "고산골장가네순두부보쌈 방문 (2/18 11:30~)",
      "address2": "고산골장가네순두부보쌈 방문 (2/18 11:30~)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 373,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.8342458,
        "lng": 128.6011679
      },
      "address": "대구효명초등학교 (2/18 09:00~09:30, 13:20~14:00)",
      "address2": "대구효명초등학교 (2/18 09:00~09:30, 13:20~14:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 374,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.8413342,
        "lng": 128.5522156
      },
      "address": "제일내과의원 방문 (2/18)",
      "address2": "제일내과의원 방문 (2/18)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 375,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.9250416,
        "lng": 128.533377
      },
      "address": "칠곡운전면허시험장 방문 (2/21)",
      "address2": "칠곡운전면허시험장 방문 (2/21)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 376,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.4862127,
        "lng": 129.4240211
      },
      "address": "동구 방어동행정복지센터 방문 (2/20 16:30)",
      "address2": "동구 방어동행정복지센터 방문 (2/20 16:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 377,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 34.8914945,
        "lng": 128.6357127
      },
      "address": "펫앤캣 애견샵 방문 (2/21 16:00)",
      "address2": "펫앤캣 애견샵 방문 (2/21 16:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 378,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.562259,
        "lng": 128.700755
      },
      "address": "옥동 굿네이버스 좋은마음센터 경북북부지부 근무 (2/14 8:40~)",
      "address2": "옥동 굿네이버스 좋은마음센터 경북북부지부 근무 (2/14 8:40~)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 379,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.574535,
        "lng": 128.675659
      },
      "address": "안동버스터미널 - 동대구터미널 버스 (2/14 19:20, 2/16 21:00 ~ 22:27) ",
      "address2": "안동버스터미널 - 동대구터미널 버스 (2/14 19:20, 2/16 21:00 ~ 22:27) ",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 380,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.8775,
        "lng": 128.62935
      },
      "address": "안동버스터미널 - 동대구터미널행 버스 (2/14 19:20, 2/16 21:00 ~ 22:27) ",
      "address2": "안동버스터미널 - 동대구터미널행 버스 (2/14 19:20, 2/16 21:00 ~ 22:27) ",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 381,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.867699,
        "lng": 128.597082
      },
      "address": "대구 갓파스시 식사 (2/16 18:30 ~ 19:20)",
      "address2": "대구 갓파스시 식사 (2/16 18:30 ~ 19:20)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 382,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.562259,
        "lng": 128.700755
      },
      "address": "옥동 굿네이버스 좋은마음센터 경북북부지부 근무 (2/14,17,18,19 8:40 ~ 18:00, 19일의 경우 단축근무)",
      "address2": "옥동 굿네이버스 좋은마음센터 경북북부지부 근무 (2/14,17,18,19 8:40 ~ 18:00, 19일의 경우 단축근무)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 383,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.566065,
        "lng": 128.69881
      },
      "address": "성모이비인후과 진료 (2/19 09:10 ~)",
      "address2": "성모이비인후과 진료 (2/19 09:10 ~)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 384,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.566059,
        "lng": 128.698756
      },
      "address": "프라자약국 방문 (2/19 09:10 ~)",
      "address2": "프라자약국 방문 (2/19 09:10 ~)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 385,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.546965,
        "lng": 128.700668
      },
      "address": "안동병원 선별진료소 방문 (2/20 14:30 ~ 14:50)",
      "address2": "안동병원 선별진료소 방문 (2/20 14:30 ~ 14:50)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 386,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.562446,
        "lng": 128.716939
      },
      "address": "안동복주여중 지나감 (2/16 21:30)",
      "address2": "안동복주여중 지나감 (2/16 21:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 387,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.560841,
        "lng": 128.700276
      },
      "address": "착한낙지 옥동점 식사 (2/20 18:00 ~ 20:00)",
      "address2": "착한낙지 옥동점 식사 (2/20 18:00 ~ 20:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 388,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.5368909,
        "lng": 129.3288589
      },
      "address": "다인오피스텔홍보관 (2/20 18:00_19:00)",
      "address2": "다인오피스텔홍보관 (2/20 18:00_19:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 389,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.559495,
        "lng": 128.700123
      },
      "address": "옥동 하프플로어 카페 방문 (2/20 20:00 ~ 20:30)",
      "address2": "옥동 하프플로어 카페 방문 (2/20 20:00 ~ 20:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 390,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.4313048,
        "lng": 127.1670716
      },
      "address": "성남시 신한은행 성남공단금융센터(18~21일 근무)",
      "address2": "성남시 신한은행 성남공단금융센터(18~21일 근무)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 391,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.515426,
        "lng": 126.907124
      },
      "address": "영등포역 방문 (2/19)",
      "address2": "영등포역 방문 (2/19)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 392,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.515943,
        "lng": 126.907483
      },
      "address": "롯데백화점 영등포점 식품관 방문 (2/19 15:00경 부터 30분)",
      "address2": "롯데백화점 영등포점 식품관 방문 (2/19 15:00경 부터 30분)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 393,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.4858735,
        "lng": 129.4207607
      },
      "address": "방어진주민센터 방문 (도보) (2/20 16:00)",
      "address2": "방어진주민센터 방문 (도보) (2/20 16:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 394,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.508811,
        "lng": 126.891205
      },
      "address": "신도림역 환승 (2/19)",
      "address2": "신도림역 환승 (2/19)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 395,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.3101929,
        "lng": 127.0957693
      },
      "address": "한국 153 근무(08:30 자가용 출근)",
      "address2": "한국 153 근무(08:30 자가용 출근)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 396,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.8585423,
        "lng": 129.1907031
      },
      "address": "동국대학교 경주병원 장례식장 (2/22)",
      "address2": "동국대학교 경주병원 장례식장 (2/22)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 397,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.195416,
        "lng": 128.7144453
      },
      "address": "성주동 프리빌리지 2차 아파트 버스정류장",
      "address2": "성주동 프리빌리지 2차 아파트 버스정류장",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 398,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.222823,
        "lng": 128.687682
      },
      "address": "시민 생활 체육관 맞은편 버스정류장",
      "address2": "시민 생활 체육관 맞은편 버스정류장",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 399,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.2211536,
        "lng": 128.6844325
      },
      "address": "한마음 창원병원 근무",
      "address2": "한마음 창원병원 근무",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 400,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.2221061,
        "lng": 128.6844131
      },
      "address": "폴리어학원 자녀픽업",
      "address2": "폴리어학원 자녀픽업",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 401,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.2279556,
        "lng": 128.6834066
      },
      "address": "창원보건소  확진검사 (19:00)",
      "address2": "창원보건소  확진검사 (19:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 402,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.1987691,
        "lng": 128.705938
      },
      "address": "확진판정 후 창원경상대 병원 이송 (04:15)",
      "address2": "확진판정 후 창원경상대 병원 이송 (04:15)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 403,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.1990977,
        "lng": 128.5644577
      },
      "address": "확진 판정 후 마산의료원  이송 (05:00)",
      "address2": "확진 판정 후 마산의료원  이송 (05:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 404,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.633918,
        "lng": 126.916581
      },
      "address": "은평구 가톨릭 성모병원 간병인으로 근무(병원에서 숙식)",
      "address2": "은평구 가톨릭 성모병원 간병인으로 근무(병원에서 숙식)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 405,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.12185,
        "lng": 128.33995
      },
      "address": "아트앤하트미술학원 송정동 (2/17,18,19,20 12:00 ~ 19:00, 21일 조기퇴근)",
      "address2": "아트앤하트미술학원 송정동 (2/17,18,19,20 12:00 ~ 19:00, 21일 조기퇴근)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 406,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.507026,
        "lng": 126.960512
      },
      "address": "중대병원 이송(격리 조치)",
      "address2": "중대병원 이송(격리 조치)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 407,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.3930351643306,
        "lng": 126.95205046262001
      },
      "address": "동안구보건소 선별진료소(2/23 검체 채취)",
      "address2": "동안구보건소 선별진료소(2/23 검체 채취)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 408,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.121939,
        "lng": 128.340031
      },
      "address": "DC마트 방문 (2/18)",
      "address2": "DC마트 방문 (2/18)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 409,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.531861,
        "lng": 127.124965
      },
      "address": "삼성내과 방문",
      "address2": "삼성내과 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 410,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.535983,
        "lng": 127.132187
      },
      "address": "강동역 하차 후 도보로 귀가",
      "address2": "강동역 하차 후 도보로 귀가",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 411,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.427291,
        "lng": 126.9907995
      },
      "address": "과천 신천지 교회 9층(2/16 12:00 예배 참석)",
      "address2": "과천 신천지 교회 9층(2/16 12:00 예배 참석)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 412,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.3913922574005,
        "lng": 126.953447277579
      },
      "address": "평촌범계약국",
      "address2": "평촌범계약국",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 413,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.057903,
        "lng": 128.494108
      },
      "address": "밀알 사랑의집 입소자 (2/18 부터 칠곡가톨릭병원으로)",
      "address2": "밀알 사랑의집 입소자 (2/18 부터 칠곡가톨릭병원으로)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 414,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.934898,
        "lng": 128.549298
      },
      "address": "장염증세로 대구 칠곡가톨릭병원 입원 (2/18 ~)",
      "address2": "장염증세로 대구 칠곡가톨릭병원 입원 (2/18 ~)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 415,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.6452257,
        "lng": 126.6908767
      },
      "address": "운양동 화성파크드림(2/18 ~ 2/21 자택->회사 출퇴근)",
      "address2": "운양동 화성파크드림(2/18 ~ 2/21 자택->회사 출퇴근)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 416,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.316832,
        "lng": 129.001614
      },
      "address": "공차 증산점 방문 (15:30)",
      "address2": "공차 증산점 방문 (15:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 417,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.310825,
        "lng": 129.006257
      },
      "address": "CU 물금나래점 방문 (2/21 20:20)",
      "address2": "CU 물금나래점 방문 (2/21 20:20)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 418,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.31632,
        "lng": 129.002477
      },
      "address": "다이소 양산증산점 방문 (2/21 15:00)",
      "address2": "다이소 양산증산점 방문 (2/21 15:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 419,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.310282,
        "lng": 129.007459
      },
      "address": "세븐일레븐 물금바젤나인점 방문 (2/21 22:00)",
      "address2": "세븐일레븐 물금바젤나인점 방문 (2/21 22:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 420,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.320423,
        "lng": 128.99725
      },
      "address": "서울온누리약국 증산점 (2/22 14:00)",
      "address2": "서울온누리약국 증산점 (2/22 14:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 421,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.7634531354371,
        "lng": 127.228428163352
      },
      "address": "천안시 무지개식당 식사(19:30~20:20)",
      "address2": "천안시 무지개식당 식사(19:30~20:20)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 422,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.5625775,
        "lng": 128.7158363
      },
      "address": "복주여중 앞에서 자가용으로 귀가(21:30~22:50)",
      "address2": "복주여중 앞에서 자가용으로 귀가(21:30~22:50)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 423,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.310762,
        "lng": 129.00639
      },
      "address": "델리랩 수제버거 물금점 (2/23 16:30)",
      "address2": "델리랩 수제버거 물금점 (2/23 16:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 424,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.309455,
        "lng": 129.00766
      },
      "address": "김영희강남동태찜 포장 (2/23 21:00)",
      "address2": "김영희강남동태찜 포장 (2/23 21:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 425,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 34.981394,
        "lng": 128.326909
      },
      "address": "고성시외버스터미널(18:00)",
      "address2": "고성시외버스터미널(18:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 426,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 34.974449,
        "lng": 128.326052
      },
      "address": "2호광장 파로마가구점 하차",
      "address2": "2호광장 파로마가구점 하차",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 427,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 34.975202,
        "lng": 128.326767
      },
      "address": "대웅뷔페를 거쳐 보경촌 돼지집까지 가로청소",
      "address2": "대웅뷔페를 거쳐 보경촌 돼지집까지 가로청소",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 428,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.8443879,
        "lng": 128.5344854
      },
      "address": "감삼DT스타벅스(17, 18일 이용)",
      "address2": "감삼DT스타벅스(17, 18일 이용)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 429,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.5516748667775,
        "lng": 126.85260143575998
      },
      "address": "GS25 화곡까치점",
      "address2": "GS25 화곡까치점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 430,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.549171372268006,
        "lng": 126.850750479918
      },
      "address": "롤리김밥",
      "address2": "롤리김밥",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 431,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.549171372268006,
        "lng": 126.850750479918
      },
      "address": "롤리김밥",
      "address2": "롤리김밥",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 432,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.55027896287321,
        "lng": 126.84883351212
      },
      "address": "양푼이동태탕 바다장어탕",
      "address2": "양푼이동태탕 바다장어탕",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 433,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.54974388975971,
        "lng": 126.85034194566299
      },
      "address": "프렌즈빈",
      "address2": "프렌즈빈",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 434,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.54961750526951,
        "lng": 126.868285554347
      },
      "address": "강서구보건소",
      "address2": "강서구보건소",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 435,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.59027240509861,
        "lng": 126.94289783071899
      },
      "address": "중앙내과의원 (홍제동)",
      "address2": "중앙내과의원 (홍제동)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 436,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.505307533885635,
        "lng": 127.00432598423035
      },
      "address": "신세계백화점 강남점",
      "address2": "신세계백화점 강남점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 437,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.4768728517033,
        "lng": 126.961805579825
      },
      "address": "대명부동산",
      "address2": "대명부동산",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 438,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.47700115295818,
        "lng": 126.96292928072465
      },
      "address": "동림오피스텔",
      "address2": "동림오피스텔",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 439,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.4773265685037,
        "lng": 126.96061148347802
      },
      "address": "장도뚝배기 낙성대점",
      "address2": "장도뚝배기 낙성대점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 440,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.4764295447952,
        "lng": 126.961774150289
      },
      "address": "삼일 공인중개사사무소",
      "address2": "삼일 공인중개사사무소",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 441,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.47538918821613,
        "lng": 126.96572021316796
      },
      "address": "원당프라자약국",
      "address2": "원당프라자약국",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 442,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.15744093195745,
        "lng": 129.11342758817509
      },
      "address": "투썸플레이스 부산광안역점",
      "address2": "투썸플레이스 부산광안역점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 443,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.48155825573261,
        "lng": 127.122672051587
      },
      "address": "배스킨라빈스 송파하비오점",
      "address2": "배스킨라빈스 송파하비오점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 444,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.631908,
        "lng": 127.505895
      },
      "address": "밥보다맛있는떡볶이방이얌 금천광장점 (2/17 15:36)",
      "address2": "밥보다맛있는떡볶이방이얌 금천광장점 (2/17 15:36)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 445,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.630605,
        "lng": 127.505526
      },
      "address": "홈플러스 익스프레스 금천점 (2/17 15:49)",
      "address2": "홈플러스 익스프레스 금천점 (2/17 15:49)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 446,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.630788,
        "lng": 127.504651
      },
      "address": "CNA 금천점 (2/18 14:15)",
      "address2": "CNA 금천점 (2/18 14:15)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 447,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.631858,
        "lng": 127.500884
      },
      "address": "에브리데이 이마트 탑동점 (2/18 14:52)",
      "address2": "에브리데이 이마트 탑동점 (2/18 14:52)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 448,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.63063,
        "lng": 127.503412
      },
      "address": "굿모닝사랑약국 방문 (2/18 15:39)",
      "address2": "굿모닝사랑약국 방문 (2/18 15:39)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 449,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.023439,
        "lng": 128.807409
      },
      "address": "거제 가덕해양파크 방문",
      "address2": "거제 가덕해양파크 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 450,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 34.829724,
        "lng": 128.703794
      },
      "address": "거제 쌤김밥 방문",
      "address2": "거제 쌤김밥 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 451,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 34.824916,
        "lng": 128.424266
      },
      "address": "루지 방문",
      "address2": "루지 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 452,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.194853,
        "lng": 128.800353
      },
      "address": "장유 스테이 볼링장 방문",
      "address2": "장유 스테이 볼링장 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 453,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 34.887603,
        "lng": 128.625321
      },
      "address": "고현더나은동물병원 방문",
      "address2": "고현더나은동물병원 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 454,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 34.871888,
        "lng": 128.722568
      },
      "address": "우당약국 방문",
      "address2": "우당약국 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 455,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.203012,
        "lng": 128.999503
      },
      "address": "구명역 승차",
      "address2": "구명역 승차",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 456,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.215074,
        "lng": 128.961475
      },
      "address": "대저역 하차",
      "address2": "대저역 하차",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 457,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.210143,
        "lng": 129.002827
      },
      "address": "구포시장 하차",
      "address2": "구포시장 하차",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 458,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 34.887613,
        "lng": 128.625138
      },
      "address": "더나은동물메디컬센터 방문",
      "address2": "더나은동물메디컬센터 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 459,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.21537,
        "lng": 128.678864
      },
      "address": "달곰김밥",
      "address2": "달곰김밥",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 460,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.24632,
        "lng": 128.915014
      },
      "address": "한일여고 승차",
      "address2": "한일여고 승차",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 461,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.24632,
        "lng": 128.915014
      },
      "address": "한일여고 승차",
      "address2": "한일여고 승차",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 462,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.24632,
        "lng": 128.915014
      },
      "address": "한일여고 승차",
      "address2": "한일여고 승차",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 463,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.215074,
        "lng": 128.961475
      },
      "address": "대저역 하차",
      "address2": "대저역 하차",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 464,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.215074,
        "lng": 128.961475
      },
      "address": "대저역 하차",
      "address2": "대저역 하차",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 465,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.553004,
        "lng": 129.269037
      },
      "address": "좋은삼정병원 방문",
      "address2": "좋은삼정병원 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 466,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.552912,
        "lng": 129.268996
      },
      "address": "상호약국 방문",
      "address2": "상호약국 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 467,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.571596,
        "lng": 129.350998
      },
      "address": "울산중구보건소 방문",
      "address2": "울산중구보건소 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 468,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.839113,
        "lng": 128.575191
      },
      "address": "제일내과의원 방문",
      "address2": "제일내과의원 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 469,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.834498,
        "lng": 128.601114
      },
      "address": "효명초 방문",
      "address2": "효명초 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 470,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.851147,
        "lng": 128.605178
      },
      "address": "대봉초 방문",
      "address2": "대봉초 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 471,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.273444,
        "lng": 129.092611
      },
      "address": "범어사역 방문(2/21 07:58)",
      "address2": "범어사역 방문(2/21 07:58)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 472,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.660293,
        "lng": 127.509629
      },
      "address": "GS25 율량주공점 (2/20 15:00)",
      "address2": "GS25 율량주공점 (2/20 15:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 473,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.660515,
        "lng": 127.506815
      },
      "address": "후레쉬마트 율량동 (2/20 15:00)",
      "address2": "후레쉬마트 율량동 (2/20 15:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 474,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.624426,
        "lng": 127.495624
      },
      "address": "효성병원 선별진료소 방문 (2/20  14:00 ~ 14:30)",
      "address2": "효성병원 선별진료소 방문 (2/20  14:00 ~ 14:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 475,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.10695,
        "lng": 129.035327
      },
      "address": "동진선박(중앙동) 방문(2/21 08:48)",
      "address2": "동진선박(중앙동) 방문(2/21 08:48)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 476,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.588217,
        "lng": 127.505942
      },
      "address": "청주시 상당구 보건소 방문 (2/21 15:00)",
      "address2": "청주시 상당구 보건소 방문 (2/21 15:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 477,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.103868,
        "lng": 129.036353
      },
      "address": "중앙역 방문(2/21 08:40)",
      "address2": "중앙역 방문(2/21 08:40)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 478,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.10695,
        "lng": 129.035327
      },
      "address": "동진선박(중앙동) 방문(2/21 13:00~18:00)",
      "address2": "동진선박(중앙동) 방문(2/21 13:00~18:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 479,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.160247,
        "lng": 129.166579
      },
      "address": "해운대팔레드시즈콘도 방문(2/21 19:30)",
      "address2": "해운대팔레드시즈콘도 방문(2/21 19:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 480,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.160247,
        "lng": 129.166579
      },
      "address": "해운대팔레드시즈콘도 방문(2/22 10:30)",
      "address2": "해운대팔레드시즈콘도 방문(2/22 10:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 481,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.583249,
        "lng": 126.926555
      },
      "address": "음식점 '소반'(홍은동) 방문 (2/19 13:00경)",
      "address2": "음식점 '소반'(홍은동) 방문 (2/19 13:00경)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 482,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.235451,
        "lng": 129.080223
      },
      "address": "부산대 금정회관 방문(2/21 12:56)",
      "address2": "부산대 금정회관 방문(2/21 12:56)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 483,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.31156,
        "lng": 129.007442
      },
      "address": "세븐일레븐 물금동진점 방문 (2/21 01:00)",
      "address2": "세븐일레븐 물금동진점 방문 (2/21 01:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 484,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.574210725029204,
        "lng": 126.910135933983
      },
      "address": "가좌보건지소 방문 (2/19 15:30)",
      "address2": "가좌보건지소 방문 (2/19 15:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 485,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.57441980379486,
        "lng": 126.91019907588093
      },
      "address": "북가좌1동주민센터방문 (2/19 15:30)",
      "address2": "북가좌1동주민센터방문 (2/19 15:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 486,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.5562410168929,
        "lng": 126.937722306731
      },
      "address": "쉬크모텔 (창천동) 1일 숙박  (2/19)",
      "address2": "쉬크모텔 (창천동) 1일 숙박  (2/19)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 487,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.55700507422813,
        "lng": 126.93774430599565
      },
      "address": "미니스톱 연대점",
      "address2": "미니스톱 연대점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 488,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.56694932271091,
        "lng": 126.90185909738
      },
      "address": "마포구보건소 방문 - 확진판정 (2/20 )",
      "address2": "마포구보건소 방문 - 확진판정 (2/20 )",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 489,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.56724946361499,
        "lng": 127.005691254159
      },
      "address": "국립중앙의료원 으로 이송 (2/20 21:00)",
      "address2": "국립중앙의료원 으로 이송 (2/20 21:00)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 490,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.215981775340005,
        "lng": 129.07717612406245
      },
      "address": "온천교회 방문(2/19 20:30)",
      "address2": "온천교회 방문(2/19 20:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 491,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.588002,
        "lng": 126.946435
      },
      "address": "펀앤펀PC방 2층 (홍제동) 방문 (2/16 12:52)",
      "address2": "펀앤펀PC방 2층 (홍제동) 방문 (2/16 12:52)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 492,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.5902399912929,
        "lng": 126.942943145886
      },
      "address": "기린약국 (홍제동) 방문 (2/17 18:08)",
      "address2": "기린약국 (홍제동) 방문 (2/17 18:08)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 493,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.59027240509861,
        "lng": 126.94289783071899
      },
      "address": "중앙내과의원  (홍제동) 방문 (2/19 09:45)",
      "address2": "중앙내과의원  (홍제동) 방문 (2/19 09:45)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 494,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.235372260576504,
        "lng": 129.08024506220448
      },
      "address": "금정회관 방문(2/20 12:36)",
      "address2": "금정회관 방문(2/20 12:36)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 495,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.2532713838143,
        "lng": 126.56268378137298
      },
      "address": "맥도날드 서귀포DT점",
      "address2": "맥도날드 서귀포DT점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 496,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.2483544970266,
        "lng": 126.50920138575
      },
      "address": "이마트 서귀포점",
      "address2": "이마트 서귀포점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 497,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.24894586738719,
        "lng": 126.507352413664
      },
      "address": "시스터필드베이커리",
      "address2": "시스터필드베이커리",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 498,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.248887841441,
        "lng": 126.50727118658499
      },
      "address": "하나은행 서귀포지점",
      "address2": "하나은행 서귀포지점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 499,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.25445673374169,
        "lng": 126.56542938872201
      },
      "address": "서귀포열린병원",
      "address2": "서귀포열린병원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 500,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.25093539168394,
        "lng": 126.43041832783432
      },
      "address": "중문농협하나로마트 본점",
      "address2": "중문농협하나로마트 본점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 501,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.274011,
        "lng": 129.086823
      },
      "address": "해피케어복지센터",
      "address2": "해피케어복지센터",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 502,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.3913922574005,
        "lng": 126.953447277579
      },
      "address": "평촌범계약국",
      "address2": "평촌범계약국",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 503,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.3913922574005,
        "lng": 126.953447277579
      },
      "address": "평촌연세내과의원",
      "address2": "평촌연세내과의원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 504,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.22127685383251,
        "lng": 129.0843085215415
      },
      "address": "해모리횟집",
      "address2": "해모리횟집",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 505,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.837851,
        "lng": 128.754514
      },
      "address": "2/15 조영동 진아샵",
      "address2": "2/15 조영동 진아샵",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 506,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.5902399912929,
        "lng": 126.942943145886
      },
      "address": "기린약국 (홍제동)",
      "address2": "기린약국 (홍제동)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 507,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.230827,
        "lng": 129.086816
      },
      "address": "제이엔제이헤어",
      "address2": "제이엔제이헤어",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 508,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.5070789578184,
        "lng": 126.49276900424401
      },
      "address": "대구발 제주 입도(QZ8125)",
      "address2": "대구발 제주 입도(QZ8125)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 509,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.251823328096094,
        "lng": 126.42567808751998
      },
      "address": "CU 제주중문점",
      "address2": "CU 제주중문점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 510,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.251707,
        "lng": 126.423325
      },
      "address": "중문 역전할머니맥주",
      "address2": "중문 역전할머니맥주",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 511,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.2519121630704,
        "lng": 126.42383178757031
      },
      "address": "준코뮤직타운 제주중문점",
      "address2": "준코뮤직타운 제주중문점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 512,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.224006430201406,
        "lng": 129.08655715094352
      },
      "address": "스타벅스 온천장역DT점 테이크아웃",
      "address2": "스타벅스 온천장역DT점 테이크아웃",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 513,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.97347969860879,
        "lng": 127.48293142101998
      },
      "address": "음성설렁탕",
      "address2": "음성설렁탕",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 514,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 33.2483544970266,
        "lng": 126.50920138575
      },
      "address": "이마트 서귀포점",
      "address2": "이마트 서귀포점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 515,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.15744093195745,
        "lng": 129.11342758817509
      },
      "address": "투썸플레이스 부산광안역점",
      "address2": "투썸플레이스 부산광안역점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 516,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.91360714738991,
        "lng": 128.8191337715366
      },
      "address": "참조은 이비인후과의원",
      "address2": "참조은 이비인후과의원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 517,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.91357418189389,
        "lng": 128.81916846333357
      },
      "address": "국민약국",
      "address2": "국민약국",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 518,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.822963214424306,
        "lng": 128.7217301280384
      },
      "address": "최용식 이비인후과의원",
      "address2": "최용식 이비인후과의원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 519,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.82299931191259,
        "lng": 128.72172648194044
      },
      "address": "명보온누리약국",
      "address2": "명보온누리약국",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 520,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.562711462773414,
        "lng": 129.26768548007058
      },
      "address": "두울원칼국수 다운점",
      "address2": "두울원칼국수 다운점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 521,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.8189299793717,
        "lng": 128.7232229663764
      },
      "address": "홈마트 옥산점",
      "address2": "홈마트 옥산점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 522,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.56953499455542,
        "lng": 129.35040542542728
      },
      "address": "울산광역시 중구보건소",
      "address2": "울산광역시 중구보건소",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 523,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.55282542977111,
        "lng": 129.26899908489065
      },
      "address": "좋은삼정병원 선별진료소",
      "address2": "좋은삼정병원 선별진료소",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 524,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.552648,
        "lng": 129.26884
      },
      "address": "삼호약국",
      "address2": "삼호약국",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 525,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.562711462773414,
        "lng": 129.26768548007058
      },
      "address": "두울원칼국수 다운점",
      "address2": "두울원칼국수 다운점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 526,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.56953499455542,
        "lng": 129.35040542542728
      },
      "address": "중구보건소 선별진료소",
      "address2": "중구보건소 선별진료소",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 527,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.48620443106542,
        "lng": 129.4240130079881
      },
      "address": "방어동주민센터",
      "address2": "방어동주민센터",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 528,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.553004,
        "lng": 129.269037
      },
      "address": "좋은삼정병원 방문",
      "address2": "좋은삼정병원 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 529,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.552912,
        "lng": 129.268996
      },
      "address": "상호약국 방문",
      "address2": "상호약국 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 530,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.571596,
        "lng": 129.350998
      },
      "address": "울산중구보건소 방문",
      "address2": "울산중구보건소 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 531,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.839113,
        "lng": 128.575191
      },
      "address": "제일내과의원 방문",
      "address2": "제일내과의원 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 532,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.834498,
        "lng": 128.601114
      },
      "address": "효명초 방문",
      "address2": "효명초 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 533,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.851147,
        "lng": 128.605178
      },
      "address": "대봉초 방문",
      "address2": "대봉초 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 534,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.3713833122834,
        "lng": 126.738410560831
      },
      "address": "GS25 G정왕IC점",
      "address2": "GS25 G정왕IC점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 535,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.3780199130881,
        "lng": 126.78571768863802
      },
      "address": "GS25 장곡푸르지오점",
      "address2": "GS25 장곡푸르지오점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 536,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.3767915755216,
        "lng": 126.788083138307
      },
      "address": "시흥경찰서",
      "address2": "시흥경찰서",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 537,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.3767915755216,
        "lng": 126.788083138307
      },
      "address": "시흥경찰서",
      "address2": "시흥경찰서",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 538,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.390893926367106,
        "lng": 126.804562164648
      },
      "address": "군자생선구이",
      "address2": "군자생선구이",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 539,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.494278075641596,
        "lng": 126.780966779124
      },
      "address": "부천시보건소",
      "address2": "부천시보건소",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 540,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.1766241640059,
        "lng": 128.80647609006255
      },
      "address": "장유율하 돈토리식당",
      "address2": "장유율하 돈토리식당",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 541,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.7383624923599,
        "lng": 127.045956826767
      },
      "address": "의정부역->소요산역 지하철으로 이동",
      "address2": "의정부역->소요산역 지하철으로 이동",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 542,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.9488975919392,
        "lng": 127.061128608638
      },
      "address": "소요산역 1호선",
      "address2": "소요산역 1호선",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 543,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.19468929096411,
        "lng": 128.80033282853657
      },
      "address": "스테이락볼링장",
      "address2": "스테이락볼링장",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 544,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.879323993179504,
        "lng": 128.62839377538825
      },
      "address": "동대구역",
      "address2": "동대구역",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 545,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.49261844867859,
        "lng": 126.72341933842698
      },
      "address": "우리은행 부평금융센터",
      "address2": "우리은행 부평금융센터",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 546,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 38.024958,
        "lng": 127.068072
      },
      "address": "전곡 블루가이 미용실에서 이발",
      "address2": "전곡 블루가이 미용실에서 이발",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 547,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 38.026251187345494,
        "lng": 127.06833623691
      },
      "address": "메가커피 연천전곡점 방문",
      "address2": "메가커피 연천전곡점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 548,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 38.025339801929,
        "lng": 127.06772948334802
      },
      "address": "롯데리아 전곡점 방문",
      "address2": "롯데리아 전곡점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 549,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 38.0263489033651,
        "lng": 127.06761651843502
      },
      "address": "GS25 연천전곡점 방문",
      "address2": "GS25 연천전곡점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 550,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.493638952611185,
        "lng": 126.728323233836
      },
      "address": "부평5동주민센터",
      "address2": "부평5동주민센터",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 551,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.4788434212658,
        "lng": 126.668610185659
      },
      "address": "인천광역시의료원",
      "address2": "인천광역시의료원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 552,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.892051,
        "lng": 127.052988
      },
      "address": "생고기 제작소 동두천점 방문",
      "address2": "생고기 제작소 동두천점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 553,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 38.024923,
        "lng": 127.068647
      },
      "address": "마왕족발 전곡점 방문",
      "address2": "마왕족발 전곡점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 554,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 38.026808,
        "lng": 127.068014
      },
      "address": "전곡 대륙정육점 방문",
      "address2": "전곡 대륙정육점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 555,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 38.0275708079992,
        "lng": 127.067180281749
      },
      "address": "전곡국민마트 방문",
      "address2": "전곡국민마트 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 556,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.55656604930032,
        "lng": 129.30906954688896
      },
      "address": "그린약국 방문",
      "address2": "그린약국 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 557,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.55484850240792,
        "lng": 129.30860567403693
      },
      "address": "GS25 리버스위트점 방문",
      "address2": "GS25 리버스위트점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 558,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.55451723367072,
        "lng": 129.30877700282792
      },
      "address": "LG전자베스트샵 태화점 방문",
      "address2": "LG전자베스트샵 태화점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 559,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.54909094925481,
        "lng": 129.30812299649892
      },
      "address": "태화로터리에서 시외버스 탑승",
      "address2": "태화로터리에서 시외버스 탑승",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 560,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.834415715214206,
        "lng": 128.60096460506324
      },
      "address": "효명초등학교 방문",
      "address2": "효명초등학교 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 561,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.83207942506239,
        "lng": 128.60451637369425
      },
      "address": "고산골 장가네순두부보쌈 방문",
      "address2": "고산골 장가네순두부보쌈 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 562,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.83885908824771,
        "lng": 128.57541360401623
      },
      "address": "정열PC 방문",
      "address2": "정열PC 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 563,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.8388656512783,
        "lng": 128.5751879641532
      },
      "address": "제일내과의원 방문",
      "address2": "제일내과의원 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 564,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.8393325667357,
        "lng": 128.5755911894652
      },
      "address": "명랑핫도그 대구안지랑점 방문",
      "address2": "명랑핫도그 대구안지랑점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 565,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.850973161796,
        "lng": 128.60516709579827
      },
      "address": "대봉초등학교 방문",
      "address2": "대봉초등학교 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 566,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.56061891788103,
        "lng": 129.34203783627524
      },
      "address": "학성초등학교 옆 정류장에서 택시 탑승",
      "address2": "학성초등학교 옆 정류장에서 택시 탑승",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 567,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.15744093195745,
        "lng": 129.11342758817509
      },
      "address": "투썸플레이스 부산광안역점 (2/20)",
      "address2": "투썸플레이스 부산광안역점 (2/20)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 568,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.16022330602121,
        "lng": 129.16658444358296
      },
      "address": "팔레드시즈 콘도 (2/21, 22)",
      "address2": "팔레드시즈 콘도 (2/21, 22)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 569,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.27306418469921,
        "lng": 129.09264113342854
      },
      "address": "범어사역 부산1호선 (2/21)",
      "address2": "범어사역 부산1호선 (2/21)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 570,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.103723215314204,
        "lng": 129.03636392432824
      },
      "address": "중앙역 부산1호선 (2/21)",
      "address2": "중앙역 부산1호선 (2/21)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 571,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.10694743675871,
        "lng": 129.0354089375253
      },
      "address": "동진선박 방문 (2/21)",
      "address2": "동진선박 방문 (2/21)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 572,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.96320059916855,
        "lng": 128.93508599668982
      },
      "address": "아디다스 영천점 방문",
      "address2": "아디다스 영천점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 573,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.9632543912451,
        "lng": 128.93610812934787
      },
      "address": "랜드로바 영천점 방문",
      "address2": "랜드로바 영천점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 574,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.963587001819796,
        "lng": 128.93604531484186
      },
      "address": "정이비인후과 방문",
      "address2": "정이비인후과 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 575,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.9635647407414,
        "lng": 128.93608467315386
      },
      "address": "완산약국 방문",
      "address2": "완산약국 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 576,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.968600511032406,
        "lng": 128.93247437575187
      },
      "address": "영천시보건소 선별진료소",
      "address2": "영천시보건소 선별진료소",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 577,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.1958269358324,
        "lng": 129.06038874293435
      },
      "address": "탐플레이스PC방 부산사직점 (2/20)",
      "address2": "탐플레이스PC방 부산사직점 (2/20)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 578,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.19618253648551,
        "lng": 129.06067437620936
      },
      "address": "스타뮤직동전노래연습장 방문 (2/20)",
      "address2": "스타뮤직동전노래연습장 방문 (2/20)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 579,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.9765907161285,
        "lng": 128.9452181919589
      },
      "address": "시골여행 점심식사",
      "address2": "시골여행 점심식사",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 580,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.9763313635004,
        "lng": 128.94476396630887
      },
      "address": "안심의원 방문",
      "address2": "안심의원 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 581,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.81486632361789,
        "lng": 128.7310920254401
      },
      "address": "you헤어 경산점",
      "address2": "you헤어 경산점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 582,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.8187438625346,
        "lng": 128.72539192848842
      },
      "address": "아틀리에빈 경산옥산점",
      "address2": "아틀리에빈 경산옥산점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 583,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.840316496684714,
        "lng": 128.70516031667842
      },
      "address": "파리바게뜨 시지아레나점",
      "address2": "파리바게뜨 시지아레나점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 584,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.83983721484,
        "lng": 128.70521535215036
      },
      "address": "시레나커피",
      "address2": "시레나커피",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 585,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.838535018086695,
        "lng": 128.75977343998645
      },
      "address": "세븐일레븐 영대제일원룸점",
      "address2": "세븐일레븐 영대제일원룸점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 586,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.839745536344715,
        "lng": 128.7073559670624
      },
      "address": "이서이비인후과",
      "address2": "이서이비인후과",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 587,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.839942743398595,
        "lng": 128.7069219386234
      },
      "address": "메디빌약국",
      "address2": "메디빌약국",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 588,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.854379507891494,
        "lng": 128.65405539230682
      },
      "address": "미니스톱 달구벌대로점",
      "address2": "미니스톱 달구벌대로점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 589,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.854028767261404,
        "lng": 128.6549203513433
      },
      "address": "아틀리에빈 담티점",
      "address2": "아틀리에빈 담티점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 590,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.8383184281012,
        "lng": 128.75634681953446
      },
      "address": "포스마트 영남대학점",
      "address2": "포스마트 영남대학점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 591,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.854028767261404,
        "lng": 128.6549203513433
      },
      "address": "아틀리에빈 담티점",
      "address2": "아틀리에빈 담티점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 592,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.84095597714584,
        "lng": 128.70448451978456
      },
      "address": "세븐일레븐 대구신매역사점",
      "address2": "세븐일레븐 대구신매역사점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 593,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.839745536344715,
        "lng": 128.7073559670624
      },
      "address": "이서이비인후과",
      "address2": "이서이비인후과",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 594,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.839942743398595,
        "lng": 128.7069219386234
      },
      "address": "메디빌약국",
      "address2": "메디빌약국",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 595,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.8401652779424,
        "lng": 128.7062272672914
      },
      "address": "시지광장약국",
      "address2": "시지광장약국",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 596,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.8393469794181,
        "lng": 128.70826155632238
      },
      "address": "교토st",
      "address2": "교토st",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 597,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.839946409700886,
        "lng": 128.70691759036538
      },
      "address": "김준홍이비인후과의원",
      "address2": "김준홍이비인후과의원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 598,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.839942743398595,
        "lng": 128.7069219386234
      },
      "address": "메디빌약국",
      "address2": "메디빌약국",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 599,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.864600040207414,
        "lng": 128.59585026286123
      },
      "address": "로제피부과의원 중앙점",
      "address2": "로제피부과의원 중앙점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 600,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.864420692602394,
        "lng": 128.59334026849024
      },
      "address": "홍스떡볶이 반월당점",
      "address2": "홍스떡볶이 반월당점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 601,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.86584251496489,
        "lng": 128.59321817162123
      },
      "address": "몬스터커피 반월당",
      "address2": "몬스터커피 반월당",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 602,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.83838300826918,
        "lng": 128.75642903073853
      },
      "address": "CU 영대경산점",
      "address2": "CU 영대경산점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 603,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.8122871887642,
        "lng": 128.75557409209645
      },
      "address": "소루 경산사동점",
      "address2": "소루 경산사동점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 604,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.8212290604591,
        "lng": 128.8243564139486
      },
      "address": "자인초등학교",
      "address2": "자인초등학교",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 605,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.81908087490171,
        "lng": 128.82292646753058
      },
      "address": "영미디지털스튜디오",
      "address2": "영미디지털스튜디오",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 606,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.8202924067565,
        "lng": 128.8238481548606
      },
      "address": "자인농협 본점",
      "address2": "자인농협 본점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 607,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.198585597593485,
        "lng": 129.057355904131
      },
      "address": "삼성서울내과 방문",
      "address2": "삼성서울내과 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 608,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.21141202010109,
        "lng": 129.07985303660647
      },
      "address": "동래구 보건소 방문",
      "address2": "동래구 보건소 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 609,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.020324307803,
        "lng": 126.791216107466
      },
      "address": "미풍해장국 (나주혁신점) 방문",
      "address2": "미풍해장국 (나주혁신점) 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 610,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.01846344368172,
        "lng": 126.79520252378528
      },
      "address": "한국인터넷진흥원 방문",
      "address2": "한국인터넷진흥원 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 611,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.451019838612694,
        "lng": 126.866112424383
      },
      "address": "광명시 소재 식당 이용",
      "address2": "광명시 소재 식당 이용",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 612,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.448312431419,
        "lng": 126.882327647416
      },
      "address": "하나로마트 광명 농협 가리대점",
      "address2": "하나로마트 광명 농협 가리대점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 613,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.23139580301661,
        "lng": 129.08864865249254
      },
      "address": "맛나감자탕 부산대점 방문",
      "address2": "맛나감자탕 부산대점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 614,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.2302178043053,
        "lng": 129.0879814501315
      },
      "address": "ZARA 부산대점 방문",
      "address2": "ZARA 부산대점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 615,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.14632389348339,
        "lng": 129.02083598513693
      },
      "address": "인제대학교 부산백병원 방문",
      "address2": "인제대학교 부산백병원 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 616,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.210665466529406,
        "lng": 129.0374945357873
      },
      "address": "우리마트 만덕점 방문",
      "address2": "우리마트 만덕점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 617,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.211439084092014,
        "lng": 129.03779057529925
      },
      "address": "하동돌솥밥 방문",
      "address2": "하동돌솥밥 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 618,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.155212473839,
        "lng": 129.06097680121138
      },
      "address": "옵포드 방문",
      "address2": "옵포드 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 619,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.155643435520204,
        "lng": 129.0607528579674
      },
      "address": "샤오시안 방문",
      "address2": "샤오시안 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 620,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.1561218199345,
        "lng": 129.05996610686037
      },
      "address": "훈혁 방문",
      "address2": "훈혁 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 621,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.210010627983806,
        "lng": 129.00722128417317
      },
      "address": "153구포국수 덕천점 방문",
      "address2": "153구포국수 덕천점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 622,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.208498030784185,
        "lng": 129.0090945585202
      },
      "address": "엔에프커피엔케이크 방문",
      "address2": "엔에프커피엔케이크 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 623,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.6604485343049,
        "lng": 126.768896925364
      },
      "address": "화이트치과",
      "address2": "화이트치과",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 624,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.20912091243989,
        "lng": 129.00892105150015
      },
      "address": "커피요정 방문",
      "address2": "커피요정 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 625,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.209861360686,
        "lng": 129.00817947080117
      },
      "address": "부잣집 방문",
      "address2": "부잣집 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 626,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.20992338817636,
        "lng": 129.00661303096578
      },
      "address": "공차 부산덕천점 방문",
      "address2": "공차 부산덕천점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 627,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.869599889826894,
        "lng": 126.7849815819108
      },
      "address": "홈플러스 파주문산점",
      "address2": "홈플러스 파주문산점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 628,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.23925667006297,
        "lng": 129.01477620046512
      },
      "address": "북구보건소 방문",
      "address2": "북구보건소 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 629,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.86331160513469,
        "lng": 126.773624258629
      },
      "address": "GS수퍼마켓 파주문산점",
      "address2": "GS수퍼마켓 파주문산점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 630,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.86441977829149,
        "lng": 126.78222599268899
      },
      "address": "플러스마트",
      "address2": "플러스마트",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 631,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.4192183,
        "lng": 128.1521353
      },
      "address": "맹구막창",
      "address2": "맹구막창",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 632,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.42244282320391,
        "lng": 128.18400218634304
      },
      "address": "국민체육센터 수영장",
      "address2": "국민체육센터 수영장",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 633,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.41040689765928,
        "lng": 128.16131330917602
      },
      "address": "2/18, 2/19 남성동성당미사참석",
      "address2": "2/18, 2/19 남성동성당미사참석",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 634,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.404336957929,
        "lng": 128.14976784614302
      },
      "address": "개운궁식당",
      "address2": "개운궁식당",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 635,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.20912091243989,
        "lng": 129.00892105150015
      },
      "address": "커피요정",
      "address2": "커피요정",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 636,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.209861360686,
        "lng": 129.00817947080117
      },
      "address": "부잣집",
      "address2": "부잣집",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 637,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.572489,
        "lng": 127.072654
      },
      "address": "S153과학학원 아르바이트",
      "address2": "S153과학학원 아르바이트",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 638,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.18681768089162,
        "lng": 129.07859802929644
      },
      "address": "아시아드요양병원",
      "address2": "아시아드요양병원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 639,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.13512519557161,
        "lng": 129.09211852431355
      },
      "address": "2/20, 2/21 지하철[대연역~수영역~연산역]이동",
      "address2": "2/20, 2/21 지하철[대연역~수영역~연산역]이동",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 640,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.16568036128701,
        "lng": 129.11480955097366
      },
      "address": "2/20, 2/21 지하철[대연역~수영역~연산역]이동",
      "address2": "2/20, 2/21 지하철[대연역~수영역~연산역]이동",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 641,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.1608998044941,
        "lng": 129.11320654836166
      },
      "address": "BHS한서병원 선별진료소",
      "address2": "BHS한서병원 선별진료소",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 642,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.165969024504406,
        "lng": 129.18503687812006
      },
      "address": "CU 해운대경남선경점",
      "address2": "CU 해운대경남선경점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 643,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.2124826165236,
        "lng": 129.07838263379648
      },
      "address": "동래봄산부인과의원",
      "address2": "동래봄산부인과의원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 644,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.20635972522261,
        "lng": 129.07389182218444
      },
      "address": "맥도날드 부산온천SK DT점",
      "address2": "맥도날드 부산온천SK DT점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 645,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.06082559625642,
        "lng": 129.37543525601947
      },
      "address": "리플러스마트 본점",
      "address2": "리플러스마트 본점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 646,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.060226381513814,
        "lng": 129.37529739394347
      },
      "address": "더벤티 포항영일대점",
      "address2": "더벤티 포항영일대점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 647,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.071848669811025,
        "lng": 129.4000937531617
      },
      "address": "선린애육원 내 별도 사무실 서류 수령",
      "address2": "선린애육원 내 별도 사무실 서류 수령",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 648,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.004570235715825,
        "lng": 129.3774981612645
      },
      "address": "2/17, 2/18, 2/19, 2/20 직장 근무(현대제철 생산관리팀)",
      "address2": "2/17, 2/18, 2/19, 2/20 직장 근무(현대제철 생산관리팀)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 649,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.1664401,
        "lng": 129.1768923
      },
      "address": "경남선경자이마트 방문",
      "address2": "경남선경자이마트 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 650,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.01191107117713,
        "lng": 129.32106361658597
      },
      "address": "포항공과대학교 제3공학관 친구 만난 후 귀가",
      "address2": "포항공과대학교 제3공학관 친구 만난 후 귀가",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 651,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.20561424504721,
        "lng": 129.0784754358185
      },
      "address": "동래역 부산1호선 도시철도 이용",
      "address2": "동래역 부산1호선 도시철도 이용",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 652,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.11454123811821,
        "lng": 129.0393442633173
      },
      "address": "부산역 부산1호선 -> KTX로 이동",
      "address2": "부산역 부산1호선 -> KTX로 이동",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 653,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.62005054337381,
        "lng": 127.327645624362
      },
      "address": "오송역 SRT -> 광주송정 이동",
      "address2": "오송역 SRT -> 광주송정 이동",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 654,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.1376351602507,
        "lng": 126.790864370399
      },
      "address": "광주송정역 SRT탑승",
      "address2": "광주송정역 SRT탑승",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 655,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.0183097,
        "lng": 126.7908682
      },
      "address": "미풍해장국 나주혁신점",
      "address2": "미풍해장국 나주혁신점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 656,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.01846344368172,
        "lng": 126.79520252378528
      },
      "address": "한국인터넷진흥원",
      "address2": "한국인터넷진흥원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 657,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.021035,
        "lng": 126.789509
      },
      "address": "빛가람 호수공원 정류장 (-> 광주송정)",
      "address2": "빛가람 호수공원 정류장 (-> 광주송정)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 658,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.11346576733731,
        "lng": 129.0398482640213
      },
      "address": "밀양돼지국밥",
      "address2": "밀양돼지국밥",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 659,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.1752121,
        "lng": 129.1162589
      },
      "address": "본인 사무실",
      "address2": "본인 사무실",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 660,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.1751111,
        "lng": 129.1161454
      },
      "address": "삼촌밥차런치펍",
      "address2": "삼촌밥차런치펍",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 661,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.1751596401248,
        "lng": 129.1245333176407
      },
      "address": "센텀가야밀면",
      "address2": "센텀가야밀면",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 662,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.23139580301661,
        "lng": 129.08864865249254
      },
      "address": "맛나감자탕 부산대점",
      "address2": "맛나감자탕 부산대점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 663,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.208498030784185,
        "lng": 129.0090945585202
      },
      "address": "NF커피",
      "address2": "NF커피",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 664,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.219402,
        "lng": 128.682338
      },
      "address": "고릴라 PC방(09:30)",
      "address2": "고릴라 PC방(09:30)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 665,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.098037815871585,
        "lng": 128.99369982072915
      },
      "address": "착한멸치국수 괴정점",
      "address2": "착한멸치국수 괴정점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 666,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.0995457823646,
        "lng": 128.98989867164812
      },
      "address": "이대운 이비인후과의원",
      "address2": "이대운 이비인후과의원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 667,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.0995495296311,
        "lng": 128.98988999044911
      },
      "address": "세인약국",
      "address2": "세인약국",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 668,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.09856938178571,
        "lng": 128.99162498776312
      },
      "address": "도담복전문점",
      "address2": "도담복전문점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 669,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.1071385985367,
        "lng": 128.96818994719703
      },
      "address": "크레인PC 부산하단점",
      "address2": "크레인PC 부산하단점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 670,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.108835410639394,
        "lng": 128.96714286487003
      },
      "address": "리얼야구존 하단동점",
      "address2": "리얼야구존 하단동점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 671,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.09866213079249,
        "lng": 128.99256148256515
      },
      "address": "갓신 괴정점",
      "address2": "갓신 괴정점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 672,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.10749653335411,
        "lng": 129.01809577112118
      },
      "address": "코로나19 서구보건소 선별진료소",
      "address2": "코로나19 서구보건소 선별진료소",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 673,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.208096781550985,
        "lng": 128.69694245322836
      },
      "address": "유내과",
      "address2": "유내과",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 674,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.2082781422916,
        "lng": 128.69686277511036
      },
      "address": "신세계약국",
      "address2": "신세계약국",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 675,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.20403010696722,
        "lng": 128.70312961337936
      },
      "address": "남창원농협 농수산물종합유통센터",
      "address2": "남창원농협 농수산물종합유통센터",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 676,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.22693205558951,
        "lng": 128.69128951895436
      },
      "address": "상지 종합상사",
      "address2": "상지 종합상사",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 677,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.226561,
        "lng": 128.694737
      },
      "address": "낚시프라자(의창신월동)",
      "address2": "낚시프라자(의창신월동)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 678,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.2078278264611,
        "lng": 128.69812714563537
      },
      "address": "성산가음정시장내 서라벌족발옆 분식집",
      "address2": "성산가음정시장내 서라벌족발옆 분식집",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 679,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.21307242741048,
        "lng": 128.70098608411138
      },
      "address": "최이비인후과의원 (2/20,22)",
      "address2": "최이비인후과의원 (2/20,22)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 680,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.21307609293421,
        "lng": 128.70098176809938
      },
      "address": "굿모닝약국 (2/20,22)",
      "address2": "굿모닝약국 (2/20,22)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 681,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.21370152731169,
        "lng": 128.70085425705238
      },
      "address": "인화약국",
      "address2": "인화약국",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 682,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.29472855633811,
        "lng": 128.34466059297807
      },
      "address": "함안휴게소 화장실(여)",
      "address2": "함안휴게소 화장실(여)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 683,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.95458127600263,
        "lng": 127.92345348691501
      },
      "address": "우미린캐슬어린이집",
      "address2": "우미린캐슬어린이집",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 684,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.97407955666101,
        "lng": 127.93297420759639
      },
      "address": "충주중앙병원",
      "address2": "충주중앙병원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 685,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.98531297713321,
        "lng": 127.94402878613687
      },
      "address": "연수힐스테이트아파트",
      "address2": "연수힐스테이트아파트",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 686,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.981404935714,
        "lng": 127.91423542994
      },
      "address": "롯데마트 충주점",
      "address2": "롯데마트 충주점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 687,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.86026006021729,
        "lng": 128.49093317437047
      },
      "address": "계명문화대학교 기숙사",
      "address2": "계명문화대학교 기숙사",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 688,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.8680036309713,
        "lng": 128.59605580106924
      },
      "address": "레드버튼 동성로점",
      "address2": "레드버튼 동성로점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 689,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.866921270984705,
        "lng": 128.59450186449286
      },
      "address": "스파오 동성로2호점",
      "address2": "스파오 동성로2호점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 690,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.8774317000986,
        "lng": 128.62732308767028
      },
      "address": "이마트24 RS동대구역점",
      "address2": "이마트24 RS동대구역점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 691,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.866771532163696,
        "lng": 128.59681934329222
      },
      "address": "웰크레페 동성로점",
      "address2": "웰크레페 동성로점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 692,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.859097425972,
        "lng": 128.49254091575213
      },
      "address": "세븐일레븐 대구계명문화대점",
      "address2": "세븐일레븐 대구계명문화대점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 693,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.72995342491374,
        "lng": 128.27209646306602
      },
      "address": "고령영생병원",
      "address2": "고령영생병원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 694,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.729501360949065,
        "lng": 128.27198759124752
      },
      "address": "백세약국",
      "address2": "백세약국",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 695,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.199171381550805,
        "lng": 128.5655606205452
      },
      "address": "코로나19 마산의료원 선별진료소",
      "address2": "코로나19 마산의료원 선별진료소",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 696,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.19917138155086,
        "lng": 128.565560620545
      },
      "address": "경상남도 마산의료원",
      "address2": "경상남도 마산의료원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 697,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.72981697649501,
        "lng": 128.26812755502903
      },
      "address": "정통닭칼국수 고령점",
      "address2": "정통닭칼국수 고령점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 698,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.097639,
        "lng": 127.933087
      },
      "address": "엄정 애린어린이집 방문",
      "address2": "엄정 애린어린이집 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 699,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.80125498117031,
        "lng": 128.09798374251903
      },
      "address": "해인사",
      "address2": "해인사",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 700,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.97957909864063,
        "lng": 127.97035088896845
      },
      "address": "충주의료원 음압병실 입원",
      "address2": "충주의료원 음압병실 입원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 701,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.805763466421105,
        "lng": 127.11153147433
      },
      "address": "대동다숲아파트(자택)",
      "address2": "대동다숲아파트(자택)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 702,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.239165,
        "lng": 128.916409
      },
      "address": "한일여고 128-1 버스 승차(2/17,18,19,21)",
      "address2": "한일여고 128-1 버스 승차(2/17,18,19,21)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 703,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.2133137085415,
        "lng": 128.96097294928197
      },
      "address": "부산 대저역 하차,승차(2/17,18,19)",
      "address2": "부산 대저역 하차,승차(2/17,18,19)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 704,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.16364796386121,
        "lng": 129.1588972402529
      },
      "address": "해운대역(2/17,18) ",
      "address2": "해운대역(2/17,18) ",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 705,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.16830460022331,
        "lng": 129.15366056343984
      },
      "address": "해운대여자중학교(2/17,18)",
      "address2": "해운대여자중학교(2/17,18)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 706,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.157939062512,
        "lng": 129.05930088354637
      },
      "address": "서면역 부산1호선(2/17,18,19)",
      "address2": "서면역 부산1호선(2/17,18,19)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 707,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.15509835931101,
        "lng": 129.0620689933964
      },
      "address": "고복 샤브샤브 서면점",
      "address2": "고복 샤브샤브 서면점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 708,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.15716439259075,
        "lng": 129.06325245873808
      },
      "address": "NC백화점 서면점 1층 로이드",
      "address2": "NC백화점 서면점 1층 로이드",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 709,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.15394225075381,
        "lng": 129.0615877432894
      },
      "address": "모던테이블 서면점",
      "address2": "모던테이블 서면점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 710,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.21072481613721,
        "lng": 129.07684012905645
      },
      "address": "복있는치과의원",
      "address2": "복있는치과의원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 711,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.2385307073672,
        "lng": 128.91555075705287
      },
      "address": "박영진의원(2/18,20)",
      "address2": "박영진의원(2/18,20)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 712,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.23858040200736,
        "lng": 128.91537178443636
      },
      "address": "더선경약국(2/18,20)",
      "address2": "더선경약국(2/18,20)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 713,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.15734582681171,
        "lng": 129.0647153473864
      },
      "address": "서면 피자집 도우개러지",
      "address2": "서면 피자집 도우개러지",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 714,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.1553264583912,
        "lng": 129.06814044907745
      },
      "address": "카페 AWLUK",
      "address2": "카페 AWLUK",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 715,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.153088142664124,
        "lng": 129.06538457863138
      },
      "address": "전포역 지하철 탑승",
      "address2": "전포역 지하철 탑승",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 716,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.202809215648784,
        "lng": 128.99955618123315
      },
      "address": "구명역",
      "address2": "구명역",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 717,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 34.829590963483376,
        "lng": 128.70372783123926
      },
      "address": "일운면 쌤김밥",
      "address2": "일운면 쌤김밥",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 718,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 34.824374746340986,
        "lng": 128.4241464930771
      },
      "address": "스카이라인루지 통영",
      "address2": "스카이라인루지 통영",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 719,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.1766241640059,
        "lng": 128.80647609006255
      },
      "address": "돈토리",
      "address2": "돈토리",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 720,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.209249258830205,
        "lng": 129.00357032807014
      },
      "address": "부산 구포시장",
      "address2": "부산 구포시장",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 721,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.21534437587001,
        "lng": 129.07356698119946
      },
      "address": "110번 버스 부산전자공업고등학교",
      "address2": "110번 버스 부산전자공업고등학교",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 722,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.215981775340005,
        "lng": 129.07717612406245
      },
      "address": "온천교회",
      "address2": "온천교회",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 723,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.2075966429643,
        "lng": 129.07322936891845
      },
      "address": "아빠와돈까스",
      "address2": "아빠와돈까스",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 724,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.23222919863411,
        "lng": 128.87070989801472
      },
      "address": "코로나19 김해시보건소 선별진료소",
      "address2": "코로나19 김해시보건소 선별진료소",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 725,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.32782130499471,
        "lng": 129.00588591265415
      },
      "address": "양산부산대학교병원",
      "address2": "양산부산대학교병원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 726,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.8054921320214,
        "lng": 127.10970114159842
      },
      "address": "찰스리미용실 대동다숲 방문",
      "address2": "찰스리미용실 대동다숲 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 727,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.788422733781196,
        "lng": 127.107307260544
      },
      "address": "상도종합건설 출근",
      "address2": "상도종합건설 출근",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 728,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.30530081785731,
        "lng": 129.02656822853723
      },
      "address": "본동국밥칼국수",
      "address2": "본동국밥칼국수",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 729,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.7997839759622,
        "lng": 127.12569957709401
      },
      "address": "천안본정형외과 방문",
      "address2": "천안본정형외과 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 730,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.3357394475375,
        "lng": 129.0249747652252
      },
      "address": "코로나19 양산시보건소 선별진료소",
      "address2": "코로나19 양산시보건소 선별진료소",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 731,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.8025841773036,
        "lng": 127.119137688512
      },
      "address": "삼성라온내과와 1층약국 방문",
      "address2": "삼성라온내과와 1층약국 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 732,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.80257964929972,
        "lng": 127.11916009264061
      },
      "address": "얌샘김밥 천안쌍용점",
      "address2": "얌샘김밥 천안쌍용점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 733,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.023372412563305,
        "lng": 128.80732632817657
      },
      "address": "거제 가덕해양파크",
      "address2": "거제 가덕해양파크",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 734,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.2387242263462,
        "lng": 128.91681739969584
      },
      "address": "한효슈퍼",
      "address2": "한효슈퍼",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 735,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.528324747431206,
        "lng": 129.04517321106124
      },
      "address": "장터돼지국밥 진보점 방문",
      "address2": "장터돼지국밥 진보점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 736,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.52883397872731,
        "lng": 129.04532058930724
      },
      "address": "고마담치킨 진보점 방문",
      "address2": "고마담치킨 진보점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 737,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.52706892009238,
        "lng": 129.04358839412427
      },
      "address": "식자재마트진보 방문",
      "address2": "식자재마트진보 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 738,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.90326330517421,
        "lng": 127.198317737577
      },
      "address": "경기도의료원 포천병원",
      "address2": "경기도의료원 포천병원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 739,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.52864609069379,
        "lng": 129.04387773693622
      },
      "address": "중화요리 용궁식당 방문",
      "address2": "중화요리 용궁식당 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 740,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.52809323398159,
        "lng": 129.04333179018923
      },
      "address": "다이소 청송진보점 방문",
      "address2": "다이소 청송진보점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 741,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.088738121826985,
        "lng": 127.59098921804299
      },
      "address": "청미천 근무",
      "address2": "청미천 근무",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 742,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.11903298806259,
        "lng": 127.63109225348101
      },
      "address": "엄마밥차",
      "address2": "엄마밥차",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 743,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.52916792644591,
        "lng": 129.0426589747802
      },
      "address": "제일내과의원 방문",
      "address2": "제일내과의원 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 744,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.528970815602804,
        "lng": 129.0432253812882
      },
      "address": "진보동산약국 방문",
      "address2": "진보동산약국 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 745,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.431033413211146,
        "lng": 129.0526518546275
      },
      "address": "청송군보건의료원 방문",
      "address2": "청송군보건의료원 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 746,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.31803891802031,
        "lng": 127.102076293537
      },
      "address": "지리산석유주유소 방문",
      "address2": "지리산석유주유소 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 747,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.2294780184202,
        "lng": 127.06567694811201
      },
      "address": "지에스테크윈",
      "address2": "지에스테크윈",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 748,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.3324026187663,
        "lng": 127.10477675221802
      },
      "address": "죽전휴게소 서울방향",
      "address2": "죽전휴게소 서울방향",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 749,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.5390690644966,
        "lng": 126.94735422122199
      },
      "address": "근신빌딩 바탕",
      "address2": "근신빌딩 바탕",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 750,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.38528838491941,
        "lng": 126.95731733307801
      },
      "address": "범계동 우성아파트",
      "address2": "범계동 우성아파트",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 751,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.77434035626601,
        "lng": 127.586694048414
      },
      "address": "코로나19 증평군보건소 선별진료소 확진",
      "address2": "코로나19 증평군보건소 선별진료소 확진",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 752,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.416451341811104,
        "lng": 126.88480397548899
      },
      "address": "KTX 광명역",
      "address2": "KTX 광명역",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 753,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.48698266881209,
        "lng": 126.792466925871
      },
      "address": "가톨릭대학교 부천성모병원",
      "address2": "가톨릭대학교 부천성모병원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 754,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.48698266881209,
        "lng": 126.792466925871
      },
      "address": "가톨릭대학교 부천성모병원 선별진료소",
      "address2": "가톨릭대학교 부천성모병원 선별진료소",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 755,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.64206996516571,
        "lng": 126.83145714476498
      },
      "address": "명지병원 격리",
      "address2": "명지병원 격리",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 756,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 38.02569181414809,
        "lng": 127.06816146129502
      },
      "address": "큰손원조할매순대국 전곡점",
      "address2": "큰손원조할매순대국 전곡점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 757,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.893414,
        "lng": 126.8715187
      },
      "address": "풍작플랜지 식당(2/17~2/21)",
      "address2": "풍작플랜지 식당(2/17~2/21)",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 758,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.555980239632106,
        "lng": 126.972091251236
      },
      "address": "서울역 1호선",
      "address2": "서울역 1호선",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 759,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 38.02528574643019,
        "lng": 127.06772943358702
      },
      "address": "전곡시외버스터미널",
      "address2": "전곡시외버스터미널",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 760,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.61266242089956,
        "lng": 126.7323442002163
      },
      "address": "풍무역 김포골드라인",
      "address2": "풍무역 김포골드라인",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 761,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.56182975642019,
        "lng": 126.80247310798501
      },
      "address": "김포공항역 공항철도",
      "address2": "김포공항역 공항철도",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 762,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.55302870046421,
        "lng": 126.972644620034
      },
      "address": "서울역 4호선",
      "address2": "서울역 4호선",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 763,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.52925914893749,
        "lng": 126.96796503918299
      },
      "address": "신용산역 4호선",
      "address2": "신용산역 4호선",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 764,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.5279760820472,
        "lng": 126.96781625386299
      },
      "address": "LS용산타워",
      "address2": "LS용산타워",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 765,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.528819096922106,
        "lng": 126.966652883289
      },
      "address": "코코이비인후과의원",
      "address2": "코코이비인후과의원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 766,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.538156854068006,
        "lng": 126.89333386706899
      },
      "address": "선유도역 9호선",
      "address2": "선유도역 9호선",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 767,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.5619657741382,
        "lng": 126.80191588831
      },
      "address": "김포공항역 9호선",
      "address2": "김포공항역 9호선",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 768,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.61266242089956,
        "lng": 126.7323442002163
      },
      "address": "풍무역 김포골드라인",
      "address2": "풍무역 김포골드라인",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 769,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.1734345402495,
        "lng": 129.10359640653363
      },
      "address": "부산지방병무청 방문",
      "address2": "부산지방병무청 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 770,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.44846731235319,
        "lng": 126.88405648750621
      },
      "address": "메이저리치 빌딩 근무",
      "address2": "메이저리치 빌딩 근무",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 771,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.155517700191425,
        "lng": 129.0607277405474
      },
      "address": "세븐스타코인 노래연습장 서면점 방문",
      "address2": "세븐스타코인 노래연습장 서면점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 772,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.1562060048052,
        "lng": 129.0620091722154
      },
      "address": "우정 서면2호점 방문",
      "address2": "우정 서면2호점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 773,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.64206996516571,
        "lng": 126.83145714476498
      },
      "address": "명지병원 격리",
      "address2": "명지병원 격리",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 774,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.19616968130391,
        "lng": 129.0611647764842
      },
      "address": "사직자이언츠파크 3pop PC방 방문 ",
      "address2": "사직자이언츠파크 3pop PC방 방문 ",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 775,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.17683141439141,
        "lng": 129.07910319217947
      },
      "address": "코로나19 연제구보건소 선별진료소 방문",
      "address2": "코로나19 연제구보건소 선별진료소 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 776,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.21221772522561,
        "lng": 129.07722514295546
      },
      "address": "롯데마트 동래점 방문",
      "address2": "롯데마트 동래점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 777,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.211799081316805,
        "lng": 129.07746482467346
      },
      "address": "삼진어묵 동래점 방문",
      "address2": "삼진어묵 동래점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 778,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.22194092440579,
        "lng": 129.08551591412248
      },
      "address": "부산우리들병원 매점 방문 ",
      "address2": "부산우리들병원 매점 방문 ",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 779,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.222024739640396,
        "lng": 129.0846263517915
      },
      "address": "KB국민은행ATM 방문",
      "address2": "KB국민은행ATM 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 780,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.22109014910189,
        "lng": 129.0846320926265
      },
      "address": "도리마리 본점 방문",
      "address2": "도리마리 본점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 781,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.01903532652067,
        "lng": 127.09859591275836
      },
      "address": "동삭동 현대아파트 거주",
      "address2": "동삭동 현대아파트 거주",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 782,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.993689570219985,
        "lng": 127.09204772606253
      },
      "address": "평택사랑외과의원",
      "address2": "평택사랑외과의원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 783,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 36.9936406569752,
        "lng": 127.09237568654702
      },
      "address": "프라자 약국",
      "address2": "프라자 약국",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 784,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.496434823485004,
        "lng": 127.123501540716
      },
      "address": "국립경찰병원",
      "address2": "국립경찰병원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 785,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.06569374577861,
        "lng": 127.066470987295
      },
      "address": "송탄보건소 출근",
      "address2": "송탄보건소 출근",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 786,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.496434823485004,
        "lng": 127.123501540716
      },
      "address": "국립경찰병원",
      "address2": "국립경찰병원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 787,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.754883167701436,
        "lng": 126.779774098725
      },
      "address": "경기도의료원 파주병원",
      "address2": "경기도의료원 파주병원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 788,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.22133856446041,
        "lng": 129.08564325739908
      },
      "address": "카페051 온천역점 방문",
      "address2": "카페051 온천역점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 789,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.2155989355679,
        "lng": 129.07742990563645
      },
      "address": "탑세일마트 온천점 방문",
      "address2": "탑세일마트 온천점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 790,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.849254132317206,
        "lng": 126.87263095765002
      },
      "address": "법원천하약국",
      "address2": "법원천하약국",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 791,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.84876326667472,
        "lng": 126.875299602282
      },
      "address": "기사식당",
      "address2": "기사식당",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 792,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.1962705526415,
        "lng": 129.06122111876638
      },
      "address": "사직동 멕시멈휘트니스 방문",
      "address2": "사직동 멕시멈휘트니스 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 793,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.21110006575282,
        "lng": 129.07975723606447
      },
      "address": "박약국 방문",
      "address2": "박약국 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 794,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.17450835507701,
        "lng": 129.0633977090364
      },
      "address": "쓰리제이에듀 부산진구지점 방문",
      "address2": "쓰리제이에듀 부산진구지점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 795,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.17459196245391,
        "lng": 129.06441393791343
      },
      "address": "정내과의원 방문",
      "address2": "정내과의원 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 796,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.174603145796496,
        "lng": 129.0643922701914
      },
      "address": "참사람 약국 방문",
      "address2": "참사람 약국 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 797,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.17450835507701,
        "lng": 129.0633977090364
      },
      "address": "CU 양정현대프라자점",
      "address2": "CU 양정현대프라자점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 798,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.212432599914,
        "lng": 129.07961554867447
      },
      "address": "GS25 S부산명륜역점 방문",
      "address2": "GS25 S부산명륜역점 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 799,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.17279452020731,
        "lng": 129.0710939773354
      },
      "address": "양정역 부산1호선",
      "address2": "양정역 부산1호선",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 800,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.2051432442233,
        "lng": 129.0800839821225
      },
      "address": "이화동고로케 방문",
      "address2": "이화동고로케 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 801,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.20468217210881,
        "lng": 129.0846747365705
      },
      "address": "링구아어학원 면접차 방문",
      "address2": "링구아어학원 면접차 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 802,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.291098360098886,
        "lng": 127.07213954282454
      },
      "address": "GS25 광교참누리점",
      "address2": "GS25 광교참누리점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 803,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.2669688574936,
        "lng": 127.00176776632999
      },
      "address": "수원역 분당선 8번출구",
      "address2": "수원역 분당선 8번출구",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 804,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.29221866084465,
        "lng": 127.07012301688236
      },
      "address": "광교2동 행정복지센터",
      "address2": "광교2동 행정복지센터",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 805,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.183765,
        "lng": 129.083024
      },
      "address": "반도보라아파트 정류장 51번 버스에서 하차",
      "address2": "반도보라아파트 정류장 51번 버스에서 하차",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 806,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.18603790971191,
        "lng": 129.08160336475848
      },
      "address": "연산역 부산1호선 승차",
      "address2": "연산역 부산1호선 승차",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 807,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.06290812166031,
        "lng": 128.97915978972205
      },
      "address": "다세움교회 방문",
      "address2": "다세움교회 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 808,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.235372260576504,
        "lng": 129.08024506220448
      },
      "address": "금정회관 방문",
      "address2": "금정회관 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 809,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.30749694510631,
        "lng": 129.11200511786163
      },
      "address": "해피케어복지관 방문",
      "address2": "해피케어복지관 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 810,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.23069433438311,
        "lng": 129.0873127321795
      },
      "address": "제이앤 제이스타일 헤어 방문",
      "address2": "제이앤 제이스타일 헤어 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 811,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.100824331003814,
        "lng": 129.0187383154012
      },
      "address": "부산대학교병원 방문",
      "address2": "부산대학교병원 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 812,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.879323993179504,
        "lng": 128.62839377538825
      },
      "address": "동대구역",
      "address2": "동대구역",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 813,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.879323993179504,
        "lng": 128.62839377538825
      },
      "address": "동대구역",
      "address2": "동대구역",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 814,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.2731345422434,
        "lng": 127.01580295485999
      },
      "address": "해운대국밥",
      "address2": "해운대국밥",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 815,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.39170679339027,
        "lng": 127.15176219552485
      },
      "address": "국군수도병원",
      "address2": "국군수도병원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 816,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.27958828328031,
        "lng": 127.04761136661999
      },
      "address": "아주대학교병원",
      "address2": "아주대학교병원",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 817,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.2124826165236,
        "lng": 129.07838263379648
      },
      "address": "우기현 내과 방문",
      "address2": "우기현 내과 방문",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 818,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 35.2042360924945,
        "lng": 129.08022333262247
      },
      "address": "코로나19 대동병원 선별진료소",
      "address2": "코로나19 대동병원 선별진료소",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 819,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.296329850611265,
        "lng": 127.04692716674592
      },
      "address": "이마트 광교점",
      "address2": "이마트 광교점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 820,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.3002187837255,
        "lng": 127.04444256769847
      },
      "address": "본죽 수원광교역점",
      "address2": "본죽 수원광교역점",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 821,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.25874424014351,
        "lng": 126.97112812016601
      },
      "address": "코로나19 권선구보건소 선별진료소",
      "address2": "코로나19 권선구보건소 선별진료소",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 822,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.29185913925371,
        "lng": 126.99637759217902
      },
      "address": "경기도의료원 수원병원 격리",
      "address2": "경기도의료원 수원병원 격리",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 823,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.27815482496529,
        "lng": 127.034314173322
      },
      "address": "코로나19 동수원병원 선별진료소",
      "address2": "코로나19 동수원병원 선별진료소",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 824,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.4127665641008,
        "lng": 126.907853110914
      },
      "address": "석수동 우리마트",
      "address2": "석수동 우리마트",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 825,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.41154729446048,
        "lng": 126.90646298066899
      },
      "address": "수스커피",
      "address2": "수스커피",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 826,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.39765915889443,
        "lng": 126.95911164239264
      },
      "address": "관양동 부영아파트 거주",
      "address2": "관양동 부영아파트 거주",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 827,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.39423950914369,
        "lng": 126.9638080221341
      },
      "address": "평촌역 4호선 출퇴근",
      "address2": "평촌역 4호선 출퇴근",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 828,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.3917052792552,
        "lng": 126.962038549409
      },
      "address": "코로나19 한림대학교성심병원 선별진료소",
      "address2": "코로나19 한림대학교성심병원 선별진료소",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 829,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.39275316576636,
        "lng": 126.96203011600447
      },
      "address": "오얏봉약국",
      "address2": "오얏봉약국",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 830,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.3917052792552,
        "lng": 126.962038549409
      },
      "address": "코로나19 한림대학교성심병원 선별진료소",
      "address2": "코로나19 한림대학교성심병원 선별진료소",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 831,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.385882567044696,
        "lng": 126.93294929443
      },
      "address": "코로나19 만안구보건소 선별진료소",
      "address2": "코로나19 만안구보건소 선별진료소",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 832,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.46224757386889,
        "lng": 126.680643386413
      },
      "address": "코로나19 인천사랑병원 선별진료소",
      "address2": "코로나19 인천사랑병원 선별진료소",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    },
    {
      "idx": 833,
      "label": "",
      "title": "",
      "type": "virus",
      "location": {
        "lat": 37.46224757386889,
        "lng": 126.680643386413
      },
      "address": "코로나19 인천사랑병원 선별진료소",
      "address2": "코로나19 인천사랑병원 선별진료소",
      "visitDate": "",
      "age": "",
      "nation": "",
      "gender": "",
      "date": "",
      "contact": ""
    }
  ];